"""
Utility functions for Hospital Management System
"""
import re
import os
import uuid
import hashlib
import bcrypt
import logging
from datetime import datetime, date
from tkinter import messagebox

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='app.log',
    filemode='a'
)
logger = logging.getLogger('utils')

# Validation patterns
EMAIL_PATTERN = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
PHONE_PATTERN = r'^\+?[0-9]{10,15}$'
PASSWORD_PATTERN = r'^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$'

def validate_email(email):
    """Validate email format"""
    pattern = re.compile(EMAIL_PATTERN)
    return bool(pattern.match(email))

def validate_phone(phone):
    """Validate phone number format"""
    pattern = re.compile(PHONE_PATTERN)
    return bool(pattern.match(phone))

def validate_password_strength(password):
    """
    Validate password strength
    - At least 8 characters
    - Contains at least one letter
    - Contains at least one number
    - Contains at least one special character
    """
    pattern = re.compile(PASSWORD_PATTERN)
    return bool(pattern.match(password))

def hash_password(password):
    """
    Hash a password using bcrypt
    
    Args:
        password (str): Plain text password
        
    Returns:
        str: Hashed password
    """
    # Generate salt and hash the password
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed.decode('utf-8')

def verify_password(stored_hash, provided_password):
    """
    Verify a password against a hash
    
    Args:
        stored_hash (str): The stored password hash
        provided_password (str): The password to verify
        
    Returns:
        bool: True if password matches, False otherwise
    """
    return bcrypt.checkpw(provided_password.encode('utf-8'), stored_hash.encode('utf-8'))

def generate_token():
    """
    Generate a unique token for appointments
    
    Returns:
        str: Token string (e.g., "TKN-12345-ABCDE")
    """
    # Generate random unique ID
    unique_id = str(uuid.uuid4())
    # Create token using timestamp and hash
    timestamp = datetime.now().strftime("%Y%m%d%H")
    hash_base = f"{timestamp}-{unique_id}"
    hash_object = hashlib.md5(hash_base.encode())
    token_hash = hash_object.hexdigest()[:10].upper()
    
    # Format as TKN-XXXXX-YYYYY
    token = f"TKN-{token_hash[:5]}-{token_hash[5:10]}"
    return token

def calculate_age(birth_date):
    """
    Calculate age from birth date
    
    Args:
        birth_date (date): Date of birth
        
    Returns:
        int: Age in years
    """
    today = date.today()
    return today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))

def show_message(parent, title, message, icon="info"):
    """
    Show a message box
    
    Args:
        parent: Parent widget
        title (str): Message box title
        message (str): Message content
        icon (str): Message type ("info", "warning", or "error")
        
    Returns:
        str: Button clicked ("ok")
    """
    if icon == "error":
        return messagebox.showerror(title, message)
    elif icon == "warning":
        return messagebox.showwarning(title, message)
    else:
        return messagebox.showinfo(title, message)

def show_confirmation(parent, title, message):
    """
    Show a confirmation dialog
    
    Args:
        parent: Parent widget
        title (str): Dialog title
        message (str): Question to ask
        
    Returns:
        bool: True if Yes was clicked, False otherwise
    """
    return messagebox.askyesno(title, message)

def validate_input(text, pattern):
    """
    Validate input text against a pattern
    
    Args:
        text (str): Text to validate
        pattern (str): Regular expression pattern
        
    Returns:
        bool: True if text matches pattern, False otherwise
    """
    regex = re.compile(pattern)
    return bool(regex.match(text))

def format_currency(amount):
    """
    Format a number as currency
    
    Args:
        amount (float): Amount to format
        
    Returns:
        str: Formatted currency string (e.g., "$1,234.56")
    """
    return "${:,.2f}".format(amount)

def log_activity(user_id, action, details=None):
    """
    Log user activity
    
    Args:
        user_id (int): User ID
        action (str): Action performed
        details (str, optional): Additional details
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = f"User {user_id} - {action}"
    if details:
        log_message += f" - {details}"
    
    logger.info(log_message)