"""
Profile dialog module for patient profile editing
"""
import customtkinter as ctk
import tkinter as tk
from tkinter import ttk, messagebox
from tkcalendar import DateEntry
from src.controllers.patient_controller import PatientController

class ProfileDialog(ctk.CTkToplevel):
    """Dialog for editing patient profile"""
    
    def __init__(self, patient, parent=None):
        """Initialize profile dialog"""
        super().__init__(parent)
        self.patient = patient
        
        # Configure window
        self.title("Edit Profile")
        self.geometry("500x600")
        
        # Create form frame
        self.form_frame = ctk.CTkFrame(self)
        self.form_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create form fields
        self.create_form()
        
        # Create buttons
        self.create_buttons()
        
        # Load patient data
        self.load_data()
    
    def create_form(self):
        """Create form fields"""
        labels = [
            ("First Name:", "first_name"),
            ("Last Name:", "last_name"),
            ("Email:", "email"),
            ("Phone:", "phone"),
            ("Date of Birth:", "date_of_birth"),
            ("Gender:", "gender"),
            ("Blood Group:", "blood_group"),
            ("Address:", "address"),
            ("Medical History:", "medical_history")
        ]
        
        for i, (label, field) in enumerate(labels):
            # Create label
            label_widget = ctk.CTkLabel(
                self.form_frame,
                text=label
            )
            label_widget.grid(row=i, column=0, padx=5, pady=5, sticky=tk.W)
            
            if field == "date_of_birth":
                # Date picker
                widget = DateEntry(
                    self.form_frame,
                    width=30,
                    background='darkblue',
                    foreground='white',
                    borderwidth=2
                )
                widget.grid(row=i, column=1, padx=5, pady=5, sticky=tk.EW)
                
            elif field == "gender":
                # Gender combobox
                widget = ttk.Combobox(
                    self.form_frame,
                    values=["Male", "Female", "Other"],
                    state="readonly"
                )
                widget.grid(row=i, column=1, padx=5, pady=5, sticky=tk.EW)
                
            elif field == "blood_group":
                # Blood group combobox
                widget = ttk.Combobox(
                    self.form_frame,
                    values=["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"],
                    state="readonly"
                )
                widget.grid(row=i, column=1, padx=5, pady=5, sticky=tk.EW)
                
            elif field == "medical_history":
                # Medical history text area
                widget = ctk.CTkTextbox(
                    self.form_frame,
                    height=100,
                    wrap=tk.WORD
                )
                widget.grid(row=i, column=1, padx=5, pady=5, sticky=tk.EW)
                
            else:
                # Regular text input
                widget = ctk.CTkEntry(self.form_frame)
                widget.grid(row=i, column=1, padx=5, pady=5, sticky=tk.EW)
            
            setattr(self, f"{field}_field", widget)
    
    def create_buttons(self):
        """Create form buttons"""
        button_frame = ctk.CTkFrame(self)
        button_frame.pack(fill=tk.X, pady=10)
        
        save_button = ctk.CTkButton(
            button_frame,
            text="Save",
            command=self.save_profile
        )
        save_button.pack(side=tk.RIGHT, padx=5)
        
        cancel_button = ctk.CTkButton(
            button_frame,
            text="Cancel",
            command=self.destroy,
            fg_color="transparent",
            border_width=2
        )
        cancel_button.pack(side=tk.RIGHT, padx=5)
    
    def load_data(self):
        """Load patient data into form fields"""
        for field in [
            "first_name", "last_name", "email", "phone",
            "gender", "blood_group", "address"
        ]:
            if hasattr(self.patient, field):
                widget = getattr(self, f"{field}_field")
                value = getattr(self.patient, field)
                if isinstance(widget, ttk.Combobox):
                    widget.set(value)
                else:
                    widget.insert(0, value)
        
        # Set date of birth
        if self.patient.date_of_birth:
            self.date_of_birth_field.set_date(self.patient.date_of_birth)
        
        # Set medical history
        if self.patient.medical_history:
            self.medical_history_field.insert("1.0", self.patient.medical_history)
    
    def save_profile(self):
        """Save profile changes"""
        # Collect form data
        data = {
            "first_name": self.first_name_field.get(),
            "last_name": self.last_name_field.get(),
            "email": self.email_field.get(),
            "phone": self.phone_field.get(),
            "date_of_birth": self.date_of_birth_field.get_date(),
            "gender": self.gender_field.get(),
            "blood_group": self.blood_group_field.get(),
            "address": self.address_field.get(),
            "medical_history": self.medical_history_field.get("1.0", tk.END).strip()
        }
        
        # Validate required fields
        required_fields = ["first_name", "last_name", "email", "phone"]
        for field in required_fields:
            if not data[field]:
                messagebox.showerror(
                    "Validation Error",
                    f"{field.replace('_', ' ').title()} is required."
                )
                return
        
        # Update patient data
        try:
            PatientController.update_patient(self.patient.patient_id, data)
            messagebox.showinfo("Success", "Profile updated successfully")
            self.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to update profile: {str(e)}")