"""
Feedback controller for managing feedback operations
"""
import logging
from datetime import datetime
from src.data.memory_store import MemoryStore, Feedback
from src.utils.helpers import log_activity

# Configure logging
logger = logging.getLogger('feedback_controller')

class FeedbackController:
    """Controller for feedback operations"""
    
    @staticmethod
    def submit_feedback(patient_id: int, doctor_id: int, appointment_id: int = 0, 
                       rating: int = 5, comment: str = None, comments: str = None) -> tuple[bool, Feedback | str]:
        """Submit new feedback"""
        try:
            store = MemoryStore()
            
            # Handle both comment and comments parameter names (for backward compatibility)
            actual_comment = comment if comment is not None else (comments if comments is not None else "")
            
            # Validate required fields
            if not all([patient_id, doctor_id, rating]):
                return False, "Patient ID, doctor ID and rating are required."
            
            # Validate rating
            if not (1 <= rating <= 5):
                return False, "Rating must be between 1 and 5."
            
            # Check if appointment exists
            appointment = store.get_appointment_by_id(appointment_id)
            if not appointment:
                return False, "Appointment not found."
                
            # Verify patient and doctor match appointment if an appointment is specified
            if appointment_id > 0:
                if appointment.patient_id != patient_id or appointment.doctor_id != doctor_id:
                    return False, "Invalid patient or doctor for this appointment."
            
            # Create feedback
            feedback = store.create_feedback(
                patient_id=patient_id,
                doctor_id=doctor_id,
                appointment_id=appointment_id,
                rating=rating,
                comment=actual_comment,
                submitted_at=datetime.now()
            )
            
            if not feedback:
                return False, "Failed to create feedback"
            
            log_activity(patient_id, f"Feedback submitted for appointment: {appointment_id}")
            return True, feedback
            
        except Exception as e:
            logger.error(f"Feedback submission error: {str(e)}")
            return False, f"An error occurred: {str(e)}"
    
    @staticmethod
    def get_feedback_by_id(feedback_id: int) -> Feedback | None:
        """Get feedback by ID"""
        try:
            store = MemoryStore()
            return store.get_feedback_by_id(feedback_id)
        except Exception as e:
            logger.error(f"Error retrieving feedback: {str(e)}")
            return None
    
    @staticmethod
    def get_feedback_by_patient(patient_id: int) -> list[Feedback]:
        """Get feedback by patient"""
        try:
            store = MemoryStore()
            return store.get_feedback_by_patient(patient_id)
        except Exception as e:
            logger.error(f"Error retrieving patient feedback: {str(e)}")
            return []
    
    @staticmethod
    def get_feedback_by_doctor(doctor_id: int) -> list[Feedback]:
        """Get feedback by doctor"""
        try:
            store = MemoryStore()
            return store.get_feedback_by_doctor(doctor_id)
        except Exception as e:
            logger.error(f"Error retrieving doctor feedback: {str(e)}")
            return []
    
    @staticmethod
    def get_feedback(start_date=None, end_date=None, rating=None) -> list:
        """Get feedback based on filters"""
        try:
            store = MemoryStore()
            feedback_list = list(store.feedback.values())
            
            # Filter by date range if specified
            if start_date and end_date:
                feedback_list = [f for f in feedback_list if start_date <= f.submitted_at.date() <= end_date]
            elif start_date:
                feedback_list = [f for f in feedback_list if start_date <= f.submitted_at.date()]
            elif end_date:
                feedback_list = [f for f in feedback_list if f.submitted_at.date() <= end_date]
            
            # Filter by rating if specified
            if rating is not None:
                feedback_list = [f for f in feedback_list if f.rating == rating]
                
            return feedback_list
        except Exception as e:
            logger.error(f"Error retrieving feedback: {str(e)}")
            return []
            
    @staticmethod
    def add_response(feedback_id: int, response: str) -> tuple[bool, str]:
        """Add response to feedback"""
        try:
            store = MemoryStore()
            
            # Get feedback
            feedback = store.get_feedback_by_id(feedback_id)
            if not feedback:
                return False, "Feedback not found."
                
            # Add response to feedback
            feedback.response = response
            feedback.updated_at = datetime.now()
            store.feedback[feedback_id] = feedback
            
            log_activity(0, f"Response added to feedback: {feedback_id}")
            return True, "Response added successfully."
            
        except Exception as e:
            logger.error(f"Adding feedback response error: {str(e)}")
            return False, f"An error occurred: {str(e)}"
            
    @staticmethod
    def update_feedback_status(feedback_id: int, status: str) -> tuple[bool, str]:
        """Update feedback status"""
        try:
            store = MemoryStore()
            
            # Get feedback
            feedback = store.get_feedback_by_id(feedback_id)
            if not feedback:
                return False, "Feedback not found."
                
            # Update status
            feedback.status = status
            feedback.updated_at = datetime.now()
            store.feedback[feedback_id] = feedback
            
            log_activity(0, f"Feedback status updated: {feedback_id} -> {status}")
            return True, "Feedback status updated successfully."
            
        except Exception as e:
            logger.error(f"Updating feedback status error: {str(e)}")
            return False, f"An error occurred: {str(e)}"
    
    @staticmethod
    def delete_feedback(feedback_id: int) -> tuple[bool, str]:
        """Delete feedback"""
        try:
            store = MemoryStore()
            
            # Get feedback
            feedback = store.get_feedback_by_id(feedback_id)
            if not feedback:
                return False, "Feedback not found."
            
            # Delete feedback
            if feedback_id in store.feedback:
                del store.feedback[feedback_id]
            
            log_activity(feedback.patient_id, f"Feedback deleted: {feedback_id}")
            return True, "Feedback deleted successfully."
            
        except Exception as e:
            logger.error(f"Feedback deletion error: {str(e)}")
            return False, f"An error occurred: {str(e)}"