"""
Appointment model
"""
from dataclasses import dataclass
from datetime import datetime
from enum import Enum, auto

class AppointmentStatus(Enum):
    """Status options for appointments"""
    SCHEDULED = auto()
    CONFIRMED = auto()
    COMPLETED = auto()
    CANCELLED = auto()

@dataclass
class Appointment:
    """Appointment model"""
    appointment_id: int
    patient_id: int
    doctor_id: int
    date: datetime
    status: AppointmentStatus
    reason: str = ""
    notes: str = ""