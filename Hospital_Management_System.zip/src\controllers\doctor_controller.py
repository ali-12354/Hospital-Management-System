"""
Doctor controller for managing doctor operations
"""
import logging
from datetime import datetime
from src.data.memory_store import MemoryStore, Doctor
from src.utils.helpers import validate_email, validate_phone, log_activity

# Configure logging
logger = logging.getLogger('doctor_controller')

class DoctorController:
    """Controller for doctor operations"""
    
    @staticmethod
    def create_doctor(username: str, password: str, first_name: str, last_name: str,
                    specialization: str, contact_number: str, email: str = None) -> tuple[bool, Doctor | str]:
        """Create a new doctor account"""
        try:
            store = MemoryStore()
            
            # Validate required fields
            if not all([username, password, first_name, last_name, specialization, contact_number]):
                return False, "All required fields must be filled."
            
            # Validate email if provided
            if email and not validate_email(email):
                return False, "Invalid email format."
            
            # Validate phone number
            if not validate_phone(contact_number):
                return False, "Invalid phone number format."
            
            # Create user
            user = store.create_user(username, password, role="doctor")
            if not user:
                return False, "Username already exists."
            
            # Create doctor profile
            doctor = store.create_doctor(
                user_id=user.user_id,
                first_name=first_name,
                last_name=last_name,
                specialization=specialization,
                contact=contact_number,
                email=email or ""
            )
            
            if not doctor:
                return False, "Failed to create doctor profile"
            
            log_activity(user.user_id, f"New doctor created: {doctor.doctor_id}")
            return True, doctor
                
        except Exception as e:
            logger.error(f"Doctor creation error: {str(e)}")
            return False, f"An error occurred: {str(e)}"
    
    @staticmethod
    def register_doctor(username: str, password: str, first_name: str, last_name: str,
                       gender: str, specialization: str, qualification: str,
                       contact_number: str, email: str = None,
                       consulting_hours: str = None, fees: float = 0.0) -> tuple[bool, Doctor | str]:
        """Register a new doctor"""
        try:
            store = MemoryStore()
            
            # Validate required fields
            if not all([username, password, first_name, last_name, gender, specialization, qualification, contact_number]):
                return False, "All required fields must be filled."
            
            # Validate email if provided
            if email and not validate_email(email):
                return False, "Invalid email format."
            
            # Validate phone number
            if not validate_phone(contact_number):
                return False, "Invalid phone number format."
            
            # Create user
            user = store.create_user(username, password, role="doctor")
            if not user:
                return False, "Username already exists."
            
            # Create doctor profile
            doctor = store.create_doctor(
                user_id=user.user_id,
                first_name=first_name,
                last_name=last_name,
                specialization=specialization,
                contact=contact_number,
                email=email or ""
            )
            
            if not doctor:
                return False, "Failed to create doctor profile"
            
            log_activity(user.user_id, f"New doctor registered: {doctor.doctor_id}")
            return True, doctor
                
        except Exception as e:
            logger.error(f"Doctor registration error: {str(e)}")
            return False, f"An error occurred: {str(e)}"
            
    @staticmethod
    def get_doctor_by_id(doctor_id: int) -> Doctor | None:
        """Get doctor by ID"""
        try:
            store = MemoryStore()
            return store.get_doctor_by_id(doctor_id)
        except Exception as e:
            logger.error(f"Error retrieving doctor: {str(e)}")
            return None
    
    @staticmethod
    def get_doctor_by_user_id(user_id: int) -> Doctor | None:
        """Get doctor by user ID"""
        try:
            store = MemoryStore()
            return store.get_doctor_by_user_id(user_id)
        except Exception as e:
            logger.error(f"Error retrieving doctor: {str(e)}")
            return None
    
    @staticmethod
    def get_all_doctors() -> list[Doctor]:
        """Get all doctors"""
        try:
            store = MemoryStore()
            return store.get_all_doctors()
        except Exception as e:
            logger.error(f"Error retrieving doctors: {str(e)}")
            return []
    
    @staticmethod
    def update_doctor(doctor_id: int, first_name: str = None, last_name: str = None,
                     gender: str = None, specialization: str = None,
                     qualification: str = None, contact_number: str = None,
                     email: str = None, consulting_hours: str = None,
                     fees: float = None) -> tuple[bool, Doctor | str]:
        """Update doctor information"""
        try:
            store = MemoryStore()
            
            # Get doctor
            doctor = store.get_doctor_by_id(doctor_id)
            if not doctor:
                return False, "Doctor not found."
            
            # Create updated doctor
            updated_doctor = Doctor(
                doctor_id=doctor.doctor_id,
                user_id=doctor.user_id,
                first_name=first_name if first_name else doctor.first_name,
                last_name=last_name if last_name else doctor.last_name,
                gender=gender if gender else doctor.gender,
                specialization=specialization if specialization else doctor.specialization,
                qualification=qualification if qualification else doctor.qualification,
                contact=contact_number if contact_number else doctor.contact,
                email=email if email else doctor.email,
                consulting_hours=consulting_hours if consulting_hours else doctor.consulting_hours,
                fees=fees if fees is not None else doctor.fees
            )
            
            # Validate updated fields
            if contact_number and not validate_phone(contact_number):
                return False, "Invalid phone number format."
                
            if email and not validate_email(email):
                return False, "Invalid email format."
            
            # Update in store
            store.doctors[doctor_id] = updated_doctor
            
            log_activity(doctor.user_id, f"Doctor profile updated: {doctor_id}")
            return True, updated_doctor
            
        except Exception as e:
            logger.error(f"Doctor update error: {str(e)}")
            return False, f"An error occurred: {str(e)}"
    
    @staticmethod
    def delete_doctor(doctor_id: int) -> bool:
        """Delete a doctor from the system
        
        Args:
            doctor_id: The ID of the doctor to delete
            
        Returns:
            True if successful, False otherwise
        """
        try:
            store = MemoryStore()
            
            # Check if doctor exists
            doctor = store.get_doctor_by_id(doctor_id)
            if not doctor:
                logger.warning(f"Attempted to delete non-existent doctor ID: {doctor_id}")
                return False
            
            # Delete doctor
            if doctor_id in store.doctors:
                # Delete associated user account
                if hasattr(doctor, 'user_id') and doctor.user_id in store.users:
                    del store.users[doctor.user_id]
                    logger.info(f"Deleted user account for doctor ID: {doctor_id}")
                
                # Delete the doctor
                del store.doctors[doctor_id]
                logger.info(f"Doctor deleted: {doctor_id}")
                return True
            else:
                return False
                
        except Exception as e:
            logger.error(f"Error deleting doctor {doctor_id}: {str(e)}")
            return False