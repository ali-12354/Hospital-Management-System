"""Admin report helpers.

Provides functions to run predefined administrative reports and export results.
This module uses the top-level `database.create_connection()` helper to connect
to the configured MySQL/XAMPP database. If you prefer SQLite, replace the
connection function accordingly.
"""
from typing import List, Tuple, Any
from datetime import datetime
from database import create_connection
from src.data.memory_store import MemoryStore
from src.controllers.billing_controller import BillingController
from src.data.memory_store import BillingStatus



def run_query(query: str, params: tuple = ()) -> Tuple[List[str], List[Tuple[Any, ...]]]:
    """Execute a query and return (columns, rows)."""
    conn = create_connection()
    if conn is None:
        raise RuntimeError("Could not connect to database")

    try:
        cursor = conn.cursor()
        cursor.execute(query, params)
        rows = cursor.fetchall()
        cols = [d[0] for d in cursor.description] if cursor.description else []
        return cols, rows
    finally:
        try:
            cursor.close()
        except Exception:
            pass
        try:
            if getattr(conn, 'is_connected', lambda: True)():
                conn.close()
        except Exception:
            pass


def get_appointments_report() -> Tuple[List[str], List[Tuple[Any, ...]]]:
    """Return the appointments report (scheduled appointments with patient/doctor).
    
    Uses MemoryStore as primary data source since that's where live data is stored.
    """
    cols = ["appointment_date", "appointment_time", "first_name", "last_name", "doctor_name", "status"]
    
    try:
        from src.data.memory_store import AppointmentStatus
        from datetime import date
        store = MemoryStore()
        # Filter for scheduled and completed appointments (not cancelled)
        appointments = [a for a in store.appointments.values() 
                       if a.status != AppointmentStatus.CANCELLED]
        
        rows = []
        for appt in appointments:
            patient = store.get_patient_by_id(appt.patient_id)
            doctor = store.get_doctor_by_id(appt.doctor_id)
            
            if patient and doctor:
                # Extract date and time from the datetime or date object
                if isinstance(appt.date, datetime):
                    appt_date = appt.date.strftime('%Y-%m-%d')
                    appt_time = appt.date.strftime('%H:%M')
                elif isinstance(appt.date, date):
                    appt_date = appt.date.strftime('%Y-%m-%d')
                    # Use time_slot if available
                    appt_time = appt.time_slot if hasattr(appt, 'time_slot') else "N/A"
                else:
                    appt_date = str(appt.date)
                    appt_time = "N/A"
                
                # Get status name
                if hasattr(appt.status, 'value'):
                    status_str = appt.status.value
                elif hasattr(appt.status, 'name'):
                    status_str = appt.status.name
                else:
                    status_str = str(appt.status)
                
                rows.append((
                    appt_date,
                    appt_time,
                    patient.first_name,
                    patient.last_name,
                    f"{doctor.first_name} {doctor.last_name}",
                    status_str
                ))
        
        return cols, rows
    except Exception as e:
        # If MemoryStore fails, return empty result
        print(f"Error in get_appointments_report: {e}")
        import traceback
        traceback.print_exc()
        return cols, []


def get_doctor_workload_report() -> Tuple[List[str], List[Tuple[Any, ...]]]:
    """Return the doctor workload report (appointments count per doctor).
    
    Uses MemoryStore as primary data source since that's where live data is stored.
    """
    cols = ["full_name", "specialization", "scheduled_appointments"]
    
    try:
        store = MemoryStore()
        doctor_counts = {}
        
        # Count appointments per doctor
        for appt in store.appointments.values():
            doctor_id = appt.doctor_id
            if doctor_id not in doctor_counts:
                doctor_counts[doctor_id] = 0
            doctor_counts[doctor_id] += 1
        
        # Build rows with doctor info
        rows = []
        for doctor in store.get_all_doctors():
            count = doctor_counts.get(doctor.doctor_id, 0)
            rows.append((
                f"{doctor.first_name} {doctor.last_name}",
                doctor.specialization,
                count
            ))
        
        # Sort by appointment count descending
        rows.sort(key=lambda x: x[2], reverse=True)
        
        return cols, rows
    except Exception as e:
        return cols, []


def export_to_csv(path: str, columns: List[str], rows: List[Tuple[Any, ...]]):
    """Export a result set to CSV."""
    import csv
    with open(path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        if columns:
            writer.writerow(columns)
        for r in rows:
            writer.writerow(r)


def get_patients_with_same_blood_group(blood_group: str) -> Tuple[List[str], List[Tuple[Any, ...]]]:
    """Return patients who share the same blood group (excluding duplicates).
    
    Uses MemoryStore as primary data source since that's where live data is stored.
    """
    cols = ["first_name", "last_name", "contact_number"]
    
    try:
        store = MemoryStore()
        all_patients = store.get_all_patients()
        
        # Find patients with matching blood group
        matching_patients = [p for p in all_patients if p.blood_group == blood_group]
        
        rows = []
        # For each patient, list OTHER patients with same blood group
        for patient in matching_patients:
            other_patients = [p for p in matching_patients if p.patient_id != patient.patient_id]
            if other_patients:  # Only add if there are other patients
                rows.append((
                    patient.first_name,
                    patient.last_name,
                    patient.contact
                ))
        
        return cols, rows
    except Exception:
        return cols, []


def get_all_patients_pending_bills() -> Tuple[List[str], List[Tuple[Any, ...]]]:
    """Return pending bills for ALL patients with patient details.
    
    Uses MemoryStore as primary data source since that's where live data is stored.
    """
    cols = ["patient_id", "first_name", "last_name", "contact", "billing_id", "amount", "bill_date", "status"]
    
    try:
        store = MemoryStore()
        all_patients = store.get_all_patients()
        
        result_rows = []
        for patient in all_patients:
            bills = store.get_billings_by_patient(patient.patient_id)
            
            if not bills:
                # Show patient even if no bills
                result_rows.append((
                    patient.patient_id,
                    patient.first_name,
                    patient.last_name,
                    patient.contact,
                    None,
                    0.0,
                    None,
                    "No Bills"
                ))
            else:
                for bill in bills:
                    # Check if pending
                    status = None
                    if isinstance(bill, dict):
                        status = bill.get('status') or bill.get('payment_status')
                    else:
                        status = getattr(bill, 'status', None)
                    
                    status_str = str(status).lower() if status else ""
                    if "pending" in status_str or not status:
                        bill_id = None
                        amount = 0.0
                        bill_date = None
                        
                        if isinstance(bill, dict):
                            bill_id = bill.get('billing_id') or bill.get('bill_id')
                            amount = bill.get('amount') or bill.get('total_amount') or 0.0
                            bill_date = bill.get('date') or bill.get('bill_date')
                        else:
                            bill_id = getattr(bill, 'billing_id', None)
                            amount = getattr(bill, 'amount', 0.0)
                            bill_date = getattr(bill, 'date', None)
                        
                        result_rows.append((
                            patient.patient_id,
                            patient.first_name,
                            patient.last_name,
                            patient.contact,
                            bill_id,
                            amount,
                            bill_date,
                            str(status) if status else "Pending"
                        ))
        
        return cols, result_rows
    except Exception as e:
        return cols, []


def get_patient_bills(patient_id: int) -> Tuple[List[str], List[Tuple[Any, ...]]]:
    """Return pending bills/invoices for a patient by calling a stored procedure.

    Expects a stored procedure named `GetPatientPendingInvoices` that accepts
    a single patient id parameter and returns a resultset of pending invoices.
    Returns (columns, rows) to match other report helpers.
    """
    query_proc = 'GetPatientPendingInvoices'

    conn = create_connection()
    cursor = None
    try:
        if conn is None:
            raise RuntimeError("Could not connect to database")

        cursor = conn.cursor()
        # Call the stored procedure
        cursor.callproc(query_proc, (patient_id,))

        cols: List[str] = []
        rows: List[Tuple[Any, ...]] = []

        # Fetch results from stored_results()
        for result in cursor.stored_results():
            if not cols and getattr(result, 'description', None):
                cols = [d[0] for d in result.description]
            fetched = result.fetchall()
            if fetched:
                rows.extend(fetched)

        return cols, rows
    except Exception as e:
        # If the stored procedure fails (example: unknown column in proc),
        # fall back to the in-memory store so UI still shows useful data.
        try:
            store = MemoryStore()
            bills = store.get_billings_by_patient(patient_id)

            # Normalize to (columns, rows)
            if not bills:
                return ["bill_id", "appointment_id", "amount", "description", "status", "date"], []

            # If bills are dataclass objects, extract attributes; if dicts, use keys
            sample = bills[0]
            if isinstance(sample, dict):
                cols = list(sample.keys())
                rows = [tuple(b.get(c) for c in cols) for b in bills]
            else:
                # dataclass Billing defined in memory_store has fields billing_id, appointment_id, amount, description, status, date
                cols = ["billing_id", "appointment_id", "amount", "description", "status", "date"]
                rows = [(
                    getattr(b, 'billing_id', None),
                    getattr(b, 'appointment_id', None),
                    getattr(b, 'amount', None),
                    getattr(b, 'description', None),
                    getattr(getattr(b, 'status', None), 'name', getattr(b, 'status', None)),
                    getattr(b, 'date', None)
                ) for b in bills]

            return cols, rows
        except Exception:
            # Re-raise original error if fallback also fails
            raise
    finally:
        try:
            if cursor:
                cursor.close()
        except Exception:
            pass
        try:
            if conn and getattr(conn, 'is_connected', lambda: True)():
                conn.close()
        except Exception:
            pass


def get_patient_balance(patient_id: int) -> float:
    """Return the patient's total balance.

    Tries to call the database function `GetPatientTotalBalance(patient_id)` via
    a SELECT. If the DB call fails (missing function, SQL error, etc.), falls
    back to summing pending bills in the in-memory `MemoryStore`.
    Returns a float (0.0 if no balance found).
    """
    conn = None
    cursor = None
    try:
        conn = create_connection()
        if conn is None:
            raise RuntimeError("Could not connect to database")

        cursor = conn.cursor()
        # Call function using SELECT; parameter style matches mysql-connector
        cursor.execute("SELECT GetPatientTotalBalance(%s)", (patient_id,))
        row = cursor.fetchone()
        balance = row[0] if row and len(row) > 0 else 0.0
        try:
            return float(balance) if balance is not None else 0.0
        except Exception:
            return 0.0
    except Exception:
        # Fallback to in-memory calculation
        try:
            store = MemoryStore()
            bills = store.get_billings_by_patient(patient_id)
            total = 0.0
            for b in bills:
                # get amount
                if isinstance(b, dict):
                    amt = b.get('total_amount') or b.get('amount') or 0
                    status = b.get('payment_status') or b.get('status') or ''
                else:
                    amt = getattr(b, 'amount', 0)
                    st = getattr(b, 'status', None)
                    # status may be an Enum or string
                    status = getattr(st, 'value', None) or getattr(st, 'name', None) or str(st)

                try:
                    is_pending = str(status).lower() == 'pending'
                except Exception:
                    is_pending = False

                try:
                    val = float(amt)
                except Exception:
                    val = 0.0

                if is_pending:
                    total += val

            return total
        except Exception:
            # Last resort: return 0.0
            return 0.0
    finally:
        try:
            if cursor:
                cursor.close()
        except Exception:
            pass


def mark_bill_as_paid(invoice_id: int) -> bool:
    """Mark a bill/invoice as paid.

    Tries an UPDATE against the DB table `Invoices`. If that fails, falls back
    to the application MemoryStore via BillingController.update_bill_status.
    Returns True on success, False on failure.
    """
    conn = None
    cursor = None
    try:
        conn = create_connection()
        if conn is None:
            raise RuntimeError("Could not connect to database")

        cursor = conn.cursor()
        query = "UPDATE Invoices SET status = 'Paid' WHERE invoice_id = %s"
        cursor.execute(query, (invoice_id,))
        conn.commit()
        return True
    except Exception:
        # Fallback to application memory store
        try:
            # Use the BillingController to update status in-memory
            success, _ = BillingController.update_bill_status(invoice_id, BillingStatus.PAID)
            return bool(success)
        except Exception:
            return False
    finally:
        try:
            if cursor:
                cursor.close()
        except Exception:
            pass
        try:
            if conn and getattr(conn, 'is_connected', lambda: True)():
                conn.close()
        except Exception:
            pass
        try:
            if conn and getattr(conn, 'is_connected', lambda: True)():
                conn.close()
        except Exception:
            pass
