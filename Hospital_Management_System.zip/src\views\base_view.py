"""
Base view module with common functions
"""
import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox, filedialog, ttk
import os
import logging
from src.utils.helpers import show_message
from datetime import datetime
from tkcalendar import Calendar
from PIL import Image

# Configure logging
logger = logging.getLogger('views')

# Note: Appearance mode and theme are set in main.py

class BaseView(ctk.CTk):
    """Base class for all views"""
    
    def __init__(self, title="Hospital Management System", width=1024, height=768):
        """
        Initialize the base view
        
        Args:
            title (str): Window title
            width (int): Window width
            height (int): Window height
        """
        super().__init__()
        
        # Set window properties
        self.title(title)
        self.geometry(f"{width}x{height}")
        self.center_on_screen()
        
        # Create a container frame to center content vertically
        self.container_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.container_frame.pack(fill=tk.BOTH, expand=True)
        
        # Add weight to rows to center content
        self.container_frame.grid_rowconfigure(0, weight=1)  # Top empty space
        self.container_frame.grid_rowconfigure(1, weight=2)  # Content area (larger weight)
        self.container_frame.grid_rowconfigure(2, weight=1)  # Bottom empty space
        self.container_frame.grid_columnconfigure(0, weight=1)
        
        # Create main frame centered vertically
        self.main_frame = ctk.CTkFrame(self.container_frame)
        self.main_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        
        # Create status bar
        self.status_bar = ctk.CTkLabel(self, text="Ready", anchor=tk.W)
        self.status_bar.pack(fill=tk.X, side=tk.BOTTOM, padx=10, pady=5)
    
    def center_on_screen(self):
        """Center the window on screen"""
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        x = (screen_width - self.winfo_width()) // 2
        y = (screen_height - self.winfo_height()) // 2
        self.geometry(f"+{x}+{y}")
    
    def set_status(self, message, timeout=5000):
        """
        Set status bar message
        
        Args:
            message (str): Message to display
            timeout (int): Message display time in milliseconds
        """
        self.status_bar.configure(text=message)
        if timeout:
            self.after(timeout, lambda: self.status_bar.configure(text="Ready"))
    
    def create_scrollable_frame(self):
        """
        Create a scrollable frame
        
        Returns:
            CTkScrollableFrame: Scrollable frame object
        """
        return ctk.CTkScrollableFrame(self.main_frame)
    
    def create_header_label(self, text, master=None):
        """
        Create a header label
        
        Args:
            text (str): Label text
            master: Parent widget
            
        Returns:
            CTkLabel: Header label
        """
        return ctk.CTkLabel(
            master or self.main_frame,
            text=text,
            font=ctk.CTkFont(size=20, weight="bold")
        )
    
    def create_sub_header_label(self, text, master=None):
        """
        Create a sub-header label
        
        Args:
            text (str): Label text
            master: Parent widget
            
        Returns:
            CTkLabel: Sub-header label
        """
        return ctk.CTkLabel(
            master or self.main_frame,
            text=text,
            font=ctk.CTkFont(size=16, weight="bold")
        )
    
    def create_primary_button(self, text, on_click=None, master=None):
        """
        Create a primary action button
        
        Args:
            text (str): Button text
            on_click (callable, optional): Button click handler
            master: Parent widget
            
        Returns:
            CTkButton: Button object
        """
        button = ctk.CTkButton(
            master or self.main_frame,
            text=text,
            command=on_click if on_click else lambda: None
        )
        return button
    
    def create_secondary_button(self, text, on_click=None, master=None):
        """
        Create a secondary action button
        
        Args:
            text (str): Button text
            on_click (callable, optional): Button click handler
            master: Parent widget
            
        Returns:
            CTkButton: Button object
        """
        button = ctk.CTkButton(
            master or self.main_frame,
            text=text,
            command=on_click if on_click else lambda: None,
            fg_color="transparent",
            border_width=2
        )
        return button
    
    def create_danger_button(self, text, on_click=None, master=None):
        """
        Create a danger action button
        
        Args:
            text (str): Button text
            on_click (callable, optional): Button click handler
            master: Parent widget
            
        Returns:
            CTkButton: Button object
        """
        button = ctk.CTkButton(
            master or self.main_frame,
            text=text,
            command=on_click if on_click else lambda: None,
            fg_color="red",
            hover_color="darkred"
        )
        return button
    
    def create_input_field(self, placeholder=None, default_value=None, read_only=False, master=None):
        """
        Create an input field
        
        Args:
            placeholder (str, optional): Placeholder text
            default_value (str, optional): Default value
            read_only (bool): Whether the field is read-only
            master: Parent widget
            
        Returns:
            CTkEntry: Input field object
        """
        field = ctk.CTkEntry(
            master or self.main_frame,
            placeholder_text=placeholder if placeholder else ""
        )
        
        if default_value:
            field.insert(0, default_value)
            
        if read_only:
            field.configure(state="readonly")
            
        return field
    
    def create_dropdown(self, items=None, default_index=0, on_change=None, master=None):
        """
        Create a dropdown field
        
        Args:
            items (list, optional): Dropdown items
            default_index (int): Default selected index
            on_change (callable, optional): Selection change handler
            master: Parent widget
            
        Returns:
            CTkComboBox: Dropdown object
        """
        items = items or []
        dropdown = ctk.CTkComboBox(
            master or self.main_frame,
            values=items,
            command=on_change if on_change else lambda x: None
        )
        
        if items and default_index < len(items):
            dropdown.set(items[default_index])
            
        return dropdown
    
    def create_date_picker(self, default_date=None, min_date=None, max_date=None, on_change=None, master=None):
        """
        Create a date picker
        
        Args:
            default_date (datetime, optional): Default date
            min_date (datetime, optional): Minimum allowed date
            max_date (datetime, optional): Maximum allowed date
            on_change (callable, optional): Date change handler
            master: Parent widget
            
        Returns:
            Calendar: Date picker object
        """
        top = tk.Toplevel(master or self.main_frame)
        cal = Calendar(top, 
                      selectmode='day',
                      date_pattern='mm/dd/yyyy',
                      mindate=min_date,
                      maxdate=max_date)
        cal.pack(padx=10, pady=10)
        
        if default_date:
            cal.selection_set(default_date)
            
        if on_change:
            cal.bind('<<CalendarSelected>>', lambda e: on_change(cal.get_date()))
            
        return cal
    
    def create_text_area(self, placeholder=None, default_text=None, read_only=False, master=None):
        """
        Create a multi-line text area
        
        Args:
            placeholder (str, optional): Placeholder text
            default_text (str, optional): Default text
            read_only (bool): Whether the field is read-only
            master: Parent widget
            
        Returns:
            CTkTextbox: Text area object
        """
        text_area = ctk.CTkTextbox(master or self.main_frame)
        
        if default_text:
            text_area.insert("1.0", default_text)
            
        if read_only:
            text_area.configure(state="disabled")
            
        return text_area
    
    def create_table(self, columns, data=None, on_select=None, master=None):
        """
        Create a data table using Treeview
        
        Args:
            columns (list): Column headers
            data (list, optional): Table data
            on_select (callable, optional): Row selection handler
            master: Parent widget
            
        Returns:
            ttk.Treeview: Table object
        """
        table = ttk.Treeview(
            master or self.main_frame,
            columns=columns,
            show='headings'
        )
        
        # Set column headings
        for col in columns:
            table.heading(col, text=col)
            table.column(col, width=100)  # Default width
            
        # Add data if provided
        if data:
            for row in data:
                table.insert('', tk.END, values=row)
                
        if on_select:
            table.bind('<<TreeviewSelect>>', 
                      lambda e: on_select(table.selection()))
            
        return table
    
    def create_tabs(self, master=None):
        """
        Create a tab widget
        
        Args:
            master: Parent widget
            
        Returns:
            CTkTabview: Tab widget object
        """
        return ctk.CTkTabview(master or self.main_frame)
    
    def create_number_input(self, minimum=0, maximum=999999, default=0, master=None):
        """
        Create a numeric input field
        
        Args:
            minimum (int/float): Minimum value
            maximum (int/float): Maximum value
            default (int/float): Default value
            master: Parent widget
            
        Returns:
            CTkEntry with validation
        """
        var = tk.StringVar(value=str(default))
        
        def validate(value):
            if value == "": return True
            try:
                val = float(value)
                return minimum <= val <= maximum
            except ValueError:
                return False
        
        entry = ctk.CTkEntry(
            master or self.main_frame,
            textvariable=var
        )
        
        vcmd = self.register(validate)
        entry.configure(validate='key', 
                       validatecommand=(vcmd, '%P'))
        
        return entry
    
    def show_error(self, title, message):
        """
        Show an error message box
        
        Args:
            title (str): Error title
            message (str): Error message
        """
        messagebox.showerror(title, message)
    
    def show_info(self, title, message):
        """
        Show an information message box
        
        Args:
            title (str): Info title
            message (str): Info message
        """
        messagebox.showinfo(title, message)
    
    def show_warning(self, title, message):
        """
        Show a warning message box
        
        Args:
            title (str): Warning title
            message (str): Warning message
        """
        messagebox.showwarning(title, message)
    
    def show_confirm(self, title, message):
        """
        Show a confirmation dialog
        
        Args:
            title (str): Dialog title
            message (str): Dialog message
            
        Returns:
            bool: True if confirmed, False otherwise
        """
        return messagebox.askyesno(title, message)
    
    def show_save_file_dialog(self, title, filetypes=(("All Files", "*.*"),)):
        """
        Show a save file dialog
        
        Args:
            title (str): Dialog title
            filetypes (tuple): File type filters
            
        Returns:
            str: Selected file path or empty string if canceled
        """
        return filedialog.asksaveasfilename(
            title=title,
            filetypes=filetypes
        )
    
    def quit(self):
        """Handle window close"""
        if hasattr(self, 'on_close'):
            self.on_close()
        self.destroy()