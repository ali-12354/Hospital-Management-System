"""
Billing model
"""
from dataclasses import dataclass
from datetime import datetime
from enum import Enum, auto

class BillingStatus(Enum):
    """Status options for billings"""
    PENDING = auto()
    PAID = auto()
    VOID = auto()

@dataclass
class Billing:
    """Billing model"""
    billing_id: int
    appointment_id: int
    amount: float
    status: BillingStatus
    created_at: datetime
    description: str = ""