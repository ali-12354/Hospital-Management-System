"""
User model for authentication
"""
from dataclasses import dataclass
from datetime import datetime

@dataclass
class User:
    """User model for authentication"""
    user_id: int
    username: str
    password: str  # Stored as hash
    role: str
    created_at: datetime = None
    last_login: datetime = None
    
    def __post_init__(self):
        """Initialize default values"""
        if self.created_at is None:
            self.created_at = datetime.now()
        if self.last_login is None:
            self.last_login = None