"""
Admin dashboard view module
"""
import os
import sys
import customtkinter as ctk
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime, date
from PIL import Image, ImageTk
from tkcalendar import DateEntry
from src.views.base_view import BaseView
from src.controllers.auth_controller import AuthController
from src.controllers.doctor_controller import DoctorController
from src.controllers.patient_controller import PatientController
from src.controllers.appointment_controller import AppointmentController
from src.controllers.billing_controller import BillingController
from src.controllers.feedback_controller import FeedbackController
from src.data.memory_store import MemoryStore
from database import create_connection

class DoctorManagementFrame(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        
        # Create header
        self.header = ctk.CTkLabel(
            self,
            text="Doctor Management",
            font=ctk.CTkFont(size=20, weight="bold")
        )
        self.header.pack(pady=10)
        
        # Create controls
        controls_frame = ctk.CTkFrame(self)
        controls_frame.pack(fill=tk.X, padx=10, pady=5)
        
        self.add_button = ctk.CTkButton(
            controls_frame,
            text="Add New Doctor",
            command=self.add_doctor
        )
        self.add_button.pack(side=tk.LEFT, padx=5)
        
        self.refresh_button = ctk.CTkButton(
            controls_frame,
            text="Refresh",
            fg_color="transparent",
            border_width=2,
            command=self.load_doctors
        )
        self.refresh_button.pack(side=tk.LEFT, padx=5)
        
        # Create table
        self.create_table()
        self.load_doctors()
    
    def create_table(self):
        columns = ("ID", "Name", "Specialization", "Contact", "Email", "Status", "Actions")
        self.table = ttk.Treeview(self, columns=columns, show="headings")
        
        # Configure columns
        for col in columns:
            self.table.heading(col, text=col)
            self.table.column(col, width=100)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(self, orient=tk.VERTICAL, command=self.table.yview)
        self.table.configure(yscrollcommand=scrollbar.set)
        
        # Pack table and scrollbar
        self.table.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=5)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Bind events
        self.table.bind("<Double-1>", self.on_doctor_select)
    
    def load_doctors(self):
        # Clear existing items
        for item in self.table.get_children():
            self.table.delete(item)
        
        # Get all doctors
        doctors = DoctorController.get_all_doctors()
        
        if not doctors:
            messagebox.showinfo("No Data", "No doctors found in the system.")
            return
            
        for doctor in doctors:
            # Fix: properly format the doctor's name and use correct field names
            full_name = f"{doctor.first_name} {doctor.last_name}"
            try:
                self.table.insert("", tk.END, values=(
                    doctor.doctor_id,
                    full_name,
                    doctor.specialization,
                    doctor.contact,  # Fix: use proper field name
                    doctor.email or "",
                    "Active",  # Assume all doctors are active for now
                    "Edit | Delete"
                ))
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load doctor data: {str(e)}")
                print(f"Doctor data error: {str(doctor)}, Error: {str(e)}")
    
    def add_doctor(self):
        print("Creating new doctor...")
        dialog = DoctorDialog(self)
        dialog.transient(self)  # Make the dialog transient to parent
        dialog.grab_set()       # Make the dialog modal
        dialog.focus_force()    # Force focus on the dialog
        self.wait_window(dialog)
        print("Doctor dialog closed, refreshing doctor list")
        self.load_doctors()
    
    def on_doctor_select(self, event):
        try:
            item = self.table.selection()[0]
            values = self.table.item(item)["values"]
            doctor_id = values[0]
            
            # Determine if edit or delete was clicked based on the click position
            clicked_column = self.table.identify_column(event.x)
            col_idx = int(clicked_column.replace('#', '')) - 1
            
            if col_idx == 6:  # Actions column
                x_relative = event.x - self.table.winfo_rootx()
                # Assuming the button width is about 50 pixels
                if x_relative > 75:  # Delete button area
                    self.delete_doctor(doctor_id)
                else:  # Edit button area
                    self.edit_doctor(doctor_id)
            else:
                # Default to edit if they clicked elsewhere on the row
                self.edit_doctor(doctor_id)
        except Exception as e:
            messagebox.showerror("Error", f"Error processing selection: {str(e)}")
    
    def edit_doctor(self, doctor_id):
        doctor = DoctorController.get_doctor_by_id(doctor_id)
        if doctor:
            print(f"Editing doctor: {doctor_id}")
            dialog = DoctorDialog(self, doctor)
            dialog.transient(self)  # Make the dialog transient to parent
            dialog.grab_set()       # Make the dialog modal
            dialog.focus_force()    # Force focus on the dialog
            self.wait_window(dialog)
            print("Doctor edit dialog closed, refreshing doctor list")
            self.load_doctors()
            
    def delete_doctor(self, doctor_id):
        doctor = DoctorController.get_doctor_by_id(doctor_id)
        if not doctor:
            messagebox.showerror("Error", "Doctor not found")
            return
            
        # Confirm deletion
        response = messagebox.askyesno(
            "Confirm Delete",
            f"Are you sure you want to delete Dr. {doctor.first_name} {doctor.last_name}?\n\nThis action cannot be undone."
        )
        
        if response:
            # Attempt to delete
            try:
                success = DoctorController.delete_doctor(doctor_id)
                if success:
                    messagebox.showinfo("Success", f"Doctor {doctor.first_name} {doctor.last_name} deleted successfully")
                    self.load_doctors()
                else:
                    messagebox.showerror("Error", "Failed to delete doctor")
            except Exception as e:
                messagebox.showerror("Error", f"Error deleting doctor: {str(e)}")

class DoctorDialog(ctk.CTkToplevel):
    def __init__(self, parent, doctor=None):
        super().__init__(parent)
        self.doctor = doctor
        self.title("Edit Doctor" if doctor else "Add Doctor")
        self.geometry("500x600")
        
        # Make dialog modal and centered on parent
        self.transient(parent)
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        self.focus_force()
        
        # Create main frame
        self.main_frame = ctk.CTkFrame(self)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create header
        self.header = ctk.CTkLabel(
            self.main_frame,
            text="Edit Doctor" if doctor else "Add New Doctor",
            font=ctk.CTkFont(size=20, weight="bold")
        )
        self.header.pack(pady=10)
        
        # Create form
        self.create_form()
        
        # Create buttons
        self.create_buttons()
    
    def create_form(self):
        form_frame = ctk.CTkFrame(self.main_frame)
        form_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Username (for new doctors only)
        if not self.doctor:
            ctk.CTkLabel(form_frame, text="Username:").pack(anchor=tk.W, padx=5, pady=2)
            self.username_field = ctk.CTkEntry(form_frame)
            self.username_field.pack(fill=tk.X, padx=5, pady=5)
            
            # Password
            ctk.CTkLabel(form_frame, text="Password:").pack(anchor=tk.W, padx=5, pady=2)
            self.password_field = ctk.CTkEntry(form_frame, show="•")
            self.password_field.pack(fill=tk.X, padx=5, pady=5)
        
        # First name
        ctk.CTkLabel(form_frame, text="First Name:").pack(anchor=tk.W, padx=5, pady=2)
        self.first_name_field = ctk.CTkEntry(form_frame)
        if self.doctor:
            self.first_name_field.insert(0, self.doctor.first_name)
        self.first_name_field.pack(fill=tk.X, padx=5, pady=5)
        
        # Last name
        ctk.CTkLabel(form_frame, text="Last Name:").pack(anchor=tk.W, padx=5, pady=2)
        self.last_name_field = ctk.CTkEntry(form_frame)
        if self.doctor:
            self.last_name_field.insert(0, self.doctor.last_name)
        self.last_name_field.pack(fill=tk.X, padx=5, pady=5)
        
        # Specialization
        ctk.CTkLabel(form_frame, text="Specialization:").pack(anchor=tk.W, padx=5, pady=2)
        self.specialization_field = ctk.CTkEntry(form_frame)
        if self.doctor:
            self.specialization_field.insert(0, self.doctor.specialization)
        self.specialization_field.pack(fill=tk.X, padx=5, pady=5)
        
        # Contact
        ctk.CTkLabel(form_frame, text="Contact:").pack(anchor=tk.W, padx=5, pady=2)
        self.contact_field = ctk.CTkEntry(form_frame)
        if self.doctor:
            self.contact_field.insert(0, self.doctor.contact_number)
        self.contact_field.pack(fill=tk.X, padx=5, pady=5)
        
        # Email
        ctk.CTkLabel(form_frame, text="Email:").pack(anchor=tk.W, padx=5, pady=2)
        self.email_field = ctk.CTkEntry(form_frame)
        if self.doctor and self.doctor.email:
            self.email_field.insert(0, self.doctor.email)
        self.email_field.pack(fill=tk.X, padx=5, pady=5)
        
        # Status
        if self.doctor:
            ctk.CTkLabel(form_frame, text="Status:").pack(anchor=tk.W, padx=5, pady=2)
            self.status_var = tk.StringVar(value="active" if self.doctor.is_active else "inactive")
            status_frame = ctk.CTkFrame(form_frame)
            status_frame.pack(fill=tk.X, padx=5, pady=5)
            
            self.status_active = ctk.CTkRadioButton(
                status_frame, text="Active", variable=self.status_var, value="active"
            )
            self.status_inactive = ctk.CTkRadioButton(
                status_frame, text="Inactive", variable=self.status_var, value="inactive"
            )
            
            self.status_active.pack(side=tk.LEFT, padx=5)
            self.status_inactive.pack(side=tk.LEFT, padx=5)
    
    def create_buttons(self):
        button_frame = ctk.CTkFrame(self.main_frame)
        button_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.save_button = ctk.CTkButton(
            button_frame,
            text="Save",
            command=self.save_doctor
        )
        self.save_button.pack(side=tk.LEFT, expand=True, padx=5)
        
        self.cancel_button = ctk.CTkButton(
            button_frame,
            text="Cancel",
            fg_color="transparent",
            border_width=2,
            command=self.destroy
        )
        self.cancel_button.pack(side=tk.LEFT, expand=True, padx=5)
    
    def save_doctor(self):
        from src.utils.helpers import validate_email, validate_phone, validate_password_strength
        
        # Get form values
        first_name = self.first_name_field.get().strip()
        last_name = self.last_name_field.get().strip()
        specialization = self.specialization_field.get().strip()
        contact = self.contact_field.get().strip()
        email = self.email_field.get().strip()
        
        # Validate inputs
        if not first_name or not last_name:
            tk.messagebox.showwarning("Error", "First name and last name are required.")
            return
        
        if not specialization:
            tk.messagebox.showwarning("Error", "Specialization is required.")
            return
        
        if not contact:
            tk.messagebox.showwarning("Error", "Contact number is required.")
            return
        
        if not validate_phone(contact):
            tk.messagebox.showwarning("Error", "Invalid contact number format.")
            return
        
        if email and not validate_email(email):
            tk.messagebox.showwarning("Error", "Invalid email format.")
            return
        
        if self.doctor:
            # Update existing doctor
            is_active = self.status_var.get() == "active"
            # Fix: update proper fields 
            success, result = DoctorController.update_doctor(
                self.doctor.doctor_id, 
                first_name=first_name, 
                last_name=last_name, 
                specialization=specialization,
                contact_number=contact, 
                email=email
            )
        else:
            # Create new doctor
            username = self.username_field.get().strip()
            password = self.password_field.get()
            
            if not username or len(username) < 4:
                tk.messagebox.showwarning("Error", "Username must be at least 4 characters.")
                return
            
            if not password:
                tk.messagebox.showwarning("Error", "Password is required.")
                return
            
            if not validate_password_strength(password):
                tk.messagebox.showwarning(
                    "Error",
                    "Password must be at least 8 characters with at least one letter, "
                    "one number, and one special character."
                )
                return
            
            success, result = DoctorController.create_doctor(
                username, password, first_name, last_name, specialization,
                contact, email
            )
        
        if success:
            tk.messagebox.showinfo("Success", "Doctor saved successfully!")
            self.destroy()
        else:
            tk.messagebox.showwarning("Error", str(result))

class AdminView(BaseView):
    """Admin dashboard view implementation"""
    
    def __init__(self, user):
        """Initialize admin dashboard"""
        super().__init__(f"Hospital Management System - Admin Dashboard", 1200, 800)
        self.user = user
        
        # The main_frame is now created and centered in BaseView
        
        # Create header
        self.create_header()
        
        # Create navigation and content area
        self.create_nav_and_content()
        
        # Set default view
        self.show_doctors()
    
    def create_header(self):
        """Create the header area"""
        header_frame = ctk.CTkFrame(self.main_frame)
        header_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # Welcome label
        welcome_label = ctk.CTkLabel(
            header_frame,
            text=f"Welcome, Administrator",
            font=ctk.CTkFont(size=20, weight="bold")
        )
        welcome_label.pack(side=tk.LEFT, padx=10)
        
        # Logout button
        self.logout_button = ctk.CTkButton(
            header_frame,
            text="Logout",
            fg_color="transparent",
            border_width=2,
            command=self.logout
        )
        self.logout_button.pack(side=tk.RIGHT, padx=10)
    
    def create_nav_and_content(self):
        """Create navigation and content area"""
        # Create container for nav and content
        container = ctk.CTkFrame(self.main_frame)
        container.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Create navigation frame
        nav_frame = ctk.CTkFrame(container, width=200)
        nav_frame.pack(side=tk.LEFT, fill=tk.Y, padx=5, pady=5)
        nav_frame.pack_propagate(False)  # Prevent shrinking
        
        # Create navigation buttons
        self.create_nav_buttons(nav_frame)
        
        # Create content frame
        self.content_frame = ctk.CTkFrame(container)
        self.content_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
    
    def create_nav_buttons(self, frame):
        """Create navigation buttons"""
        buttons = [
            ("Doctors", self.show_doctors),
            ("Patients", self.show_patients),
            ("Appointments", self.show_appointments),
            ("Billing", self.show_billing),
            ("Feedback", self.show_feedback),
            ("Reports", self.show_reports)
        ]
        
        for text, command in buttons:
            btn = ctk.CTkButton(
                frame,
                text=text,
                fg_color="transparent",
                border_width=2,
                command=command
            )
            btn.pack(fill=tk.X, padx=5, pady=2)
    
    def clear_content(self):
        """Clear the content frame"""
        for widget in self.content_frame.winfo_children():
            widget.destroy()
    
    def show_doctors(self):
        """Show doctor management view"""
        self.clear_content()
        doctors_frame = DoctorManagementFrame(self.content_frame)
        doctors_frame.pack(fill=tk.BOTH, expand=True)
    
    def show_patients(self):
        """Show patient management view"""
        self.clear_content()
        patients_frame = PatientManagementFrame(self.content_frame)
        patients_frame.pack(fill=tk.BOTH, expand=True)
    
    def show_appointments(self):
        """Show appointment management view"""
        self.clear_content()
        appointments_frame = AppointmentManagementFrame(self.content_frame)
        appointments_frame.pack(fill=tk.BOTH, expand=True)
    
    def show_billing(self):
        """Show billing management view"""
        self.clear_content()
        billing_frame = BillingManagementFrame(self.content_frame)
        billing_frame.pack(fill=tk.BOTH, expand=True)
    
    def show_feedback(self):
        """Show feedback management view"""
        self.clear_content()
        feedback_frame = FeedbackManagementFrame(self.content_frame)
        feedback_frame.pack(fill=tk.BOTH, expand=True)

    def show_reports(self):
        """Show reports view"""
        self.clear_content()
        reports_frame = ReportsManagementFrame(self.content_frame)
        reports_frame.pack(fill=tk.BOTH, expand=True)
    
    def logout(self, *args):
        """Handle logout button click"""
        from src.views.login_view import LoginView
        import tkinter as tk
        
        # Confirm logout
        if not tk.messagebox.askyesno("Logout", "Are you sure you want to logout?"):
            return
        
        # Log out user
        AuthController.logout(self.user.user_id)
        
        # Close admin view
        self.destroy()  # Destroy admin window completely
        
        # Show login view in a new instance
        login_view = LoginView()
        login_view.focus()
        login_view.mainloop()  # Ensure the login view's event loop starts

class PatientManagementFrame(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        
        # Create header
        self.header = ctk.CTkLabel(
            self,
            text="Patient Management",
            font=ctk.CTkFont(size=20, weight="bold")
        )
        self.header.pack(pady=10)
        
        # Create controls
        controls_frame = ctk.CTkFrame(self)
        controls_frame.pack(fill=tk.X, padx=10, pady=5)
        
        self.search_entry = ctk.CTkEntry(
            controls_frame,
            placeholder_text="Search by name or ID..."
        )
        self.search_entry.pack(side=tk.LEFT, padx=5)
        
        self.search_button = ctk.CTkButton(
            controls_frame,
            text="Search",
            command=self.search_patients
        )
        self.search_button.pack(side=tk.LEFT, padx=5)
        
        self.refresh_button = ctk.CTkButton(
            controls_frame,
            text="Refresh",
            fg_color="transparent",
            border_width=2,
            command=self.load_patients
        )
        self.refresh_button.pack(side=tk.LEFT, padx=5)
        
        # Create table
        self.create_table()
        self.load_patients()
    
    def create_table(self):
        columns = ("ID", "Name", "Gender", "Contact", "Email", "Blood Group", "Actions")
        self.table = ttk.Treeview(self, columns=columns, show="headings")
        
        # Configure columns
        for col in columns:
            self.table.heading(col, text=col)
            self.table.column(col, width=100)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(self, orient=tk.VERTICAL, command=self.table.yview)
        self.table.configure(yscrollcommand=scrollbar.set)
        
        # Pack table and scrollbar
        self.table.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=5)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Bind events
        self.table.bind("<Double-1>", self.on_patient_select)
    
    def load_patients(self):
        # Clear existing items
        for item in self.table.get_children():
            self.table.delete(item)
        
        # Get all patients
        patients = PatientController.get_all_patients()
        
        # Debugging - print patients count
        print(f"Patients found: {len(patients)}")
        
        for patient in patients:
            try:
                # Use the correct field name 'contact' instead of 'contact_number'
                self.table.insert("", tk.END, values=(
                    patient.patient_id,
                    f"{patient.first_name} {patient.last_name}",
                    patient.gender,
                    patient.contact,  # Changed from contact_number to contact
                    patient.email or "",
                    patient.blood_group or "Not specified",
                    "View | Delete"
                ))
            except Exception as e:
                print(f"Error adding patient to table: {e}")
                print(f"Patient data: {patient.__dict__}")
    
    def search_patients(self):
        search_term = self.search_entry.get().strip().lower()
        if not search_term:
            self.load_patients()
            return
        
        # Clear existing items
        for item in self.table.get_children():
            self.table.delete(item)
        
        # Get all patients and filter
        patients = PatientController.get_all_patients()
        
        for patient in patients:
            try:
                full_name = f"{patient.first_name} {patient.last_name}".lower()
                if (search_term in full_name or 
                    search_term in str(patient.patient_id) or
                    search_term in patient.contact.lower()):  # Changed contact_number to contact
                    self.table.insert("", tk.END, values=(
                        patient.patient_id,
                        f"{patient.first_name} {patient.last_name}",
                        patient.gender,
                        patient.contact,  # Changed from contact_number to contact
                        patient.email or "",
                        patient.blood_group or "Not specified",
                        "View | Delete"
                    ))
            except Exception as e:
                print(f"Error filtering patient: {e}")
    
    def on_patient_select(self, event):
        try:
            item = self.table.selection()[0]
            values = self.table.item(item)["values"]
            patient_id = values[0]
            
            # Determine if view or delete was clicked based on the click position
            clicked_column = self.table.identify_column(event.x)
            col_idx = int(clicked_column.replace('#', '')) - 1
            
            if col_idx == 6:  # Actions column
                x_relative = event.x - self.table.winfo_rootx()
                # If they clicked the right side of the actions cell (delete button area)
                if x_relative > 75:  # Delete button area
                    self.delete_patient(patient_id)
                else:  # View button area
                    self.view_patient_details(patient_id)
            else:
                # Default to view details if they clicked elsewhere on the row
                self.view_patient_details(patient_id)
        except Exception as e:
            messagebox.showerror("Error", f"Error processing selection: {str(e)}")
    
    def view_patient_details(self, patient_id):
        patient = PatientController.get_patient_by_id(patient_id)
        if patient:
            dialog = PatientDetailsDialog(self, patient)
            dialog.focus()
            
    def delete_patient(self, patient_id):
        patient = PatientController.get_patient_by_id(patient_id)
        if not patient:
            messagebox.showerror("Error", "Patient not found")
            return
            
        # Confirm deletion
        response = messagebox.askyesno(
            "Confirm Delete",
            f"Are you sure you want to delete patient {patient.first_name} {patient.last_name}?\n\nThis action cannot be undone."
        )
        
        if response:
            # Attempt to delete
            try:
                success = PatientController.delete_patient(patient_id)
                if success:
                    messagebox.showinfo("Success", f"Patient {patient.first_name} {patient.last_name} deleted successfully")
                    self.load_patients()
                else:
                    messagebox.showerror("Error", "Failed to delete patient")
            except Exception as e:
                messagebox.showerror("Error", f"Error deleting patient: {str(e)}")

class PatientDetailsDialog(ctk.CTkToplevel):
    def __init__(self, parent, patient):
        super().__init__(parent)
        self.patient = patient
        # Use first_name and last_name instead of full_name which doesn't exist
        self.title(f"Patient Details - {patient.first_name} {patient.last_name}")
        self.geometry("800x600")
        
        # Create notebook for tabs
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create tabs
        self.create_profile_tab()
        self.create_appointments_tab()
        self.create_medical_history_tab()
        self.create_billing_tab()
    
    def create_profile_tab(self):
        profile_frame = ctk.CTkFrame(self.notebook)
        profile_frame.pack(fill=tk.BOTH, expand=True)
        
        # Profile information
        info_frame = ctk.CTkFrame(profile_frame)
        info_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        labels = [
            ("Name:", f"{self.patient.first_name} {self.patient.last_name}"),
            ("Gender:", self.patient.gender),
            ("Date of Birth:", self.patient.dob.strftime("%m/%d/%Y")),  # Changed date_of_birth to dob
            ("Blood Group:", self.patient.blood_group or "Not specified"),
            ("Contact:", self.patient.contact),  # Changed contact_number to contact
            ("Email:", self.patient.email or "Not specified"),
            ("Address:", self.patient.address or "Not specified")
        ]
        
        for label, value in labels:
            row = ctk.CTkFrame(info_frame)
            row.pack(fill=tk.X, pady=2)
            
            ctk.CTkLabel(row, text=label, width=100).pack(side=tk.LEFT, padx=5)
            ctk.CTkLabel(row, text=value).pack(side=tk.LEFT, padx=5)
        
        self.notebook.add(profile_frame, text="Profile")
    
    def create_appointments_tab(self):
        appointments_frame = ctk.CTkFrame(self.notebook)
        appointments_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create appointments table
        columns = ("Date", "Time", "Doctor", "Status")
        self.appointments_table = ttk.Treeview(
            appointments_frame, columns=columns, show="headings"
        )
        
        for col in columns:
            self.appointments_table.heading(col, text=col)
            self.appointments_table.column(col, width=100)
        
        scrollbar = ttk.Scrollbar(
            appointments_frame, 
            orient=tk.VERTICAL, 
            command=self.appointments_table.yview
        )
        self.appointments_table.configure(yscrollcommand=scrollbar.set)
        
        self.appointments_table.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Load appointments
        appointments = AppointmentController.get_appointments_by_patient(self.patient.patient_id)
        
        for appt in appointments:
            self.appointments_table.insert("", tk.END, values=(
                appt.date.strftime("%m/%d/%Y") if hasattr(appt, 'date') else "Unknown",
                appt.time_slot if hasattr(appt, 'time_slot') else "Unknown",
                appt.doctor.full_name if hasattr(appt, 'doctor') else "Unknown",
                appt.status.name if hasattr(appt.status, 'name') else str(appt.status)
            ))
        
        self.notebook.add(appointments_frame, text="Appointments")
    
    def create_medical_history_tab(self):
        medical_frame = ctk.CTkFrame(self.notebook)
        medical_frame.pack(fill=tk.BOTH, expand=True)
        
        # Medical history text
        ctk.CTkLabel(medical_frame, text="Medical History:").pack(anchor=tk.W, padx=10, pady=5)
        
        medical_text = ctk.CTkTextbox(medical_frame, height=200)
        medical_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        medical_text.insert("1.0", self.patient.medical_history or "No medical history recorded.")
        medical_text.configure(state="disabled")
        
        # Past appointments with notes
        ctk.CTkLabel(medical_frame, text="Past Appointments:").pack(anchor=tk.W, padx=10, pady=5)
        
        columns = ("Date", "Doctor", "Notes")
        self.medical_table = ttk.Treeview(
            medical_frame, columns=columns, show="headings"
        )
        
        for col in columns:
            self.medical_table.heading(col, text=col)
        
        scrollbar = ttk.Scrollbar(
            medical_frame, 
            orient=tk.VERTICAL, 
            command=self.medical_table.yview
        )
        self.medical_table.configure(yscrollcommand=scrollbar.set)
        
        self.medical_table.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=5)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Load past appointments
        appointments = AppointmentController.get_appointments_by_patient(self.patient.patient_id)
        for appt in appointments:
            if str(appt.status).lower() == "completed" or (hasattr(appt.status, 'name') and appt.status.name.lower() == "completed"):
                self.medical_table.insert("", tk.END, values=(
                    appt.date.strftime("%m/%d/%Y") if hasattr(appt, 'date') else "Unknown",
                    "Unknown Doctor", # We need to lookup doctor names separately
                    appt.notes or "No notes"
                ))
        
        self.notebook.add(medical_frame, text="Medical History")
    
    def create_billing_tab(self):
        billing_frame = ctk.CTkFrame(self.notebook)
        billing_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create billing table
        columns = ("Date", "Amount", "Status", "Actions")
        self.billing_table = ttk.Treeview(
            billing_frame, columns=columns, show="headings"
        )
        
        for col in columns:
            self.billing_table.heading(col, text=col)
        
        scrollbar = ttk.Scrollbar(
            billing_frame, 
            orient=tk.VERTICAL, 
            command=self.billing_table.yview
        )
        self.billing_table.configure(yscrollcommand=scrollbar.set)
        
        self.billing_table.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Load bills
        bills = BillingController.get_bills_by_patient(self.patient.patient_id)
        
        for bill in bills:
            self.billing_table.insert("", tk.END, values=(
                bill.bill_date.strftime("%m/%d/%Y"),
                f"${bill.total_amount:.2f}",
                bill.payment_status.title(),
                "View Details"
            ))
        
        self.notebook.add(billing_frame, text="Billing")
    
    def show_appointments(self):
        """Show appointment management view"""
        self.clear_content()
        appointments_frame = AppointmentManagementFrame(self.content_frame)
        appointments_frame.pack(fill=tk.BOTH, expand=True)

class AppointmentManagementFrame(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        
        # Create header
        self.header = ctk.CTkLabel(
            self,
            text="Appointment Management",
            font=ctk.CTkFont(size=20, weight="bold")
        )
        self.header.pack(pady=10)
        
        # Create controls
        controls_frame = ctk.CTkFrame(self)
        controls_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # Date filter
        self.date_label = ctk.CTkLabel(controls_frame, text="Date:")
        self.date_label.pack(side=tk.LEFT, padx=5)
        
        self.date_picker = DateEntry(
            controls_frame,
            width=12,
            background='darkblue',
            foreground='white',
            borderwidth=2
        )
        self.date_picker.pack(side=tk.LEFT, padx=5)
        
        # Status filter
        self.status_label = ctk.CTkLabel(controls_frame, text="Status:")
        self.status_label.pack(side=tk.LEFT, padx=5)
        
        self.status_var = tk.StringVar(value="all")
        self.status_combo = ctk.CTkComboBox(
            controls_frame,
            values=["all", "scheduled", "completed", "cancelled"],
            variable=self.status_var
        )
        self.status_combo.pack(side=tk.LEFT, padx=5)
        
        # Search
        self.search_entry = ctk.CTkEntry(
            controls_frame,
            placeholder_text="Search patient or doctor..."
        )
        self.search_entry.pack(side=tk.LEFT, padx=5)
        
        self.search_button = ctk.CTkButton(
            controls_frame,
            text="Search",
            command=self.search_appointments
        )
        self.search_button.pack(side=tk.LEFT, padx=5)
        
        self.refresh_button = ctk.CTkButton(
            controls_frame,
            text="Refresh",
            fg_color="transparent",
            border_width=2,
            command=self.load_appointments
        )
        self.refresh_button.pack(side=tk.LEFT, padx=5)
        
        # Create new appointment button
        self.new_appointment_button = ctk.CTkButton(
            controls_frame,
            text="New Appointment",
            command=self.create_appointment
        )
        self.new_appointment_button.pack(side=tk.RIGHT, padx=5)
        
        # Create table
        self.create_table()
        self.load_appointments()
    
    def create_table(self):
        columns = (
            "ID", "Date", "Time", "Patient", "Doctor", 
            "Status", "Actions"
        )
        self.table = ttk.Treeview(self, columns=columns, show="headings")
        
        # Configure columns
        for col in columns:
            self.table.heading(col, text=col)
            # Set column widths based on content
            if col in ["Patient", "Doctor"]:
                width = 150
            elif col == "Actions":
                width = 150  # Make actions column wider for buttons
            elif col == "ID":
                width = 50   # ID can be narrower
            else:
                width = 100  # Default width
            self.table.column(col, width=width)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(self, orient=tk.VERTICAL, command=self.table.yview)
        self.table.configure(yscrollcommand=scrollbar.set)
        
        # Pack table and scrollbar
        self.table.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=5)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Bind events
        self.table.bind("<ButtonRelease-1>", self.on_appointment_select)
    
    def load_appointments(self):
        # Clear existing items
        try:
            for item in self.table.get_children():
                self.table.delete(item)
            
            # Get appointments based on filters
            date = self.date_picker.get_date()
            status = self.status_var.get()
            
            # Debug info
            print(f"Loading appointments with date={date}, status={status}")
            
            appointments = AppointmentController.get_appointments(
                date=date if status != "all" else None,
                status=status if status != "all" else None
            )
            
            print(f"Found {len(appointments)} appointments")
            
            if not appointments:
                # If no appointments found, display a message
                self.table.insert("", tk.END, values=(
                    "", "", "", "No appointments found", "", "", ""
                ))
                print("No appointments found")
                return
                
            for appt in appointments:
                try:
                    # Debug appointment object
                    print(f"Processing appointment: {appt.appointment_id}, attrs: {dir(appt)}")
                    
                    # Get related patient and doctor objects
                    patient = PatientController.get_patient_by_id(appt.patient_id)
                    doctor = DoctorController.get_doctor_by_id(appt.doctor_id)
                    
                    patient_name = f"{patient.first_name} {patient.last_name}" if patient else f"Patient {appt.patient_id}"
                    doctor_name = f"{doctor.first_name} {doctor.last_name}" if doctor else f"Doctor {appt.doctor_id}"
                    
                    # Handle date formatting safely
                    try:
                        if hasattr(appt, 'date'):
                            if hasattr(appt.date, 'strftime'):
                                date_str = appt.date.strftime("%m/%d/%Y")
                            else:
                                date_str = str(appt.date)
                        else:
                            date_str = "Unknown"
                    except Exception as e:
                        print(f"Error formatting date: {str(e)}")
                        date_str = "Error"
                    
                    # Handle time slot
                    time_str = appt.time_slot if hasattr(appt, 'time_slot') else "N/A"
                    
                    # Handle status formatting safely
                    try:
                        if hasattr(appt, 'status'):
                            if hasattr(appt.status, 'name'):
                                status_str = appt.status.name
                            elif hasattr(appt.status, 'value'):
                                status_str = appt.status.value
                            else:
                                status_str = str(appt.status)
                        else:
                            status_str = "Unknown"
                    except Exception as e:
                        print(f"Error formatting status: {str(e)}")
                        status_str = "Error"
                    
                    self.table.insert("", tk.END, values=(
                        appt.appointment_id,
                        date_str,
                        time_str,
                        patient_name,
                        doctor_name,
                        status_str,
                        "👁️ View | 🗑️ Delete"
                    ))
                except Exception as e:
                    print(f"Error displaying appointment {appt.appointment_id if hasattr(appt, 'appointment_id') else 'unknown'}: {str(e)}")
                    messagebox.showwarning("Warning", f"Error displaying appointment: {str(e)}")
        except Exception as e:
            print(f"Failed to load appointments: {str(e)}")
            messagebox.showerror("Error", f"Failed to load appointments: {str(e)}")
    
    def search_appointments(self):
        search_term = self.search_entry.get().strip().lower()
        if not search_term:
            self.load_appointments()
            return
        
        # Clear existing items
        for item in self.table.get_children():
            self.table.delete(item)
        
        # Get appointments based on filters
        date = self.date_picker.get_date()
        status = self.status_var.get()
        
        appointments = AppointmentController.get_appointments(
            date=date if status != "all" else None,
            status=status if status != "all" else None
        )
        
        # Filter appointments based on search term
        for appt in appointments:
            patient_name = f"{appt.patient.first_name} {appt.patient.last_name}".lower()
            doctor_name = f"{appt.doctor.first_name} {appt.doctor.last_name}".lower()
            
            if search_term in patient_name or search_term in doctor_name:
                # Get related patient and doctor objects
                patient = PatientController.get_patient_by_id(appt.patient_id)
                doctor = DoctorController.get_doctor_by_id(appt.doctor_id)
                
                patient_name = f"{patient.first_name} {patient.last_name}" if patient else f"Patient {appt.patient_id}"
                doctor_name = f"{doctor.first_name} {doctor.last_name}" if doctor else f"Doctor {appt.doctor_id}"
                
                self.table.insert("", tk.END, values=(
                    appt.appointment_id,
                    appt.date.strftime("%m/%d/%Y") if hasattr(appt.date, 'strftime') else str(appt.date),
                    appt.time_slot if hasattr(appt, 'time_slot') else "N/A",
                    patient_name,
                    doctor_name,
                    appt.status.value if hasattr(appt.status, 'value') else str(appt.status),
                    "View Details"
                ))
    
    def create_appointment(self):
        try:
            # First check if we have patients and doctors
            patients = PatientController.get_all_patients()
            doctors = DoctorController.get_all_doctors()
            
            if not patients:
                messagebox.showwarning("No Patients", "You need to add patients before creating appointments.")
                return
                
            if not doctors:
                messagebox.showwarning("No Doctors", "You need to add doctors before creating appointments.")
                return
            
            print("Creating new appointment...")
            dialog = AppointmentDialog(self)
            dialog.transient(self)  # Make the dialog transient to parent
            dialog.grab_set()       # Make the dialog modal
            dialog.focus_force()    # Force focus on the dialog
            self.wait_window(dialog)
            print("Appointment dialog closed, refreshing appointment list")
            self.load_appointments()
        except Exception as e:
            print(f"Error creating appointment dialog: {str(e)}")
            messagebox.showerror("Error", f"Failed to create appointment dialog: {str(e)}")
    
    def on_appointment_select(self, event):
        try:
            # Debug the event type and coordinates
            print(f"Event: type={event.type}, x={event.x}, y={event.y}, num={event.num}")
            
            # Get the item that was clicked
            region = self.table.identify_region(event.x, event.y)
            print(f"Region: {region}")
            if region != "cell":
                return
                
            # Get the item that was clicked
            item = self.table.identify_row(event.y)
            if not item:
                print("No item identified")
                return
                
            # Get column number
            column = self.table.identify_column(event.x)
            col_idx = int(column.replace('#', '')) - 1
            
            # Get appointment ID from the row
            values = self.table.item(item)["values"]
            print(f"Row values: {values}")
            
            if not values or len(values) == 0:
                print("No values in row")
                return
                
            appt_id = values[0]
            
            if not appt_id or appt_id == "":  # Empty row or no ID
                print("Empty appointment ID")
                return
                
            print(f"Clicked on appointment ID {appt_id}, column {col_idx}")
            
            # Handle action column clicks
            if col_idx == 6:  # Actions column (0-based index)
                cell_width = self.table.column("#7")["width"]  # Width of Actions column (1-based)
                x_relative = event.x - self.table.bbox(item, column)[0]
                # Divide the column into 40% for View and 60% for Delete to account for text size difference
                delete_threshold = cell_width * 0.6  # 60% mark for the delete button
                
                print(f"Action column click: x_rel={x_relative}, threshold={delete_threshold}, width={cell_width}")
                
                # Convert appt_id to integer if it's a string
                try:
                    appt_id = int(appt_id)
                except (ValueError, TypeError):
                    print(f"Invalid appointment ID: {appt_id}")
                    return
                
                # Right portion (>60%) = Delete button
                if x_relative > delete_threshold:  
                    print(f"Deleting appointment {appt_id}")
                    self.delete_appointment(appt_id)
                else:  # Left portion (<60%) = View button
                    print(f"Viewing appointment {appt_id}")
                    self.view_appointment_details(appt_id)
            else:
                # Click anywhere else to view details
                try:
                    appt_id = int(appt_id)
                    self.view_appointment_details(appt_id)
                except (ValueError, TypeError):
                    print(f"Invalid appointment ID: {appt_id}")
        except Exception as e:
            print(f"Error in on_appointment_select: {str(e)}")
            messagebox.showerror("Error", f"Error processing selection: {str(e)}")
    
    def view_appointment_details(self, appt_id):
        appointment = AppointmentController.get_appointment_by_id(appt_id)
        if appointment:
            dialog = AppointmentDetailsDialog(self, appointment)
            dialog.focus()
            self.wait_window(dialog)
            self.load_appointments()
            
    def delete_appointment(self, appt_id):
        try:
            # Get the appointment details
            appointment = AppointmentController.get_appointment_by_id(appt_id)
            if not appointment:
                messagebox.showerror("Error", "Appointment not found")
                return
                
            # Confirm deletion
            response = messagebox.askyesno(
                "Confirm Delete",
                f"Are you sure you want to delete this appointment?\n\nThis action cannot be undone."
            )
            
            if response:
                # Print debug info
                print(f"Attempting to delete appointment {appt_id}")
                print(f"Appointment details: date={appointment.date}, time_slot={appointment.time_slot}")
                
                # Attempt to delete
                try:
                    # Call the cancel_appointment method which returns a tuple (success, message)
                    result = AppointmentController.cancel_appointment(appt_id)
                    
                    # Debug the result
                    print(f"Cancel appointment result: {result}")
                    
                    # Make sure we properly unpack the tuple
                    if isinstance(result, tuple) and len(result) == 2:
                        success, message = result
                    else:
                        success = result
                        message = ""
                    
                    if success:
                        messagebox.showinfo("Success", "Appointment deleted successfully")
                        self.load_appointments()
                    else:
                        messagebox.showerror("Error", f"Failed to delete appointment: {message}")
                except Exception as e:
                    print(f"Error in delete_appointment (inner): {str(e)}")
                    messagebox.showerror("Error", f"Error deleting appointment: {str(e)}")
        except Exception as e:
            print(f"Error in delete_appointment (outer): {str(e)}")
            messagebox.showerror("Error", f"Error preparing to delete appointment: {str(e)}")

class AppointmentDialog(ctk.CTkToplevel):
    def __init__(self, parent, appointment=None):
        super().__init__(parent)
        self.appointment = appointment
        self.title("New Appointment" if not appointment else "Edit Appointment")
        self.geometry("600x500")
        
        # Make dialog modal and centered on parent
        self.transient(parent)
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        self.focus_force()
        
        # Patient selection
        patient_frame = ctk.CTkFrame(self)
        patient_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ctk.CTkLabel(patient_frame, text="Patient:").pack(side=tk.LEFT, padx=5)
        self.patient_var = tk.StringVar()
        self.patients = PatientController.get_all_patients()  # Store the full patient objects
        
        if not self.patients:
            # If no patients exist, show a message
            messagebox.showwarning("No Patients", "No patients found in the system. Please add patients first.")
            patient_names = ["No patients available"]
            self.patient_dict = {}  # Empty dictionary if no patients
        else:
            # Create a dictionary mapping display strings to patient IDs for easy lookup
            patient_names = [f"{p.patient_id}: {p.first_name} {p.last_name}" for p in self.patients]
            self.patient_dict = {f"{p.patient_id}: {p.first_name} {p.last_name}": p.patient_id for p in self.patients}
            # Set default selection to first patient
            if patient_names:
                self.patient_var.set(patient_names[0])
        
        # Use CTkComboBox instead of tk.OptionMenu for better visibility
        self.patient_combo = ctk.CTkComboBox(
            patient_frame,
            variable=self.patient_var,
            values=patient_names,
            width=300,
            state="readonly"
        )
        self.patient_combo.pack(side=tk.LEFT, padx=5)
        
        # Doctor selection
        doctor_frame = ctk.CTkFrame(self)
        doctor_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ctk.CTkLabel(doctor_frame, text="Doctor:").pack(side=tk.LEFT, padx=5)
        self.doctor_var = tk.StringVar()
        self.doctors = DoctorController.get_all_doctors()  # Store the full doctor objects
        
        if not self.doctors:
            # If no doctors exist, show a message
            messagebox.showwarning("No Doctors", "No doctors found in the system. Please add doctors first.")
            doctor_names = ["No doctors available"]
            self.doctor_dict = {}  # Empty dictionary if no doctors
        else:
            # Create a dictionary mapping display strings to doctor IDs for easy lookup
            doctor_names = [f"{d.doctor_id}: {d.first_name} {d.last_name}" for d in self.doctors]
            self.doctor_dict = {f"{d.doctor_id}: {d.first_name} {d.last_name}": d.doctor_id for d in self.doctors}
            # Set default selection to first doctor
            if doctor_names:
                self.doctor_var.set(doctor_names[0])
        
        # Use CTkComboBox instead of tk.OptionMenu for better visibility
        self.doctor_combo = ctk.CTkComboBox(
            doctor_frame,
            variable=self.doctor_var,
            values=doctor_names,
            width=300,
            state="readonly"
        )
        self.doctor_combo.pack(side=tk.LEFT, padx=5)
        
        # Date and time
        datetime_frame = ctk.CTkFrame(self)
        datetime_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ctk.CTkLabel(datetime_frame, text="Date:").pack(side=tk.LEFT, padx=5)
        self.date_picker = DateEntry(
            datetime_frame,
            width=12,
            background='darkblue',
            foreground='white',
            borderwidth=2
        )
        self.date_picker.pack(side=tk.LEFT, padx=5)
        
        ctk.CTkLabel(datetime_frame, text="Time:").pack(side=tk.LEFT, padx=5)
        self.time_var = tk.StringVar()
        times = [f"{h:02d}:{m:02d}" for h in range(9, 18) for m in (0, 30)]
        # Set default time to 9:00
        self.time_var.set("09:00")
        self.time_combo = ctk.CTkComboBox(
            datetime_frame,
            values=times,
            variable=self.time_var
        )
        self.time_combo.pack(side=tk.LEFT, padx=5)
        
        # Notes
        notes_frame = ctk.CTkFrame(self)
        notes_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        ctk.CTkLabel(notes_frame, text="Notes:").pack(anchor=tk.W)
        self.notes_text = ctk.CTkTextbox(notes_frame, height=100)
        self.notes_text.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Buttons
        button_frame = ctk.CTkFrame(self)
        button_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.save_button = ctk.CTkButton(
            button_frame,
            text="Save",
            command=self.save_appointment
        )
        self.save_button.pack(side=tk.RIGHT, padx=5)
        
        self.cancel_button = ctk.CTkButton(
            button_frame,
            text="Cancel",
            command=self.destroy,
            fg_color="transparent",
            border_width=2
        )
        self.cancel_button.pack(side=tk.RIGHT, padx=5)
        
        if appointment:
            self.load_appointment_data()
    
    def load_appointment_data(self):
        # Create patient selection string
        patient_string = f"{self.appointment.patient.patient_id}: {self.appointment.patient.first_name} {self.appointment.patient.last_name}"
        # Set patient selection if it exists in our dropdown
        if patient_string in self.patient_dict:
            self.patient_var.set(patient_string)
        
        # Create doctor selection string
        doctor_string = f"{self.appointment.doctor.doctor_id}: {self.appointment.doctor.first_name} {self.appointment.doctor.last_name}"
        # Set doctor selection if it exists in our dropdown
        if doctor_string in self.doctor_dict:
            self.doctor_var.set(doctor_string)
        
        # Set date safely
        if hasattr(self.appointment, 'date') and self.appointment.date:
            self.date_picker.set_date(self.appointment.date)
        
        # Set time safely
        if hasattr(self.appointment, 'time_slot') and self.appointment.time_slot:
            self.time_var.set(self.appointment.time_slot)
        self.notes_text.insert("1.0", self.appointment.notes or "")
    
    def save_appointment(self):
        try:
            # Validate patient selection
            patient_value = self.patient_var.get()
            if not patient_value or patient_value == "No patients available":
                messagebox.showerror("Error", "Please select a patient")
                return
            
            # Validate doctor selection
            doctor_value = self.doctor_var.get()
            if not doctor_value:
                messagebox.showerror("Error", "Please select a doctor")
                return
                
            # Get patient ID directly from our dictionary
            try:
                patient_id = self.patient_dict[patient_value]
            except KeyError:
                messagebox.showerror("Error", "Invalid patient selection. Please select a patient from the dropdown.")
                return
                
            try:
                doctor_id = self.doctor_dict[doctor_value]
            except KeyError:
                messagebox.showerror("Error", "Invalid doctor selection. Please select a doctor from the dropdown.")
                return
            
            # Get date
            date = self.date_picker.get_date()
            if not date:
                messagebox.showerror("Error", "Please select a date")
                return
                
            # Get time
            time_str = self.time_var.get()
            if not time_str:
                messagebox.showerror("Error", "Please select a time")
                return
                
            try:
                hours, minutes = map(int, time_str.split(":"))
                from datetime import time
                time_obj = time(hours, minutes)
            except (ValueError, IndexError):
                messagebox.showerror("Error", "Invalid time format. Please use HH:MM format.")
                return
            
            notes = self.notes_text.get("1.0", tk.END).strip()
            
            if self.appointment:
                # Update existing appointment
                success, result = AppointmentController.update_appointment(
                    self.appointment.appointment_id,
                    patient_id,
                    doctor_id,
                    date,
                    time_obj,
                    notes
                )
                if not success:
                    messagebox.showerror("Error", str(result))
                    return
            else:
                # Create new appointment
                success, result = AppointmentController.create_appointment(
                    patient_id,
                    doctor_id,
                    date,
                    time_obj,
                    reason="Admin scheduled appointment",
                    notes=notes
                )
                if not success:
                    messagebox.showerror("Error", str(result))
                    return
                else:
                    messagebox.showinfo("Success", "Appointment created successfully")
            
            self.destroy()
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

class AppointmentDetailsDialog(ctk.CTkToplevel):
    def __init__(self, parent, appointment):
        super().__init__(parent)
        self.appointment = appointment
        self.title(f"Appointment Details - {appointment.appointment_id}")
        self.geometry("600x400")
        
        # Details
        details_frame = ctk.CTkFrame(self)
        details_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Get patient and doctor info
        patient = PatientController.get_patient_by_id(appointment.patient_id)
        doctor = DoctorController.get_doctor_by_id(appointment.doctor_id)
        
        # Format date and time safely
        date_str = appointment.date.strftime("%m/%d/%Y") if hasattr(appointment, 'date') and hasattr(appointment.date, 'strftime') else "Unknown"
        time_str = appointment.time_slot if hasattr(appointment, 'time_slot') else "Unknown"
        
        # Format status safely
        status_str = appointment.status.name if hasattr(appointment.status, 'name') else str(appointment.status)
        
        labels = [
            ("Date:", date_str),
            ("Time:", time_str),
            ("Patient:", f"{patient.first_name} {patient.last_name}" if patient else f"Patient ID: {appointment.patient_id}"),
            ("Doctor:", f"{doctor.first_name} {doctor.last_name}" if doctor else f"Doctor ID: {appointment.doctor_id}"),
            ("Status:", status_str.title())
        ]
        
        for label, value in labels:
            row = ctk.CTkFrame(details_frame)
            row.pack(fill=tk.X, pady=2)
            
            ctk.CTkLabel(row, text=label, width=100).pack(side=tk.LEFT, padx=5)
            ctk.CTkLabel(row, text=value).pack(side=tk.LEFT, padx=5)
        
        # Notes
        ctk.CTkLabel(details_frame, text="Notes:").pack(anchor=tk.W, padx=5, pady=5)
        notes_text = ctk.CTkTextbox(details_frame, height=100)
        notes_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        notes_text.insert("1.0", appointment.notes or "")
        notes_text.configure(state="disabled")
        
        # Actions
        actions_frame = ctk.CTkFrame(self)
        actions_frame.pack(fill=tk.X, padx=10, pady=10)
        
        if appointment.status == "scheduled":
            self.complete_button = ctk.CTkButton(
                actions_frame,
                text="Mark as Completed",
                command=self.mark_completed
            )
            self.complete_button.pack(side=tk.LEFT, padx=5)
            
            self.cancel_button = ctk.CTkButton(
                actions_frame,
                text="Cancel Appointment",
                command=self.cancel_appointment,
                fg_color="red"
            )
            self.cancel_button.pack(side=tk.LEFT, padx=5)
        
        self.edit_button = ctk.CTkButton(
            actions_frame,
            text="Edit",
            command=self.edit_appointment
        )
        self.edit_button.pack(side=tk.RIGHT, padx=5)
        
        self.close_button = ctk.CTkButton(
            actions_frame,
            text="Close",
            command=self.destroy,
            fg_color="transparent",
            border_width=2
        )
        self.close_button.pack(side=tk.RIGHT, padx=5)
    
    def mark_completed(self):
        if messagebox.askyesno("Confirm", "Mark this appointment as completed?"):
            AppointmentController.update_appointment_status(
                self.appointment.appointment_id, 
                "completed"
            )
            self.destroy()
    
    def cancel_appointment(self):
        if messagebox.askyesno("Confirm", "Cancel this appointment?"):
            AppointmentController.update_appointment_status(
                self.appointment.appointment_id, 
                "cancelled"
            )
            self.destroy()
    
    def edit_appointment(self):
        self.destroy()
        dialog = AppointmentDialog(self.master, self.appointment)
        dialog.focus()
    
    def show_billing(self):
        """Show billing management view"""
        self.clear_content()
        billing_frame = BillingManagementFrame(self.content_frame)
        billing_frame.pack(fill=tk.BOTH, expand=True)

class BillingManagementFrame(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        
        # Create header
        self.header = ctk.CTkLabel(
            self,
            text="Billing Management",
            font=ctk.CTkFont(size=20, weight="bold")
        )
        self.header.pack(pady=10)
        
        # Create controls
        controls_frame = ctk.CTkFrame(self)
        controls_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # Date filter
        self.date_label = ctk.CTkLabel(controls_frame, text="Date Range:")
        self.date_label.pack(side=tk.LEFT, padx=5)
        
        self.start_date = DateEntry(
            controls_frame,
            width=12,
            background='darkblue',
            foreground='white',
            borderwidth=2
        )
        self.start_date.pack(side=tk.LEFT, padx=5)
        
        self.end_date = DateEntry(
            controls_frame,
            width=12,
            background='darkblue',
            foreground='white',
            borderwidth=2
        )
        self.end_date.pack(side=tk.LEFT, padx=5)
        
        # Status filter
        self.status_label = ctk.CTkLabel(controls_frame, text="Status:")
        self.status_label.pack(side=tk.LEFT, padx=5)
        
        self.status_var = tk.StringVar(value="all")
        self.status_combo = ctk.CTkComboBox(
            controls_frame,
            values=["all", "paid", "pending", "overdue"],
            variable=self.status_var
        )
        self.status_combo.pack(side=tk.LEFT, padx=5)
        
        # Search
        self.search_entry = ctk.CTkEntry(
            controls_frame,
            placeholder_text="Search by patient name..."
        )
        self.search_entry.pack(side=tk.LEFT, padx=5)
        
        self.search_button = ctk.CTkButton(
            controls_frame,
            text="Search",
            command=self.search_bills
        )
        self.search_button.pack(side=tk.LEFT, padx=5)
        
        self.refresh_button = ctk.CTkButton(
            controls_frame,
            text="Refresh",
            fg_color="transparent",
            border_width=2,
            command=self.load_bills
        )
        self.refresh_button.pack(side=tk.LEFT, padx=5)
        
        # Create new bill button
        self.new_bill_button = ctk.CTkButton(
            controls_frame,
            text="New Bill",
            command=self.create_bill
        )
        self.new_bill_button.pack(side=tk.RIGHT, padx=5)
        
        # Create table
        self.create_table()
        self.load_bills()
    
    def create_table(self):
        columns = (
            "Bill ID", "Patient", "Date", "Total Amount", 
            "Status", "Actions"
        )
        self.table = ttk.Treeview(self, columns=columns, show="headings")
        
        # Configure columns
        for col in columns:
            self.table.heading(col, text=col)
            width = 150 if col in ["Patient"] else 100
            self.table.column(col, width=width)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(self, orient=tk.VERTICAL, command=self.table.yview)
        self.table.configure(yscrollcommand=scrollbar.set)
        
        # Pack table and scrollbar
        self.table.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=5)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Bind events
        self.table.bind("<Double-1>", self.on_bill_select)
    
    def load_bills(self):
        print("BillingManagementFrame.load_bills() called")
        
        # Use our direct billing fix to refresh the table
        from src.controllers.billing_fix import refresh_billing_table
        count = refresh_billing_table(self.table)
        print(f"Loaded {count} bills into the table")
    
    def search_bills(self):
        search_term = self.search_entry.get().strip().lower()
        if not search_term:
            self.load_bills()
            return
            
        print(f"Searching bills with term: '{search_term}'")
        
        # Use our enhanced billing_fix utility with the search term
        from src.controllers.billing_fix import refresh_billing_table
        count = refresh_billing_table(self.table, search_term=search_term)
        print(f"Found and displayed {count} bills matching '{search_term}'")
    
    def create_bill(self):
        print("Creating new bill...")
        dialog = BillDialog(self)
        dialog.transient(self)  # Make the dialog transient to parent
        dialog.grab_set()       # Make the dialog modal
        dialog.focus_force()    # Force focus on the dialog
        dialog.parent_table = self.table  # Pass reference to parent table
        self.wait_window(dialog)
        print("Bill dialog closed, refreshing billing list")
        
        # Use our direct billing fix to refresh the table
        from src.controllers.billing_fix import refresh_billing_table
        refresh_billing_table(self.table)
    
    def on_bill_select(self, event):
        try:
            item = self.table.selection()[0]
            values = self.table.item(item)["values"]
            bill_id = values[0]
            
            if not bill_id or bill_id == "N/A":  # Empty row or no ID
                return
                
            # Determine if view or delete was clicked based on the click position
            clicked_column = self.table.identify_column(event.x)
            col_idx = int(clicked_column.replace('#', '')) - 1
            
            if col_idx == 5:  # Actions column (Bill has: ID, Patient, Date, Total, Status, Actions)
                x_relative = event.x - self.table.winfo_rootx()
                # If they clicked the right side of the actions cell (delete button area)
                if x_relative > 75:  # Delete button area
                    self.delete_bill(bill_id)
                else:  # View button area
                    self.view_bill_details(bill_id)
            else:
                # Default to view details if they clicked elsewhere on the row
                self.view_bill_details(bill_id)
        except Exception as e:
            messagebox.showerror("Error", f"Error processing selection: {str(e)}")
            
    def view_bill_details(self, bill_id):
        bill = BillingController.get_bill_by_id(bill_id)
        if bill:
            dialog = BillDetailsDialog(self, bill)
            dialog.focus()
            self.wait_window(dialog)
            self.load_bills()
            
    def delete_bill(self, bill_id):
        bill = BillingController.get_bill_by_id(bill_id)
        if not bill:
            messagebox.showerror("Error", "Bill not found")
            return
            
        # Confirm deletion
        response = messagebox.askyesno(
            "Confirm Delete",
            f"Are you sure you want to delete this bill?\n\nThis action cannot be undone."
        )
        
        if response:
            # Attempt to delete
            try:
                success = BillingController.delete_bill(bill_id)
                if success:
                    messagebox.showinfo("Success", "Bill deleted successfully")
                    self.load_bills()
                else:
                    messagebox.showerror("Error", "Failed to delete bill")
            except Exception as e:
                messagebox.showerror("Error", f"Error deleting bill: {str(e)}")

class BillDialog(ctk.CTkToplevel):
    def __init__(self, parent, bill=None):
        super().__init__(parent)
        self.bill = bill
        self.parent_table = None  # Add reference to parent table
        self.title("New Bill" if not bill else "Edit Bill")
        self.geometry("600x650")  # Increased height
        self.minsize(600, 650)    # Set minimum size
        
        # Make dialog modal and centered
        self.transient(parent)
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        
        # Main frame with padding
        main_frame = ctk.CTkFrame(self)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Patient selection
        patient_frame = ctk.CTkFrame(main_frame)
        patient_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ctk.CTkLabel(patient_frame, text="Patient:", font=ctk.CTkFont(weight="bold")).pack(side=tk.LEFT, padx=10)
        
        # Get patients and create dropdown
        patients = PatientController.get_all_patients()
        patient_names = [f"{p.patient_id}: {p.first_name} {p.last_name}" for p in patients]
        
        # Store patients in a dict for easy lookup
        self.patients_dict = {f"{p.patient_id}: {p.first_name} {p.last_name}": p.patient_id for p in patients}
        
        self.patient_var = tk.StringVar(value=patient_names[0] if patient_names else "")
        
        # Use OptionMenu instead of ComboBox for better compatibility
        self.patient_dropdown = ctk.CTkOptionMenu(
            patient_frame,
            values=patient_names,
            variable=self.patient_var,
            width=300,
            dynamic_resizing=False
        )
        self.patient_dropdown.pack(side=tk.LEFT, padx=10)
        
        # Bill items
        items_frame = ctk.CTkFrame(main_frame)
        items_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        items_label = ctk.CTkLabel(items_frame, text="Bill Items:", font=ctk.CTkFont(weight="bold"))
        items_label.pack(fill=tk.X, padx=10, pady=5, anchor=tk.W)
        
        # Items table
        table_frame = ctk.CTkFrame(items_frame)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        columns = ("Description", "Amount")
        self.items_table = ttk.Treeview(table_frame, columns=columns, show="headings", height=5)
        for col in columns:
            self.items_table.heading(col, text=col)
            if col == "Description":
                self.items_table.column(col, width=350, stretch=True)
            else:
                self.items_table.column(col, width=100, stretch=False)
        
        table_scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.items_table.yview)
        self.items_table.configure(yscrollcommand=table_scrollbar.set)
        
        self.items_table.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        table_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Add item section
        add_section_frame = ctk.CTkFrame(main_frame)
        add_section_frame.pack(fill=tk.X, padx=10, pady=10)
        
        add_item_label = ctk.CTkLabel(add_section_frame, text="Add New Item:", font=ctk.CTkFont(weight="bold"))
        add_item_label.pack(anchor=tk.W, padx=10, pady=5)
        
        # Description input
        desc_frame = ctk.CTkFrame(add_section_frame)
        desc_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ctk.CTkLabel(desc_frame, text="Description:").pack(side=tk.LEFT, padx=10)
        self.desc_entry = ctk.CTkEntry(desc_frame, placeholder_text="Enter item description", width=400)
        self.desc_entry.pack(side=tk.LEFT, padx=10, fill=tk.X, expand=True)
        
        # Amount input
        amount_frame = ctk.CTkFrame(add_section_frame)
        amount_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ctk.CTkLabel(amount_frame, text="Amount ($):").pack(side=tk.LEFT, padx=10)
        self.amount_entry = ctk.CTkEntry(amount_frame, placeholder_text="0.00", width=150)
        self.amount_entry.pack(side=tk.LEFT, padx=10)
        
        # Add button
        self.add_item_button = ctk.CTkButton(
            amount_frame,
            text="Add Item",
            command=self.add_item,
            width=120
        )
        self.add_item_button.pack(side=tk.LEFT, padx=20)
        
        # Total
        total_frame = ctk.CTkFrame(main_frame)
        total_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ctk.CTkLabel(total_frame, text="Total Amount:", font=ctk.CTkFont(weight="bold", size=14)).pack(side=tk.LEFT, padx=10)
        self.total_label = ctk.CTkLabel(total_frame, text="$0.00", font=ctk.CTkFont(size=16, weight="bold"))
        self.total_label.pack(side=tk.LEFT, padx=10)
        
        # Buttons frame with prominent save button
        button_frame = ctk.CTkFrame(main_frame)
        button_frame.pack(fill=tk.X, padx=10, pady=(20, 10))
        
        self.save_button = ctk.CTkButton(
            button_frame,
            text="SAVE BILL",
            command=self.save_bill,
            fg_color="#28a745",  # Green color for save button
            hover_color="#218838",  # Darker green on hover
            font=ctk.CTkFont(weight="bold", size=16),
            height=50,
            width=200
        )
        self.save_button.pack(side=tk.RIGHT, padx=20, pady=10)
        
        self.cancel_button = ctk.CTkButton(
            button_frame,
            text="Cancel",
            command=self.destroy,
            fg_color="transparent",
            border_width=2,
            height=50,
            width=120
        )
        self.cancel_button.pack(side=tk.RIGHT, padx=20, pady=10)
        
        # Patient selection is already set with the initial value in patient_var
        
        if bill:
            self.load_bill_data()
        
        # Bind keyboard shortcuts
        self.bind("<Return>", lambda event: self.add_item())
        self.bind("<Control-s>", lambda event: self.save_bill())
        self.bind("<Escape>", lambda event: self.destroy())
        
        # Set initial focus
        self.desc_entry.focus_set()
    
    def add_item(self):
        desc = self.desc_entry.get().strip()
        amount_str = self.amount_entry.get().strip()
        
        if not desc:
            messagebox.showerror("Error", "Please enter a description for the bill item")
            self.desc_entry.focus_set()
            return
            
        if not amount_str:
            messagebox.showerror("Error", "Please enter an amount for the bill item")
            self.amount_entry.focus_set()
            return
        
        try:
            # Handle both formats: with or without dollar sign, with or without commas
            cleaned_amount = amount_str.replace('$', '').replace(',', '')
            amount = float(cleaned_amount)
            
            if amount <= 0:
                messagebox.showerror("Error", "Amount must be greater than zero")
                self.amount_entry.focus_set()
                return
                
            # Add to table with proper formatting
            self.items_table.insert("", tk.END, values=(desc, f"${amount:.2f}"))
            self.update_total()
            
            # Clear entries and set focus for next item
            self.desc_entry.delete(0, tk.END)
            self.amount_entry.delete(0, tk.END)
            self.desc_entry.focus_set()
            
            # Show a brief indicator of success
            self.add_item_button.configure(text="Item Added ✓")
            self.after(1000, lambda: self.add_item_button.configure(text="Add Item"))
            
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid numeric amount")
            self.amount_entry.focus_set()
            self.amount_entry.select_range(0, tk.END)
    
    def update_total(self):
        total = 0
        for item in self.items_table.get_children():
            amount_str = self.items_table.item(item)["values"][1]
            total += float(amount_str.replace("$", ""))
        self.total_label.configure(text=f"${total:.2f}")
    
    def load_bill_data(self):
        # Format patient string
        patient_str = f"{self.bill.patient.patient_id}: {self.bill.patient.first_name} {self.bill.patient.last_name}"
        
        # Set the variable directly
        self.patient_var.set(patient_str)
        
        # Update dropdown if needed
        if hasattr(self, 'patient_dropdown') and patient_str not in self.patient_dropdown._values:
            # Add this patient to the dropdown values if it doesn't exist
            new_values = list(self.patient_dropdown._values)
            new_values.append(patient_str)
            self.patient_dropdown.configure(values=new_values)
            
            # Update our patient dictionary
            self.patients_dict[patient_str] = self.bill.patient.patient_id
        
        for item in self.bill.items:
            self.items_table.insert("", tk.END, values=(
                item.description,
                f"${item.amount:.2f}"
            ))
        
        self.update_total()
    
    def save_bill(self):
        try:
            # Check if patient is selected
            patient_str = self.patient_var.get()
            if not patient_str:
                messagebox.showerror("Error", "Please select a patient")
                return
            
            # Get patient ID from our dictionary
            try:
                patient_id = self.patients_dict.get(patient_str)
                if not patient_id:
                    # Try to parse it from the string as fallback
                    patient_id = int(patient_str.split(":")[0]) if ":" in patient_str else None
                
                if not patient_id:
                    messagebox.showerror("Error", "Invalid patient selection")
                    return
            except Exception:
                messagebox.showerror("Error", "Could not determine patient ID")
                return
            
            # Collect items
            items = []
            for item in self.items_table.get_children():
                desc, amount_str = self.items_table.item(item)["values"]
                amount = float(amount_str.replace("$", ""))
                items.append({"description": desc, "amount": amount})
            
            if not items:
                messagebox.showerror("Error", "Please add at least one item to the bill")
                self.desc_entry.focus_set()
                return
            
            # Temporarily disable the save button to prevent double submission
            self.save_button.configure(state="disabled", text="Saving...")
            self.update()
            
            if self.bill:
                # Update existing bill
                success, result = BillingController.update_bill(
                    self.bill.bill_id,
                    patient_id,
                    items
                )
                if success:
                    messagebox.showinfo("Success", "Bill updated successfully!")
                    self.destroy()
                else:
                    messagebox.showerror("Error", str(result))
                    self.save_button.configure(state="normal", text="Save Bill")
            else:
                # Create new bill
                success, result = BillingController.create_bill(
                    patient_id,
                    items
                )
                if success:
                    bill_id = result.get('bill_id', '') if isinstance(result, dict) else getattr(result, 'bill_id', '')
                    print(f"Bill {bill_id} created successfully!")
                    messagebox.showinfo("Success", f"Bill #{bill_id} created successfully!")
                    
                    # Refresh the billing table directly using our utility function
                    if hasattr(self, 'parent_table') and self.parent_table:
                        print("Refreshing table directly using billing_fix utility")
                        from src.controllers.billing_fix import refresh_billing_table
                        refresh_billing_table(self.parent_table)
                    # Also try the traditional approach as backup
                    elif hasattr(self.master, 'load_bills'):
                        print("Calling parent's load_bills method")
                        self.master.load_bills()
                    self.destroy()
                else:
                    messagebox.showerror("Error", str(result))
                    self.save_button.configure(state="normal", text="Save Bill")
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")
            self.save_button.configure(state="normal", text="Save Bill")

class BillDetailsDialog(ctk.CTkToplevel):
    def __init__(self, parent, bill):
        super().__init__(parent)
        self.bill = bill
        self.title(f"Bill Details - {bill.bill_id}")
        self.geometry("600x400")
        
        # Details
        details_frame = ctk.CTkFrame(self)
        details_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        labels = [
            ("Bill ID:", str(bill.bill_id)),
            ("Patient:", f"{bill.patient.first_name} {bill.patient.last_name}"),
            ("Date:", bill.bill_date.strftime("%m/%d/%Y")),
            ("Status:", bill.payment_status.title())
        ]
        
        for label, value in labels:
            row = ctk.CTkFrame(details_frame)
            row.pack(fill=tk.X, pady=2)
            
            ctk.CTkLabel(row, text=label, width=100).pack(side=tk.LEFT, padx=5)
            ctk.CTkLabel(row, text=value).pack(side=tk.LEFT, padx=5)
        
        # Items
        ctk.CTkLabel(details_frame, text="Items:").pack(anchor=tk.W, padx=5, pady=5)
        
        columns = ("Description", "Amount")
        items_table = ttk.Treeview(details_frame, columns=columns, show="headings")
        for col in columns:
            items_table.heading(col, text=col)
        
        scrollbar = ttk.Scrollbar(details_frame, orient=tk.VERTICAL, command=items_table.yview)
        items_table.configure(yscrollcommand=scrollbar.set)
        
        items_table.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, pady=5)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        total = 0
        for item in bill.items:
            items_table.insert("", tk.END, values=(
                item.description,
                f"${item.amount:.2f}"
            ))
            total += item.amount
        
        # Total
        total_frame = ctk.CTkFrame(details_frame)
        total_frame.pack(fill=tk.X, pady=5)
        
        ctk.CTkLabel(total_frame, text="Total Amount:").pack(side=tk.LEFT, padx=5)
        ctk.CTkLabel(total_frame, text=f"${total:.2f}").pack(side=tk.LEFT, padx=5)
        
        # Actions
        actions_frame = ctk.CTkFrame(self)
        actions_frame.pack(fill=tk.X, padx=10, pady=10)
        
        if bill.payment_status == "pending":
            self.mark_paid_button = ctk.CTkButton(
                actions_frame,
                text="Mark as Paid",
                command=self.mark_paid
            )
            self.mark_paid_button.pack(side=tk.LEFT, padx=5)
        
        self.edit_button = ctk.CTkButton(
            actions_frame,
            text="Edit",
            command=self.edit_bill
        )
        self.edit_button.pack(side=tk.RIGHT, padx=5)
        
        self.close_button = ctk.CTkButton(
            actions_frame,
            text="Close",
            command=self.destroy,
            fg_color="transparent",
            border_width=2
        )
        self.close_button.pack(side=tk.RIGHT, padx=5)
    
    def mark_paid(self):
        if messagebox.askyesno("Confirm", "Mark this bill as paid?"):
            BillingController.update_bill_status(
                self.bill.bill_id,
                "paid"
            )
            self.destroy()
    
    def edit_bill(self):
        self.destroy()
        dialog = BillDialog(self.master, self.bill)
        dialog.focus()
    
    def show_feedback(self):
        """Show feedback management view"""
        self.clear_content()
        feedback_frame = FeedbackManagementFrame(self.content_frame)
        feedback_frame.pack(fill=tk.BOTH, expand=True)

class FeedbackManagementFrame(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        
        # Create header
        self.header = ctk.CTkLabel(
            self,
            text="Feedback Management",
            font=ctk.CTkFont(size=20, weight="bold")
        )
        self.header.pack(pady=10)
        
        # Create controls
        controls_frame = ctk.CTkFrame(self)
        controls_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # Date filter
        self.date_label = ctk.CTkLabel(controls_frame, text="Date Range:")
        self.date_label.pack(side=tk.LEFT, padx=5)
        
        self.start_date = DateEntry(
            controls_frame,
            width=12,
            background='darkblue',
            foreground='white',
            borderwidth=2
        )
        self.start_date.pack(side=tk.LEFT, padx=5)
        
        self.end_date = DateEntry(
            controls_frame,
            width=12,
            background='darkblue',
            foreground='white',
            borderwidth=2
        )
        self.end_date.pack(side=tk.LEFT, padx=5)
        
        # Rating filter
        self.rating_label = ctk.CTkLabel(controls_frame, text="Rating:")
        self.rating_label.pack(side=tk.LEFT, padx=5)
        
        self.rating_var = tk.StringVar(value="all")
        self.rating_combo = ctk.CTkComboBox(
            controls_frame,
            values=["all", "1", "2", "3", "4", "5"],
            variable=self.rating_var
        )
        self.rating_combo.pack(side=tk.LEFT, padx=5)
        
        # Search
        self.search_entry = ctk.CTkEntry(
            controls_frame,
            placeholder_text="Search by patient or doctor name..."
        )
        self.search_entry.pack(side=tk.LEFT, padx=5)
        
        self.search_button = ctk.CTkButton(
            controls_frame,
            text="Search",
            command=self.search_feedback
        )
        self.search_button.pack(side=tk.LEFT, padx=5)
        
        self.refresh_button = ctk.CTkButton(
            controls_frame,
            text="Refresh",
            fg_color="transparent",
            border_width=2,
            command=self.load_feedback
        )
        self.refresh_button.pack(side=tk.LEFT, padx=5)
        
        # Statistics frame
        stats_frame = ctk.CTkFrame(self)
        stats_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # Average rating
        avg_frame = ctk.CTkFrame(stats_frame)
        avg_frame.pack(side=tk.LEFT, padx=20, pady=5)
        
        ctk.CTkLabel(avg_frame, text="Average Rating:").pack()
        self.avg_rating_label = ctk.CTkLabel(
            avg_frame,
            text="0.0",
            font=ctk.CTkFont(size=24, weight="bold")
        )
        self.avg_rating_label.pack()
        
        # Total feedback count
        count_frame = ctk.CTkFrame(stats_frame)
        count_frame.pack(side=tk.LEFT, padx=20, pady=5)
        
        ctk.CTkLabel(count_frame, text="Total Feedback:").pack()
        self.feedback_count_label = ctk.CTkLabel(
            count_frame,
            text="0",
            font=ctk.CTkFont(size=24, weight="bold")
        )
        self.feedback_count_label.pack()
        
        # Rating distribution
        dist_frame = ctk.CTkFrame(stats_frame)
        dist_frame.pack(side=tk.RIGHT, padx=20, pady=5, fill=tk.X, expand=True)
        
        ctk.CTkLabel(dist_frame, text="Rating Distribution:").pack()
        self.dist_labels = {}
        for i in range(5, 0, -1):
            row = ctk.CTkFrame(dist_frame)
            row.pack(fill=tk.X)
            
            ctk.CTkLabel(row, text=f"{i} ★", width=30).pack(side=tk.LEFT)
            progress = ctk.CTkProgressBar(row)
            progress.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
            progress.set(0)
            
            count_label = ctk.CTkLabel(row, text="0", width=30)
            count_label.pack(side=tk.LEFT)
            
            self.dist_labels[i] = (progress, count_label)
        
        # Create table
        self.create_table()
        self.load_feedback()
    
    def create_table(self):
        columns = (
            "ID", "Patient", "Doctor", "Rating", 
            "Date", "Status", "Actions"
        )
        self.table = ttk.Treeview(self, columns=columns, show="headings")
        
        # Configure columns
        for col in columns:
            self.table.heading(col, text=col)
            width = 150 if col in ["Patient", "Doctor"] else 100
            self.table.column(col, width=width)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(self, orient=tk.VERTICAL, command=self.table.yview)
        self.table.configure(yscrollcommand=scrollbar.set)
        
        # Pack table and scrollbar
        self.table.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=5)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Bind events
        self.table.bind("<Double-1>", self.on_feedback_select)
    
    def load_feedback(self):
        # Clear existing items
        for item in self.table.get_children():
            self.table.delete(item)
        
        # Get feedback based on filters
        start_date = self.start_date.get_date()
        end_date = self.end_date.get_date()
        rating = self.rating_var.get()
        
        feedback_list = FeedbackController.get_feedback(
            start_date=start_date,
            end_date=end_date,
            rating=int(rating) if rating != "all" else None
        )
        
        # Update statistics
        total_count = len(feedback_list)
        self.feedback_count_label.configure(text=str(total_count))
        
        if total_count > 0:
            avg_rating = sum(f.rating for f in feedback_list) / total_count
            self.avg_rating_label.configure(text=f"{avg_rating:.1f}")
            
            # Update distribution
            rating_counts = {i: 0 for i in range(1, 6)}
            for f in feedback_list:
                rating_counts[f.rating] += 1
            
            for rating, (progress, label) in self.dist_labels.items():
                count = rating_counts[rating]
                percentage = count / total_count if total_count > 0 else 0
                progress.set(percentage)
                label.configure(text=str(count))
        
        # Populate table
        for feedback in feedback_list:
            # Get patient and doctor info
            patient = PatientController.get_patient_by_id(feedback.patient_id)
            doctor = DoctorController.get_doctor_by_id(feedback.doctor_id)
            
            patient_name = f"{patient.first_name} {patient.last_name}" if patient else f"Patient {feedback.patient_id}"
            doctor_name = f"{doctor.first_name} {doctor.last_name}" if doctor else f"Doctor {feedback.doctor_id}"
            
            # Format feedback date and rating
            feedback_date = feedback.submitted_at.strftime("%m/%d/%Y") if hasattr(feedback, "submitted_at") and hasattr(feedback.submitted_at, "strftime") else "Unknown"
            rating_stars = "★" * feedback.rating
            
            status = feedback.status if hasattr(feedback, "status") else "pending"
            
            self.table.insert("", tk.END, values=(
                feedback.feedback_id,
                patient_name,
                doctor_name,
                rating_stars,
                feedback_date,
                status,
                "View Details"
            ))
    
    def search_feedback(self):
        search_term = self.search_entry.get().strip().lower()
        if not search_term:
            self.load_feedback()
            return
        
        # Clear existing items
        for item in self.table.get_children():
            self.table.delete(item)
        
        # Get feedback based on filters
        start_date = self.start_date.get_date()
        end_date = self.end_date.get_date()
        rating = self.rating_var.get()
        
        feedback_list = FeedbackController.get_feedback(
            start_date=start_date,
            end_date=end_date,
            rating=int(rating) if rating != "all" else None
        )
        
        # Filter feedback based on search term
        filtered_feedback = []
        for feedback in feedback_list:
            patient_name = f"{feedback.patient.first_name} {feedback.patient.last_name}".lower()
            doctor_name = f"{feedback.doctor.first_name} {feedback.doctor.last_name}".lower()
            
            if search_term in patient_name or search_term in doctor_name:
                filtered_feedback.append(feedback)
                self.table.insert("", tk.END, values=(
                    feedback.feedback_id,
                    f"{feedback.patient.first_name} {feedback.patient.last_name}",
                    f"{feedback.doctor.first_name} {feedback.doctor.last_name}",
                    "★" * feedback.rating,
                    feedback.feedback_date.strftime("%m/%d/%Y"),
                    feedback.status.title(),
                    "View Details"
                ))
        
        # Update statistics for filtered results
        total_count = len(filtered_feedback)
        self.feedback_count_label.configure(text=str(total_count))
        
        if total_count > 0:
            avg_rating = sum(f.rating for f in filtered_feedback) / total_count
            self.avg_rating_label.configure(text=f"{avg_rating:.1f}")
            
            # Update distribution
            rating_counts = {i: 0 for i in range(1, 6)}
            for f in filtered_feedback:
                rating_counts[f.rating] += 1
            
            for rating, (progress, label) in self.dist_labels.items():
                count = rating_counts[rating]
                percentage = count / total_count if total_count > 0 else 0
                progress.set(percentage)
                label.configure(text=str(count))
    
    def on_feedback_select(self, event):
        item = self.table.selection()[0]
        feedback_id = self.table.item(item)["values"][0]
        feedback = FeedbackController.get_feedback_by_id(feedback_id)
        if feedback:
            dialog = FeedbackDetailsDialog(self, feedback)
            dialog.focus()

class FeedbackDetailsDialog(ctk.CTkToplevel):
    def __init__(self, parent, feedback):
        super().__init__(parent)
        self.feedback = feedback
        self.title(f"Feedback Details - {feedback.feedback_id}")
        self.geometry("600x400")
        
        # Details frame
        details_frame = ctk.CTkFrame(self)
        details_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Basic information
        info_frame = ctk.CTkFrame(details_frame)
        info_frame.pack(fill=tk.X, pady=5)
        
        labels = [
            ("Feedback ID:", str(feedback.feedback_id)),
            ("Patient:", f"{feedback.patient.first_name} {feedback.patient.last_name}"),
            ("Doctor:", f"{feedback.doctor.first_name} {feedback.doctor.last_name}"),
            ("Rating:", "★" * feedback.rating),
            ("Date:", feedback.feedback_date.strftime("%m/%d/%Y")),
            ("Status:", feedback.status.title())
        ]
        
        for label, value in labels:
            row = ctk.CTkFrame(info_frame)
            row.pack(fill=tk.X, pady=2)
            
            ctk.CTkLabel(row, text=label, width=100).pack(side=tk.LEFT, padx=5)
            ctk.CTkLabel(row, text=value).pack(side=tk.LEFT, padx=5)
        
        # Feedback text
        ctk.CTkLabel(details_frame, text="Feedback:").pack(anchor=tk.W, padx=5, pady=5)
        
        feedback_text = ctk.CTkTextbox(details_frame, height=150)
        feedback_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        feedback_text.insert("1.0", feedback.feedback_text)
        feedback_text.configure(state="disabled")
        
        # Response section
        response_frame = ctk.CTkFrame(details_frame)
        response_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        ctk.CTkLabel(response_frame, text="Response:").pack(anchor=tk.W)
        
        self.response_text = ctk.CTkTextbox(response_frame, height=100)
        self.response_text.pack(fill=tk.BOTH, expand=True, pady=5)
        
        if feedback.response:
            self.response_text.insert("1.0", feedback.response)
            self.response_text.configure(state="disabled")
        
        # Actions
        actions_frame = ctk.CTkFrame(self)
        actions_frame.pack(fill=tk.X, padx=10, pady=10)
        
        if not feedback.response:
            self.respond_button = ctk.CTkButton(
                actions_frame,
                text="Submit Response",
                command=self.submit_response
            )
            self.respond_button.pack(side=tk.LEFT, padx=5)
        
        if feedback.status == "pending":
            self.resolve_button = ctk.CTkButton(
                actions_frame,
                text="Mark as Resolved",
                command=self.mark_resolved
            )
            self.resolve_button.pack(side=tk.LEFT, padx=5)
        
        self.close_button = ctk.CTkButton(
            actions_frame,
            text="Close",
            command=self.destroy,
            fg_color="transparent",
            border_width=2
        )
        self.close_button.pack(side=tk.RIGHT, padx=5)
    
    def submit_response(self):
        response = self.response_text.get("1.0", tk.END).strip()
        if not response:
            messagebox.showerror("Error", "Please enter a response")
            return
        
        if messagebox.askyesno("Confirm", "Submit this response?"):
            FeedbackController.add_response(
                self.feedback.feedback_id,
                response
            )
            self.destroy()
    
    def mark_resolved(self):
        if messagebox.askyesno("Confirm", "Mark this feedback as resolved?"):
            FeedbackController.update_feedback_status(
                self.feedback.feedback_id,
                "resolved"
            )
            self.destroy()


class ReportsManagementFrame(ctk.CTkFrame):
    """Simple reports frame for admin to run predefined queries and view results."""
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)

        # Header
        self.header = ctk.CTkLabel(self, text="Reports", font=ctk.CTkFont(size=20, weight="bold"))
        self.header.pack(pady=10)

        # Controls frame
        controls_frame = ctk.CTkFrame(self)
        controls_frame.pack(fill=tk.X, padx=10, pady=5)

        # Reports dropdown
        self.report_combo = ctk.CTkComboBox(
            controls_frame,
            values=[
                "Appointments",
                "Doctor Workload",
                "Patients With Same Blood Group",
                "Patient Pending Bills"
            ],
            width=260
        )
        self.report_combo.set("Appointments")
        self.report_combo.pack(side=tk.LEFT, padx=5)

        # Blood group selector (used by some reports)
        self.blood_group_combo = ctk.CTkComboBox(
            controls_frame,
            values=["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"],
            width=120
        )
        self.blood_group_combo.set("A+")
        # start hidden; shown when report selected
        self.blood_group_combo.pack(side=tk.LEFT, padx=5)
        self.blood_group_combo.pack_forget()

        # Patient selector (for Patient Pending Bills)
        patients = PatientController.get_all_patients()
        if patients:
            patient_names = [f"{p.patient_id}: {p.first_name} {p.last_name}" for p in patients]
        else:
            patient_names = ["No patients available"]

        self.patient_dict = {name: int(name.split(":")[0]) for name in patient_names if ":" in name}

        self.patient_combo = ctk.CTkComboBox(controls_frame, values=patient_names, width=300)
        if patient_names:
            self.patient_combo.set(patient_names[0])
        # start hidden
        self.patient_combo.pack(side=tk.LEFT, padx=5)
        self.patient_combo.pack_forget()

        # Bind selection change to update visibility of parameter controls
        try:
            # CTkComboBox supports command in newer versions; try to attach
            self.report_combo.configure(command=lambda value=None: self.on_report_change())
        except Exception:
            # Fallback: try ttk-style binding
            try:
                self.report_combo.bind("<<ComboboxSelected>>", lambda e: self.on_report_change())
            except Exception:
                pass

        # Run button
        self.run_report_button = ctk.CTkButton(controls_frame, text="Run", command=self.run_selected_report)
        self.run_report_button.pack(side=tk.LEFT, padx=5)

        # Export CSV button
        self.export_button = ctk.CTkButton(controls_frame, text="Export CSV", command=self.export_csv)
        self.export_button.pack(side=tk.LEFT, padx=5)

        # Create results table
        self.create_table()

        # Storage for current results
        self.current_columns = []
        self.current_rows = []

    def create_table(self):
        self.tree = ttk.Treeview(self, show="headings")
        self.tree.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        vsb = ttk.Scrollbar(self, orient=tk.VERTICAL, command=self.tree.yview)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree.configure(yscrollcommand=vsb.set)

    def run_appointments_report(self):
        """Run the provided appointments query and populate the treeview."""
        query = """
    SELECT 
        a.appointment_date, 
        a.appointment_time, 
        p.first_name, 
        p.last_name, 
        d.full_name AS doctor_name
    FROM Appointments AS a
    JOIN Patients AS p ON a.patient_id = p.patient_id
    JOIN Doctors AS d ON a.doctor_id = d.doctor_id
    WHERE a.status = 'Scheduled'
    ORDER BY a.appointment_date, a.appointment_time;
        """

        conn = None
        cursor = None
        try:
            conn = create_connection()
            if conn is None:
                messagebox.showerror("DB Error", "Could not connect to the database for reports.")
                return

            cursor = conn.cursor()
            cursor.execute(query)
            rows = cursor.fetchall()
            cols = [desc[0] for desc in cursor.description] if cursor.description else []

            # Save current results
            self.current_columns = cols
            self.current_rows = rows

            # Populate treeview
            # Clear existing
            for col in self.tree["columns"]:
                try:
                    self.tree.heading(col, text="")
                except Exception:
                    pass
            self.tree.delete(*self.tree.get_children())

            self.tree["columns"] = cols
            for c in cols:
                self.tree.heading(c, text=c)
                self.tree.column(c, width=140, anchor="w")

            for r in rows:
                self.tree.insert("", tk.END, values=r)

        except Exception as e:
            messagebox.showerror("Query Error", f"Failed to run report: {e}")
        finally:
            try:
                if cursor:
                    cursor.close()
            except Exception:
                pass
            try:
                if conn and getattr(conn, 'is_connected', lambda: True)():
                    conn.close()
            except Exception:
                pass

    def run_doctor_workload_report(self):
        """Run the doctor workload query and populate the treeview."""
        query = """
    SELECT 
        d.full_name, 
        d.specialization,
        COUNT(a.appointment_id) AS scheduled_appointments
    FROM Appointments AS a
    RIGHT JOIN Doctors AS d ON a.doctor_id = d.doctor_id
    GROUP BY d.doctor_id
    ORDER BY scheduled_appointments DESC;
        """

        conn = None
        cursor = None
        try:
            conn = create_connection()
            if conn is None:
                messagebox.showerror("DB Error", "Could not connect to the database for reports.")
                return

            cursor = conn.cursor()
            cursor.execute(query)
            rows = cursor.fetchall()
            cols = [desc[0] for desc in cursor.description] if cursor.description else []

            # Save current results
            self.current_columns = cols
            self.current_rows = rows

            # Populate treeview
            for col in self.tree["columns"]:
                try:
                    self.tree.heading(col, text="")
                except Exception:
                    pass
            self.tree.delete(*self.tree.get_children())

            self.tree["columns"] = cols
            for c in cols:
                self.tree.heading(c, text=c)
                self.tree.column(c, width=160, anchor="w")

            for r in rows:
                self.tree.insert("", tk.END, values=r)

        except Exception as e:
            messagebox.showerror("Query Error", f"Failed to run report: {e}")
        finally:
            try:
                if cursor:
                    cursor.close()
            except Exception:
                pass
            try:
                if conn and getattr(conn, 'is_connected', lambda: True)():
                    conn.close()
            except Exception:
                pass

    def run_selected_report(self):
        """Run the report selected in the dropdown using `src.reports.admin_reports`."""
        try:
            from src.reports import admin_reports
        except Exception as e:
            messagebox.showerror("Import Error", f"Failed to import reports module: {e}")
            return

        selection = self.report_combo.get()
        try:
            if selection == "Appointments":
                cols, rows = admin_reports.get_appointments_report()
            elif selection == "Doctor Workload":
                cols, rows = admin_reports.get_doctor_workload_report()
            elif selection == "Patients With Same Blood Group":
                blood_group = self.blood_group_combo.get()
                if not blood_group:
                    messagebox.showwarning("Input", "Please select a blood group for this report.")
                    return
                cols, rows = admin_reports.get_patients_with_same_blood_group(blood_group)
            elif selection == "Patient Pending Bills":
                # Show all patients' pending bills (no patient selection needed)
                cols, rows = admin_reports.get_all_patients_pending_bills()
            else:
                messagebox.showwarning("Report", "Unknown report selected")
                return

            # Save and populate
            self.current_columns = cols
            self.current_rows = rows

            # Clear existing
            for col in self.tree["columns"]:
                try:
                    self.tree.heading(col, text="")
                except Exception:
                    pass
            self.tree.delete(*self.tree.get_children())

            self.tree["columns"] = cols
            for c in cols:
                self.tree.heading(c, text=c)
                self.tree.column(c, width=160, anchor="w")

            for r in rows:
                self.tree.insert("", tk.END, values=r)

        except Exception as e:
            messagebox.showerror("Report Error", f"Failed to run selected report: {e}")

    def on_report_change(self):
        """Show or hide parameter controls depending on selected report."""
        try:
            selection = self.report_combo.get()
        except Exception:
            # If we can't get selection, do nothing
            return

        # By default hide both
        try:
            self.blood_group_combo.pack_forget()
        except Exception:
            pass
        try:
            self.patient_combo.pack_forget()
        except Exception:
            pass

        if selection == "Patients With Same Blood Group":
            try:
                self.blood_group_combo.pack(side=tk.LEFT, padx=5)
            except Exception:
                pass
        # Patient Pending Bills no longer needs patient selector - shows all patients

    def export_csv(self):
        try:
            if not self.current_rows:
                messagebox.showinfo("Export", "No data to export. Run a report first.")
                return

            from tkinter import filedialog
            path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files","*.csv")])
            if not path:
                return

            import csv
            with open(path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                if self.current_columns:
                    writer.writerow(self.current_columns)
                for r in self.current_rows:
                    writer.writerow(r)

            messagebox.showinfo("Export", f"Report exported to {path}")
        except Exception as e:
            messagebox.showerror("Export Error", str(e))