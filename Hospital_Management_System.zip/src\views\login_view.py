"""
Login view module
"""
import os
import sys
import customtkinter as ctk
import tkinter as tk
from PIL import Image, ImageTk
from datetime import datetime
from src.views.base_view import BaseView
from src.views.admin_view import AdminView
from src.views.patient_view import PatientView
from src.controllers.auth_controller import AuthController
from src.data.memory_store import Patient
from src.utils.helpers import validate_email, validate_phone, validate_password_strength
import tkinter.messagebox as messagebox

class PatientRegistrationDialog:
    """Patient registration dialog"""
    
    def __init__(self, parent=None):
        """Initialize registration dialog"""
        # Create a new Toplevel window
        self.window = tk.Toplevel(parent)
        self.window.title("Patient Registration")
        self.window.geometry("550x650")
        self.window.resizable(False, False)
        
        # Set the window to be modal
        self.window.transient(parent)
        self.window.grab_set()
        
        # Position the window relative to parent
        if parent:
            x = parent.winfo_x() + 100
            y = parent.winfo_y() + 50
            self.window.geometry(f"+{x}+{y}")
            
        # Customize appearance
        self.window.configure(bg="#1E1E1E" if ctk.get_appearance_mode() == "Dark" else "#F0F0F0")
            
        # Create main frame
        self.main_frame = ctk.CTkFrame(self.window)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)
        
        # Create header with prominent styling
        header_frame = ctk.CTkFrame(self.main_frame, fg_color="#1f6aa5", corner_radius=0)
        header_frame.pack(fill="x", pady=(0, 15))
        
        self.header_label = ctk.CTkLabel(
            header_frame,
            text="Patient Registration",
            font=ctk.CTkFont(size=22, weight="bold"),
            text_color="white"
        )
        self.header_label.pack(pady=15)
        
        # Create form fields
        self.create_form_fields()
        
        # Create buttons
        self.create_buttons()
        
        # Focus on first field
        self.window.after(100, lambda: self.username_field.focus())
    
    def focus(self):
        """Focus the window"""
        self.window.focus_force()
        
    def destroy(self):
        """Close the dialog"""
        self.window.destroy()
    
    def create_form_fields(self):
        """Create all form fields"""
        form_frame = ctk.CTkScrollableFrame(self.main_frame, height=450)
        form_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.username_field = ctk.CTkEntry(form_frame, placeholder_text="Username (min. 4 characters)", height=35)
        self.username_field.pack(fill=tk.X, padx=10, pady=5)
        
        # Password field with show/hide toggle
        password_frame = ctk.CTkFrame(form_frame)
        password_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.password_field = ctk.CTkEntry(password_frame, placeholder_text="Password", show="•", height=35)
        self.password_field.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=(5, 5))
        
        self.show_password_btn = ctk.CTkButton(
            password_frame,
            text="👁",
            width=35,
            height=35,
            command=self.toggle_password
        )
        self.show_password_btn.pack(side=tk.RIGHT)
        
        # Confirm password field with show/hide toggle
        confirm_frame = ctk.CTkFrame(form_frame)
        confirm_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.confirm_password_field = ctk.CTkEntry(confirm_frame, placeholder_text="Confirm Password", show="•", height=35)
        self.confirm_password_field.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=(5, 5))
        
        self.show_confirm_btn = ctk.CTkButton(
            confirm_frame,
            text="👁",
            width=35,
            height=35,
            command=self.toggle_confirm_password
        )
        self.show_confirm_btn.pack(side=tk.RIGHT)
        
        self.first_name_field = ctk.CTkEntry(form_frame, placeholder_text="First Name", height=35)
        self.first_name_field.pack(fill=tk.X, padx=10, pady=5)
        
        self.last_name_field = ctk.CTkEntry(form_frame, placeholder_text="Last Name", height=35)
        self.last_name_field.pack(fill=tk.X, padx=10, pady=5)
        
        # Gender selection
        gender_frame = ctk.CTkFrame(form_frame)
        gender_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ctk.CTkLabel(gender_frame, text="Gender:", font=ctk.CTkFont(size=14)).pack(side=tk.LEFT, padx=5)
        self.gender_var = tk.StringVar(value="")
        self.gender_male = ctk.CTkRadioButton(gender_frame, text="Male", variable=self.gender_var, value="Male")
        self.gender_female = ctk.CTkRadioButton(gender_frame, text="Female", variable=self.gender_var, value="Female")
        self.gender_other = ctk.CTkRadioButton(gender_frame, text="Other", variable=self.gender_var, value="Other")
        
        self.gender_male.pack(side=tk.LEFT, padx=5)
        self.gender_female.pack(side=tk.LEFT, padx=5)
        self.gender_other.pack(side=tk.LEFT, padx=5)
        
        # Date of birth
        dob_frame = ctk.CTkFrame(form_frame)
        dob_frame.pack(fill=tk.X, padx=10, pady=5)
        
        self.dob_label = ctk.CTkLabel(dob_frame, text="Date of Birth:", font=ctk.CTkFont(size=14))
        self.dob_label.pack(side=tk.LEFT, padx=5)
        
        try:
            from tkcalendar import DateEntry
            self.dob_field = DateEntry(dob_frame, width=20, date_pattern='mm/dd/yyyy', 
                                      background="#1f6aa5" if ctk.get_appearance_mode() == "Dark" else "#2D5A98",
                                      foreground='white')
            self.dob_field.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        except ImportError:
            messagebox.showwarning("Module Missing", "The tkcalendar module is missing. Please install it using pip.")
            self.dob_field = ctk.CTkEntry(dob_frame, placeholder_text="MM/DD/YYYY")
            self.dob_field.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
            
            # Method to get date from entry if DateEntry is not available
            self.dob_field.get_date = lambda: datetime.strptime(self.dob_field.get(), "%m/%d/%Y").date()
        
        # Blood group selection
        bg_frame = ctk.CTkFrame(form_frame)
        bg_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ctk.CTkLabel(bg_frame, text="Blood Group:", font=ctk.CTkFont(size=14)).pack(side=tk.LEFT, padx=5)
        
        self.blood_group_field = ctk.CTkComboBox(
            bg_frame,
            values=["Select Blood Group", "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"],
            width=150
        )
        self.blood_group_field.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # Contact information section
        contact_label = ctk.CTkLabel(form_frame, text="Contact Information", font=ctk.CTkFont(size=16, weight="bold"))
        contact_label.pack(anchor="w", padx=10, pady=(15, 5))
        
        self.contact_field = ctk.CTkEntry(form_frame, placeholder_text="Contact Number", height=35)
        self.contact_field.pack(fill=tk.X, padx=10, pady=5)
        
        self.email_field = ctk.CTkEntry(form_frame, placeholder_text="Email Address", height=35)
        self.email_field.pack(fill=tk.X, padx=10, pady=5)
        
        self.address_field = ctk.CTkEntry(form_frame, placeholder_text="Address", height=35)
        self.address_field.pack(fill=tk.X, padx=10, pady=5)
        
        # Medical history
        medical_label = ctk.CTkLabel(form_frame, text="Medical History", font=ctk.CTkFont(size=16, weight="bold"))
        medical_label.pack(anchor="w", padx=10, pady=(15, 5))
        
        self.medical_history_field = ctk.CTkTextbox(form_frame, height=80)
        self.medical_history_field.pack(fill=tk.X, padx=10, pady=5)
    
    def toggle_password(self):
        """Toggle password visibility"""
        if self.password_field.cget("show") == "":
            self.password_field.configure(show="•")
            self.show_password_btn.configure(text="👁")
        else:
            self.password_field.configure(show="")
            self.show_password_btn.configure(text="🔒")

    def toggle_confirm_password(self):
        """Toggle confirm password visibility"""
        if self.confirm_password_field.cget("show") == "":
            self.confirm_password_field.configure(show="•")
            self.show_confirm_btn.configure(text="👁")
        else:
            self.confirm_password_field.configure(show="")
            self.show_confirm_btn.configure(text="🔒")

    def create_buttons(self):
        """Create action buttons"""
        button_frame = ctk.CTkFrame(self.main_frame)
        button_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.register_button = ctk.CTkButton(
            button_frame,
            text="Register",
            command=self.register,
            font=ctk.CTkFont(size=16, weight="bold"),
            height=40,
            fg_color="#FF5722",
            hover_color="#E64A19"
        )
        self.register_button.pack(side=tk.LEFT, expand=True, padx=5)
        
        self.cancel_button = ctk.CTkButton(
            button_frame,
            text="Cancel",
            fg_color="transparent",
            border_width=2,
            command=self.destroy,
            font=ctk.CTkFont(size=16),
            height=40
        )
        self.cancel_button.pack(side=tk.LEFT, expand=True, padx=5)
    
    def register(self):
        """Handle registration button click"""
        from src.controllers.patient_controller import PatientController
        
        # Validate all fields
        username = self.username_field.get().strip()
        password = self.password_field.get()
        confirm_password = self.confirm_password_field.get()
        first_name = self.first_name_field.get().strip()
        last_name = self.last_name_field.get().strip()
        gender = self.gender_var.get()
        
        try:
            dob = self.dob_field.get_date()
        except Exception as e:
            messagebox.showwarning("Validation Error", f"Invalid date format: {str(e)}")
            return
        
        blood_group = self.blood_group_field.get()
        if blood_group == "Select Blood Group":
            blood_group = None
        
        contact = self.contact_field.get().strip()
        email = self.email_field.get().strip()
        address = self.address_field.get().strip()
        medical_history = self.medical_history_field.get("1.0", tk.END).strip()
        
        # Validation
        if not username or len(username) < 4:
            messagebox.showwarning("Validation Error", "Username must be at least 4 characters.")
            return
        
        if not password:
            messagebox.showwarning("Validation Error", "Password is required.")
            return
        
        if password != confirm_password:
            messagebox.showwarning("Validation Error", "Passwords do not match.")
            return
        
        if not validate_password_strength(password):
            messagebox.showwarning("Validation Error", 
                              "Password must be at least 8 characters with at least one letter, one number, and one special character.")
            return
        
        if not first_name or not last_name:
            messagebox.showwarning("Validation Error", "First name and last name are required.")
            return
        
        if not gender:
            messagebox.showwarning("Validation Error", "Please select a gender.")
            return
        
        # Validate age
        today = datetime.now().date()
        age = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
        if age < 1:
            messagebox.showwarning("Validation Error", "Invalid date of birth.")
            return
        
        if not contact:
            messagebox.showwarning("Validation Error", "Contact number is required.")
            return
        
        if not validate_phone(contact):
            messagebox.showwarning("Validation Error", "Invalid contact number format.")
            return
        
        if email and not validate_email(email):
            messagebox.showwarning("Validation Error", "Invalid email format.")
            return
        
        # Validate registration data with auth controller
        success, message = AuthController.register_patient(username, password, confirm_password)
        if not success:
            messagebox.showwarning("Registration Error", message)
            return
        
        # Register patient
        try:
            success, result = PatientController.register_patient(
                username, password, first_name, last_name, gender, dob, contact,
                email, blood_group, address, medical_history
            )
            
            if success:
                messagebox.showinfo("Registration Successful", 
                                   "Your patient account has been created successfully!\n\n" +
                                   f"Username: {username}\n\n" +
                                   "You can now login with these credentials.")
                self.destroy()
            else:
                messagebox.showwarning("Registration Error", str(result))
        except Exception as e:
            messagebox.showerror("Registration Error", f"An error occurred: {str(e)}")


class LoginView(BaseView):
    """Login view implementation"""
    
    def __init__(self):
        """Initialize login view"""
        super().__init__("Hospital Management System - Login", 800, 700)
        
        # The main_frame is now created in the BaseView and centered vertically
        
        # Create title and subtitle
        title_frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        title_frame.pack(pady=(10, 5), padx=20)
        
        title = ctk.CTkLabel(
            title_frame,
            text="Hospital Management System",
            font=ctk.CTkFont(size=24, weight="bold"),
            text_color="#1f6aa5" if ctk.get_appearance_mode() == "Dark" else "#2D5A98"
        )
        title.pack()
        
        subtitle = ctk.CTkLabel(
            title_frame,
            text="Please log in or create an account to continue",
            font=ctk.CTkFont(size=14),
            text_color="gray"
        )
        subtitle.pack(pady=(5, 0))
        
        # Two column layout - centered with fixed height
        content_frame = ctk.CTkFrame(self.main_frame, fg_color="transparent", height=400)
        content_frame.pack(fill="both", expand=True, padx=40, pady=20)
        content_frame.pack_propagate(False)  # Prevent the frame from shrinking
        
        # Left column: Login
        left_frame = ctk.CTkFrame(
            content_frame,
            fg_color="#1E1E1E" if ctk.get_appearance_mode() == "Dark" else "#F0F0F0",
            corner_radius=10,
            border_width=2,
            border_color="#1f6aa5"
        )
        left_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        
        # Right column: Registration
        right_frame = ctk.CTkFrame(
            content_frame,
            fg_color="#1E1E1E" if ctk.get_appearance_mode() == "Dark" else "#F0F0F0",
            corner_radius=10,
            border_width=2,
            border_color="#FF5722"
        )
        right_frame.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
        
        # Configure grid weights
        content_frame.grid_columnconfigure(0, weight=1)
        content_frame.grid_columnconfigure(1, weight=1)
        content_frame.grid_rowconfigure(0, weight=1)
        
        # Login Form Header
        login_header = ctk.CTkLabel(
            left_frame,
            text="Login to Your Account",
            font=ctk.CTkFont(size=18, weight="bold")
        )
        login_header.pack(pady=(20, 15), padx=20)
        
        # Username field
        username_frame = ctk.CTkFrame(left_frame, fg_color="transparent")
        username_frame.pack(fill="x", padx=20, pady=(0, 10))
        
        username_label = ctk.CTkLabel(
            username_frame, 
            text="Username",
            font=ctk.CTkFont(size=14)
        )
        username_label.pack(anchor="w")
        
        self.username_field = ctk.CTkEntry(
            username_frame,
            placeholder_text="Enter your username",
            height=35
        )
        self.username_field.pack(fill="x", pady=(5, 0))
        
        # Password field
        password_frame = ctk.CTkFrame(left_frame, fg_color="transparent")
        password_frame.pack(fill="x", padx=20, pady=(0, 15))
        
        password_label = ctk.CTkLabel(
            password_frame, 
            text="Password",
            font=ctk.CTkFont(size=14)
        )
        password_label.pack(anchor="w")
        
        password_input_frame = ctk.CTkFrame(password_frame, fg_color="transparent")
        password_input_frame.pack(fill="x", pady=(5, 0))
        
        self.password_field = ctk.CTkEntry(
            password_input_frame,
            placeholder_text="Enter your password",
            show="•",
            height=35
        )
        self.password_field.pack(side="left", fill="x", expand=True)
        
        self.show_password_btn = ctk.CTkButton(
            password_input_frame,
            text="👁",
            width=35,
            height=35,
            command=self.toggle_password_visibility
        )
        self.show_password_btn.pack(side="right", padx=(5, 0))
        
        # Role selection
        role_frame = ctk.CTkFrame(left_frame, fg_color="transparent")
        role_frame.pack(fill="x", padx=20, pady=(0, 15))
        
        self.role_var = tk.StringVar(value="patient")
        
        role_label = ctk.CTkLabel(
            role_frame, 
            text="Login as:",
            font=ctk.CTkFont(size=14)
        )
        role_label.pack(side="left", padx=(0, 10))
        
        self.role_patient = ctk.CTkRadioButton(
            role_frame,
            text="Patient",
            variable=self.role_var,
            value="patient",
            font=ctk.CTkFont(size=14)
        )
        self.role_patient.pack(side="left", padx=(0, 10))
        
        self.role_admin = ctk.CTkRadioButton(
            role_frame,
            text="Administrator",
            variable=self.role_var,
            value="admin",
            font=ctk.CTkFont(size=14)
        )
        self.role_admin.pack(side="left")
        
        # Login button
        login_button_frame = ctk.CTkFrame(left_frame, fg_color="transparent")
        login_button_frame.pack(fill="x", padx=20, pady=(5, 20))
        
        self.login_button = ctk.CTkButton(
            login_button_frame,
            text="Login",
            command=self.login,
            font=ctk.CTkFont(size=16, weight="bold"),
            height=40
        )
        self.login_button.pack(fill="x")
        
        # Registration section
        # Header with NEW badge
        reg_header_frame = ctk.CTkFrame(right_frame, fg_color="transparent")
        reg_header_frame.pack(pady=(20, 5), padx=20)
        
        reg_header = ctk.CTkLabel(
            reg_header_frame,
            text="New Patient Registration",
            font=ctk.CTkFont(size=18, weight="bold")
        )
        reg_header.pack(side="left")
        
        new_badge = ctk.CTkLabel(
            reg_header_frame,
            text="NEW",
            font=ctk.CTkFont(size=10, weight="bold"),
            text_color="white",
            fg_color="#FF5722",
            corner_radius=5,
            width=30
        )
        new_badge.pack(side="left", padx=10)
        
        # Description
        reg_desc = ctk.CTkLabel(
            right_frame,
            text="Create an account to manage appointments\nand health records",
            font=ctk.CTkFont(size=14)
        )
        reg_desc.pack(pady=(5, 15), padx=20)
        
        # Benefits list
        benefits = [
            "✓ Book appointments online",
            "✓ View your medical history",
            "✓ Get reminders for appointments",
            "✓ Communicate with doctors"
        ]
        
        benefits_frame = ctk.CTkFrame(right_frame, fg_color="transparent")
        benefits_frame.pack(fill="x", padx=20, pady=(0, 15))
        
        for benefit in benefits:
            benefit_label = ctk.CTkLabel(
                benefits_frame,
                text=benefit,
                font=ctk.CTkFont(size=14),
                anchor="w"
            )
            benefit_label.pack(anchor="w", pady=5)
        
        # Register button
        register_button_frame = ctk.CTkFrame(right_frame, fg_color="transparent")
        register_button_frame.pack(fill="x", padx=20, pady=(10, 20))
        
        self.register_button = ctk.CTkButton(
            register_button_frame,
            text="Create New Patient Account →",
            command=self.show_registration,
            font=ctk.CTkFont(size=16, weight="bold"),
            height=40,
            fg_color="#FF5722",
            hover_color="#E64A19",
            border_width=0,
            corner_radius=8
        )
        self.register_button.pack(fill="x")
        
        # Footer
        footer_frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        footer_frame.pack(fill="x", pady=10)
        
        footer_text = ctk.CTkLabel(
            footer_frame,
            text="Need help? Contact system administrator",
            font=ctk.CTkFont(size=12)
        )
        footer_text.pack()
        
        # Bind enter key to login
        self.bind("<Return>", lambda e: self.login())
    
    # Methods removed as they are now integrated into __init__
    
    def login(self):
        """Handle login button click"""
        username = self.username_field.get().strip()
        password = self.password_field.get()
        is_patient = self.role_var.get() == "patient"
        
        # Validate inputs
        if not username or not password:
            self.show_error("Login Error", "Username and password are required.")
            return
        
        # Special handling for admin login
        if not is_patient and username == "admin":
            if password != "Admin@123":
                self.show_error("Login Error", "Invalid administrator credentials.")
                return
        
        # Authenticate user
        success, result = AuthController.login(username, password)
        
        if success:
            user = result
            
            # Check if the user role matches the selected role
            if is_patient and user.role != "patient":
                self.show_error("Login Error", "Invalid credentials for Patient login.")
                return
            
            if not is_patient and user.role != "admin":
                self.show_error("Login Error", "Invalid credentials for Administrator login.")
                return
            
            # Login successful
            self.set_status(f"Login successful. Welcome {username}!")
            
            # Open appropriate view based on role
            if user.role == "patient":
                # Get patient by user ID
                from src.controllers.patient_controller import PatientController
                patient = PatientController.get_patient_by_user_id(user.user_id)
                
                if patient:
                    self.withdraw()  # Hide the login window
                    self.patient_view = PatientView(patient)
                    self.patient_view.protocol("WM_DELETE_WINDOW", self.quit)
                    self.patient_view.mainloop()  # Start the patient view main loop
                else:
                    self.show_error("Login Error", "Patient profile not found.")
                    
            elif user.role == "admin":
                from src.views.admin_view import AdminView  # Import here to avoid circular imports
                
                self.withdraw()  # Hide the login window
                self.admin_view = AdminView(user)
                self.admin_view.protocol("WM_DELETE_WINDOW", self.quit)
                self.admin_view.mainloop()  # Start the admin view main loop
                
        else:
            # Login failed
            self.show_error("Login Failed", str(result))
    
    def toggle_password_visibility(self):
        """Toggle password visibility"""
        if self.password_field.cget("show") == "":
            self.password_field.configure(show="•")
            self.show_password_btn.configure(text="👁")
        else:
            self.password_field.configure(show="")
            self.show_password_btn.configure(text="🔒")

    def show_registration(self):
        """Show patient registration dialog"""
        try:
            # Create the registration dialog with proper reference to the parent window
            dialog = PatientRegistrationDialog(self)
            # This will make sure the dialog stays in focus until closed
            dialog.window.grab_set()
            dialog.window.focus_force()
            # Wait for the dialog to be closed before returning
            self.wait_window(dialog.window)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to open registration form: {str(e)}")
            import traceback
            traceback.print_exc()