"""
Configuration utilities for the Hospital Management System
"""
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

def load_styles():
    """
    Load application stylesheet
    
    Returns:
        str: CSS stylesheet content
    """
    style = """
    /* Global Styles */
    QWidget {
        font-family: 'Segoe UI', 'Roboto', sans-serif;
        font-size: 10pt;
    }
    
    /* Main Window */
    QMainWindow {
        background-color: #f5f5f5;
    }
    
    /* Push Buttons */
    QPushButton {
        background-color: #2196F3;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        min-width: 80px;
        font-weight: bold;
    }
    
    QPushButton:hover {
        background-color: #0d8aee;
    }
    
    QPushButton:pressed {
        background-color: #0b7ddb;
    }
    
    QPushButton:disabled {
        background-color: #b0bec5;
        color: #f5f5f5;
    }
    
    /* Primary Action Button */
    QPushButton#primaryButton {
        background-color: #1976D2;
        font-size: 11pt;
        padding: 10px 20px;
    }
    
    /* Secondary Action Button */
    QPushButton#secondaryButton {
        background-color: #78909c;
    }
    
    /* Danger Action Button */
    QPushButton#dangerButton {
        background-color: #f44336;
    }
    
    /* Text Inputs */
    QLineEdit, QTextEdit, QComboBox, QDateEdit, QTimeEdit, QSpinBox, QDoubleSpinBox {
        border: 1px solid #bdbdbd;
        border-radius: 4px;
        padding: 8px;
        background-color: white;
        selection-background-color: #2196F3;
    }
    
    QLineEdit:focus, QTextEdit:focus, QComboBox:focus, QDateEdit:focus, QTimeEdit:focus {
        border: 2px solid #2196F3;
    }
    
    /* Labels */
    QLabel {
        color: #212121;
    }
    
    QLabel#headerLabel {
        font-size: 18pt;
        font-weight: bold;
        color: #1976D2;
        margin-bottom: 10px;
    }
    
    QLabel#subHeaderLabel {
        font-size: 14pt;
        font-weight: bold;
        color: #1976D2;
    }
    
    /* Group Box */
    QGroupBox {
        font-weight: bold;
        border: 1px solid #bdbdbd;
        border-radius: 4px;
        margin-top: 12px;
        padding-top: 10px;
    }
    
    QGroupBox::title {
        subcontrol-origin: margin;
        left: 10px;
        padding: 0 5px;
    }
    
    /* Tab Widget */
    QTabWidget::pane {
        border: 1px solid #bdbdbd;
        background-color: white;
        border-radius: 4px;
    }
    
    QTabBar::tab {
        background-color: #f5f5f5;
        border: 1px solid #bdbdbd;
        border-bottom-color: #bdbdbd;
        border-top-left-radius: 4px;
        border-top-right-radius: 4px;
        min-width: 100px;
        padding: 8px 12px;
        font-weight: bold;
    }
    
    QTabBar::tab:selected {
        background-color: #2196F3;
        color: white;
        border-bottom-color: #2196F3;
    }
    
    QTabBar::tab:!selected {
        margin-top: 2px;
    }
    
    /* Table Widget */
    QTableWidget {
        alternate-background-color: #f5f5f5;
        selection-background-color: #2196F3;
        selection-color: white;
        gridline-color: #e0e0e0;
        border: 1px solid #bdbdbd;
    }
    
    QTableWidget QHeaderView::section {
        background-color: #1976D2;
        color: white;
        padding: 6px;
        font-weight: bold;
        border: none;
        border-right: 1px solid #0d5ca0;
    }
    
    /* Scroll Bar */
    QScrollBar:vertical {
        border: none;
        background: #f5f5f5;
        width: 10px;
        margin: 0px;
    }

    QScrollBar::handle:vertical {
        background: #90caf9;
        min-height: 20px;
        border-radius: 5px;
    }

    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
        height: 0px;
    }
    
    /* Menu Bar */
    QMenuBar {
        background-color: #1976D2;
        color: white;
    }
    
    QMenuBar::item {
        background-color: transparent;
        padding: 8px 12px;
    }
    
    QMenuBar::item:selected {
        background-color: #2196F3;
    }
    
    QMenu {
        background-color: white;
        border: 1px solid #bdbdbd;
    }
    
    QMenu::item {
        padding: 6px 20px 6px 20px;
    }
    
    QMenu::item:selected {
        background-color: #e3f2fd;
        color: #1565c0;
    }
    
    /* Status Bar */
    QStatusBar {
        background-color: #f5f5f5;
        color: #212121;
        border-top: 1px solid #bdbdbd;
    }
    
    /* Login Screen */
    QWidget#loginWidget {
        background-color: white;
        border: 1px solid #bdbdbd;
        border-radius: 8px;
    }
    
    /* Dashboard Cards */
    QFrame#dashboardCard {
        background-color: white;
        border-radius: 8px;
        border: 1px solid #e0e0e0;
    }
    
    /* Form Layout Spacing */
    QFormLayout {
        spacing: 12px;
    }
    """
    return style

def get_config(key, default=None):
    """
    Get configuration value from environment variables
    
    Args:
        key (str): Environment variable key
        default: Default value if key is not found
        
    Returns:
        Value of the environment variable or default
    """
    return os.getenv(key, default)

def load_config():
    return {
        'database': {
            'host': get_config('DB_HOST', 'localhost'),
            'port': int(get_config('DB_PORT', '3306')),
            'name': get_config('DB_NAME', 'hospital_db'),
            'user': get_config('DB_USER', 'root'),
            'password': get_config('DB_PASSWORD', '')
        },
        'app': {
            'title': 'Hospital Management System',
            'debug': get_config('APP_DEBUG', 'false').lower() == 'true'
        }
    }
