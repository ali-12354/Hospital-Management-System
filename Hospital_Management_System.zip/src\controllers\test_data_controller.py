"""
Test data controller for initializing test data in the system
"""
import logging
from datetime import datetime, timedelta
import random
from src.data.memory_store import MemoryStore, AppointmentStatus, BillingStatus
from src.controllers.auth_controller import AuthController
from src.controllers.patient_controller import PatientController
from src.controllers.doctor_controller import DoctorController
from src.controllers.appointment_controller import AppointmentController
from src.controllers.billing_controller import BillingController
from src.controllers.feedback_controller import FeedbackController

# Configure logging
logger = logging.getLogger('test_data_controller')

class TestDataController:
    """Controller for initializing test data"""
    
    @staticmethod
    def initialize_test_data():
        """Initialize test data for the application"""
        try:
            logger.info("Initializing test data...")
            
            # Create some doctors
            doctors = TestDataController._create_test_doctors()
            logger.info(f"Created {len(doctors)} test doctors")
            
            # Create some patients
            patients = TestDataController._create_test_patients()
            logger.info(f"Created {len(patients)} test patients")
            
            # Check if we have doctors and patients before continuing
            if not doctors or not patients:
                logger.warning("Could not create test appointments: missing doctors or patients")
                return True, "Test data initialized with limited data"
                
            # Create appointments
            appointments = TestDataController._create_test_appointments(patients, doctors)
            logger.info(f"Created {len(appointments)} test appointments")
            
            # Create billings
            billings = TestDataController._create_test_billings(appointments)
            logger.info(f"Created {len(billings) if billings else 0} test billings")
            
            # Create feedback
            feedback = TestDataController._create_test_feedback(appointments)
            logger.info(f"Created {len(feedback) if feedback else 0} test feedback")
            
            logger.info("Test data initialization completed successfully")
            return True, "Test data initialized"
            
        except Exception as e:
            logger.error(f"Error initializing test data: {str(e)}")
            return False, f"Failed to initialize test data: {str(e)}"

    @staticmethod
    def _create_test_doctors():
        """Create test doctor accounts"""
        doctors = []
        doctor_data = [
            {
                "username": "dr.smith", 
                "password": "Doctor@123", 
                "first_name": "John", 
                "last_name": "Smith",
                "specialization": "Cardiology", 
                "email": "dr.smith@hospital.com", 
                "contact": "5551234567"  # Fixed format without hyphens
            },
            {
                "username": "dr.patel", 
                "password": "Doctor@123", 
                "first_name": "Priya", 
                "last_name": "Patel",
                "specialization": "Neurology", 
                "email": "dr.patel@hospital.com", 
                "contact": "5552345678"  # Fixed format without hyphens
            },
            {
                "username": "dr.garcia", 
                "password": "Doctor@123", 
                "first_name": "Maria", 
                "last_name": "Garcia",
                "specialization": "Pediatrics", 
                "email": "dr.garcia@hospital.com", 
                "contact": "5553456789"  # Fixed format without hyphens
            }
        ]
        
        # First, clear any existing test doctors with these usernames
        store = MemoryStore()
        for data in doctor_data:
            user = store.get_user_by_username(data["username"])
            if user:
                # If user exists, find and remove the corresponding doctor
                for doc_id, doctor in list(store.doctors.items()):
                    if doctor.user_id == user.user_id:
                        del store.doctors[doc_id]
                # Remove the user
                if user.user_id in store.users:
                    del store.users[user.user_id]
        
        # Now create new doctors directly using store API for more reliable creation
        for data in doctor_data:
            try:
                # Create user first
                user = store.create_user(data["username"], data["password"], role="doctor")
                
                if user:
                    # Create doctor profile directly using store methods
                    doctor = store.create_doctor(
                        user_id=user.user_id,
                        first_name=data["first_name"],
                        last_name=data["last_name"],
                        specialization=data["specialization"],
                        contact=data["contact"],
                        email=data["email"]
                    )
                    
                    if doctor:
                        doctors.append(doctor)
                        logger.info(f"Created test doctor: {data['username']} with ID {doctor.doctor_id}")
                    else:
                        logger.warning(f"Failed to create test doctor profile for {data['username']}")
                else:
                    logger.warning(f"Failed to create test doctor user: {data['username']} (may already exist)")
            except Exception as e:
                logger.error(f"Error creating test doctor {data['username']}: {str(e)}")
        
        # Double-check that doctors were actually created
        all_doctors = store.get_all_doctors()
        logger.info(f"Total doctors in store after creation: {len(all_doctors)}")
        
        return doctors
    
    @staticmethod
    def _create_test_patients():
        """Create test patient accounts"""
        patients = []
        patient_data = [
            {
                "username": "patient1", 
                "password": "Patient@123", 
                "first_name": "David", 
                "last_name": "Johnson",
                "gender": "Male", 
                "dob": datetime(1985, 5, 15), 
                "contact": "555-111-2222",
                "email": "david@example.com", 
                "blood_group": "A+", 
                "address": "123 Main St",
                "medical_history": "Asthma, seasonal allergies"
            },
            {
                "username": "patient2", 
                "password": "Patient@123", 
                "first_name": "Sarah", 
                "last_name": "Williams",
                "gender": "Female", 
                "dob": datetime(1990, 8, 22), 
                "contact": "555-333-4444",
                "email": "sarah@example.com", 
                "blood_group": "O-", 
                "address": "456 Oak Ave",
                "medical_history": "No chronic conditions"
            },
            {
                "username": "patient3", 
                "password": "Patient@123", 
                "first_name": "Michael", 
                "last_name": "Brown",
                "gender": "Male", 
                "dob": datetime(1978, 11, 30), 
                "contact": "555-555-6666",
                "email": "michael@example.com", 
                "blood_group": "B+", 
                "address": "789 Pine St",
                "medical_history": "Hypertension, type 2 diabetes"
            }
        ]
        
        # First, clear any existing test patients with these usernames
        store = MemoryStore()
        for data in patient_data:
            user = store.get_user_by_username(data["username"])
            if user:
                # If user exists, find and remove the corresponding patient
                for patient_id, patient in list(store.patients.items()):
                    if patient.user_id == user.user_id:
                        del store.patients[patient_id]
                # Remove the user
                if user.user_id in store.users:
                    del store.users[user.user_id]
        
        # Now create new patients using direct store API for more reliable creation
        for data in patient_data:
            try:
                # Create user first
                user = store.create_user(data["username"], data["password"], role="patient")
                
                if user:
                    # Create patient profile directly using store methods
                    patient = store.create_patient(
                        user_id=user.user_id,
                        first_name=data["first_name"],
                        last_name=data["last_name"],
                        gender=data["gender"],
                        dob=data["dob"],
                        contact=data["contact"],
                        email=data["email"],
                        blood_group=data["blood_group"],
                        address=data["address"],
                        medical_history=data["medical_history"]
                    )
                    
                    if patient:
                        patients.append(patient)
                        logger.info(f"Created test patient: {data['username']} with ID {patient.patient_id}")
                    else:
                        logger.warning(f"Failed to create test patient profile for {data['username']}")
                else:
                    logger.warning(f"Failed to create test patient user: {data['username']} (may already exist)")
            except Exception as e:
                logger.error(f"Error creating test patient {data['username']}: {str(e)}")
        
        # Double-check that patients were actually created
        all_patients = store.get_all_patients()
        logger.info(f"Total patients in store after creation: {len(all_patients)}")
        
        return patients
    
    @staticmethod
    def _create_test_appointments(patients, doctors):
        """Create test appointments"""
        appointments = []
        
        # Check if we have patients and doctors
        if not patients or not doctors:
            logger.warning("No patients or doctors available for creating appointments")
            return appointments
        
        # Current date for reference
        now = datetime.now()
        
        # Create past appointments (some completed, some cancelled)
        for i in range(5):
            # Make sure we have valid patients and doctors
            if not patients or not doctors:
                logger.warning("Not enough patients or doctors for appointments")
                continue
                
            try:
                days_ago = random.randint(5, 30)
                appointment_date = now - timedelta(days=days_ago)
                
                patient = random.choice(patients) if patients else None
                doctor = random.choice(doctors) if doctors else None
                
                if not patient or not doctor:
                    logger.warning("Missing patient or doctor for appointment")
                    continue
                
                # Random hour between 9 AM and 4 PM
                hour = random.randint(9, 16)
                minute = random.choice([0, 30])
                time_slot = f"{hour:02d}:{minute:02d}"
                
                # Random status for past appointments
                status = random.choice([
                    AppointmentStatus.COMPLETED, 
                    AppointmentStatus.COMPLETED,  # Higher probability for completed
                    AppointmentStatus.COMPLETED, 
                    AppointmentStatus.CANCELLED
                ])
                
                success, result = AppointmentController.create_appointment(
                    patient.patient_id, doctor.doctor_id, appointment_date.date(),
                    datetime.strptime(time_slot, "%H:%M").time(),
                    f"Routine checkup {i+1}",
                    status=status,
                    notes="Follow-up in 3 months" if status == AppointmentStatus.COMPLETED else ""
                )
                
                if success:
                    appointments.append(result)
            except Exception as e:
                logger.error(f"Error creating past appointment: {str(e)}")
                continue
        
        # Create upcoming appointments (all scheduled)
        for i in range(5):
            # Make sure we have valid patients and doctors
            if not patients or not doctors:
                logger.warning("Not enough patients or doctors for future appointments")
                continue
                
            try:
                days_ahead = random.randint(1, 14)
                appointment_date = now + timedelta(days=days_ahead)
                
                patient = random.choice(patients) if patients else None
                doctor = random.choice(doctors) if doctors else None
                
                if not patient or not doctor:
                    logger.warning("Missing patient or doctor for future appointment")
                    continue
                
                # Random hour between 9 AM and 4 PM
                hour = random.randint(9, 16)
                minute = random.choice([0, 30])
                time_slot = f"{hour:02d}:{minute:02d}"
                
                success, result = AppointmentController.create_appointment(
                    patient.patient_id, doctor.doctor_id, appointment_date.date(),
                    datetime.strptime(time_slot, "%H:%M").time(),
                    f"Scheduled visit {i+1}"
                )
                
                if success:
                    appointments.append(result)
            except Exception as e:
                logger.error(f"Error creating future appointment: {str(e)}")
                continue
        
        return appointments
    
    @staticmethod
    def _create_test_billings(appointments):
        """Create test billing records"""
        bills = []
        
        # Check if we have appointments
        if not appointments:
            logger.warning("No appointments available for creating billings")
            return bills
            
        for appointment in appointments:
            # Only create bills for completed appointments
            if appointment.status == AppointmentStatus.COMPLETED:
                # Random amount between $100 and $500
                amount = round(random.uniform(100, 500), 2)
                
                # Random billing items
                items = [
                    {"description": "Consultation fee", "amount": round(amount * 0.7, 2)},
                    {"description": "Lab tests", "amount": round(amount * 0.3, 2)}
                ]
                
                # 70% chance of paid, 30% chance of pending
                status = BillingStatus.PAID if random.random() < 0.7 else BillingStatus.PENDING
                
                try:
                    success, result = BillingController.create_bill(
                        appointment.patient_id, items, status=status
                    )
                    
                    if success:
                        bills.append(result)
                except Exception as e:
                    logger.error(f"Error creating test billing: {str(e)}")
        
        return bills
    
    @staticmethod
    def _create_test_feedback(appointments):
        """Create test feedback records"""
        feedback_list = []
        store = MemoryStore()
        
        # Check if we have appointments
        if not appointments:
            logger.warning("No appointments available for creating feedback")
            return feedback_list
            
        for appointment in appointments:
            # Only create feedback for some completed appointments (70% chance)
            if appointment.status == AppointmentStatus.COMPLETED and random.random() < 0.7:
                try:
                    # Random rating between 3 and 5 (biased toward positive)
                    rating = random.randint(3, 5)
                    
                    # Generate feedback comment based on rating
                    if rating == 5:
                        comment = random.choice([
                            "Excellent service! The doctor was very thorough and caring.",
                            "Great experience overall. Very satisfied with my treatment.",
                            "Doctor was knowledgeable and took time to explain everything clearly."
                        ])
                    elif rating == 4:
                        comment = random.choice([
                            "Good service, but had to wait a bit longer than expected.",
                            "Doctor was professional and helpful. Facilities were clean.",
                            "Satisfied with the care provided. Would recommend."
                        ])
                    else:  # rating == 3
                        comment = random.choice([
                            "Average experience. The doctor seemed rushed.",
                            "Service was okay, but the wait time was too long.",
                            "Treatment was adequate, but could improve on communication."
                        ])
                    
                    # Create feedback directly in the memory store
                    feedback = store.create_feedback(
                        patient_id=appointment.patient_id,
                        doctor_id=appointment.doctor_id,
                        appointment_id=appointment.appointment_id,
                        rating=rating,
                        comment=comment,
                        submitted_at=datetime.now() - timedelta(days=random.randint(1, 5))
                    )
                    
                    feedback_list.append(feedback)
                    
                    # Add responses to some feedback (50% chance)
                    if random.random() < 0.5:
                        response = random.choice([
                            "Thank you for your feedback. We're glad you had a positive experience.",
                            "We appreciate your comments and will work to address your concerns.",
                            "Thank you for letting us know about your experience. We value your input."
                        ])
                        feedback.response = response
                        feedback.status = "resolved" if random.random() < 0.7 else "pending"
                        feedback.updated_at = datetime.now() - timedelta(days=random.randint(0, 2))
                except Exception as e:
                    logger.error(f"Error creating test feedback: {str(e)}")
        
        return feedback_list