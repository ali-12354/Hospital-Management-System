"""
Patient model
"""
from dataclasses import dataclass
from datetime import datetime

@dataclass
class Patient:
    """Patient model"""
    patient_id: int
    user_id: int
    first_name: str
    last_name: str
    gender: str
    dob: datetime
    contact: str
    email: str = ""
    blood_group: str = ""
    address: str = ""
    medical_history: str = ""