"""
Feedback model with in-memory storage
"""
from dataclasses import dataclass, field
from typing import List, Optional
from datetime import datetime

@dataclass
class Feedback:
    """Feedback model with in-memory storage"""
    feedback_id: int
    patient_id: int
    doctor_id: int
    appointment_id: int
    rating: int
    comment: str = ""
    submitted_at: datetime = field(default_factory=datetime.now)
    updated_at: Optional[datetime] = None
    status: str = "pending"
    response: str = ""

    # In-memory storage
    _feedbacks: List['Feedback'] = field(default_factory=list)

    @classmethod
    def create(cls, **kwargs) -> 'Feedback':
        feedback = cls(**kwargs)
        cls._feedbacks.append(feedback)
        return feedback

    @classmethod
    def get_all(cls) -> List['Feedback']:
        return cls._feedbacks.copy()

    @classmethod
    def get_by_id(cls, feedback_id: int) -> Optional['Feedback']:
        return next((f for f in cls._feedbacks if f.feedback_id == feedback_id), None)

    @classmethod
    def get_by_doctor(cls, doctor_id: int) -> List['Feedback']:
        return [f for f in cls._feedbacks if f.doctor_id == doctor_id]

    @classmethod
    def get_by_patient(cls, patient_id: int) -> List['Feedback']:
        return [f for f in cls._feedbacks if f.patient_id == patient_id]

    @classmethod
    def get_by_appointment(cls, appointment_id: int) -> Optional['Feedback']:
        return next((f for f in cls._feedbacks if f.appointment_id == appointment_id), None)

    @classmethod
    def update(cls, feedback_id: int, **kwargs) -> Optional['Feedback']:
        feedback = cls.get_by_id(feedback_id)
        if feedback:
            for key, value in kwargs.items():
                if hasattr(feedback, key):
                    setattr(feedback, key, value)
            feedback.updated_at = datetime.now()
        return feedback

    @classmethod
    def delete(cls, feedback_id: int) -> bool:
        feedback = cls.get_by_id(feedback_id)
        if feedback:
            cls._feedbacks.remove(feedback)
            return True
        return False