"""
Feedback dialog module for submitting patient feedback
"""
import customtkinter as ctk
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from src.controllers.feedback_controller import FeedbackController
from src.controllers.appointment_controller import AppointmentController
from src.controllers.doctor_controller import DoctorController

class FeedbackDialog(ctk.CTkToplevel):
    """Dialog for submitting feedback"""
    
    def __init__(self, patient, parent=None):
        """Initialize feedback dialog"""
        super().__init__(parent)
        self.patient = patient
        
        # Configure window
        self.title("Submit Feedback")
        self.geometry("500x500")
        
        # Create form frame
        self.form_frame = ctk.CTkFrame(self)
        self.form_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create form fields
        self.create_form()
        
        # Create buttons
        self.create_buttons()
        
        # Load appointments for selection
        self.load_appointments()
    
    def create_form(self):
        """Create form fields"""
        # Appointment selection
        appointment_label = ctk.CTkLabel(
            self.form_frame,
            text="Appointment:"
        )
        appointment_label.grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        
        self.appointment_field = ttk.Combobox(
            self.form_frame,
            state="readonly"
        )
        self.appointment_field.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)
        self.appointment_field.bind("<<ComboboxSelected>>", self.on_appointment_select)
        
        # Doctor field (read-only)
        doctor_label = ctk.CTkLabel(
            self.form_frame,
            text="Doctor:"
        )
        doctor_label.grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        
        self.doctor_var = ctk.StringVar()
        self.doctor_field = ctk.CTkEntry(
            self.form_frame,
            textvariable=self.doctor_var,
            state="disabled"
        )
        self.doctor_field.grid(row=1, column=1, padx=5, pady=5, sticky=tk.EW)
        
        # Rating field
        rating_label = ctk.CTkLabel(
            self.form_frame,
            text="Rating (1-5):"
        )
        rating_label.grid(row=2, column=0, padx=5, pady=5, sticky=tk.W)
        
        # Rating frame with stars
        rating_frame = ctk.CTkFrame(self.form_frame)
        rating_frame.grid(row=2, column=1, padx=5, pady=5, sticky=tk.W)
        
        self.rating_var = tk.IntVar(value=5)
        self.rating_buttons = []
        
        for i in range(1, 6):
            btn = ctk.CTkButton(
                rating_frame,
                text="★",
                width=30,
                height=30,
                command=lambda rating=i: self.set_rating(rating)
            )
            btn.pack(side=tk.LEFT)
            self.rating_buttons.append(btn)
        
        # Comment field
        comment_label = ctk.CTkLabel(
            self.form_frame,
            text="Comments:"
        )
        comment_label.grid(row=3, column=0, padx=5, pady=5, sticky=tk.NW)
        
        self.comment_field = ctk.CTkTextbox(
            self.form_frame,
            height=150,
            wrap=tk.WORD
        )
        self.comment_field.grid(row=3, column=1, padx=5, pady=5, sticky=tk.EW)
        
        # Configure grid
        self.form_frame.columnconfigure(1, weight=1)
        
        # Highlight initial rating
        self.update_rating_buttons()
    
    def create_buttons(self):
        """Create form buttons"""
        button_frame = ctk.CTkFrame(self)
        button_frame.pack(fill=tk.X, pady=10)
        
        submit_button = ctk.CTkButton(
            button_frame,
            text="Submit",
            command=self.submit_feedback
        )
        submit_button.pack(side=tk.RIGHT, padx=5)
        
        cancel_button = ctk.CTkButton(
            button_frame,
            text="Cancel",
            command=self.destroy,
            fg_color="transparent",
            border_width=2
        )
        cancel_button.pack(side=tk.RIGHT, padx=5)
    
    def load_appointments(self):
        """Load patient's appointments"""
        try:
            # Get all appointments for the patient
            appointments = AppointmentController.get_appointments_by_patient(self.patient.patient_id)
            
            if not appointments:
                messagebox.showinfo("No Appointments", "You don't have any appointments to leave feedback on.")
                self.destroy()
                return
                
            # For the demo, all appointments are eligible for feedback
            completed = appointments
            
            if not completed:
                messagebox.showinfo("No Appointments", "You don't have any completed appointments to leave feedback on.")
                self.destroy()
                return
            
            # Create appointment map for easier lookup
            self.appointment_map = {}
            
            for appt in completed:
                # Get doctor info
                doctor = None
                doctor_id = None
                
                # Try to get doctor_id from appointment
                if hasattr(appt, 'doctor_id') and appt.doctor_id:
                    doctor_id = appt.doctor_id
                    doctor = DoctorController.get_doctor_by_id(doctor_id)
                elif hasattr(appt, 'doctor') and appt.doctor:
                    doctor = appt.doctor
                    if hasattr(doctor, 'doctor_id'):
                        doctor_id = doctor.doctor_id
                
                # Skip appointments without a doctor
                if not doctor_id:
                    continue
                
                doctor_name = f"Dr. {doctor.first_name} {doctor.last_name}" if doctor else f"Doctor (ID: {doctor_id})"
                
                # Get date string safely
                date_str = "Unknown"
                if hasattr(appt, 'date'):
                    if hasattr(appt.date, 'strftime'):
                        date_str = appt.date.strftime("%m/%d/%Y")
                    else:
                        date_str = str(appt.date)
                
                # Create unique display text
                display_text = f"{date_str} - {doctor_name}"
                
                # Add extra numbering if duplicates exist
                if display_text in self.appointment_map:
                    display_text = f"{display_text} (ID: {appt.appointment_id})"
                
                self.appointment_map[display_text] = appt
            
            # Set appointment options
            self.appointment_field['values'] = list(self.appointment_map.keys())
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load appointments: {str(e)}")
            self.destroy()
    
    def on_appointment_select(self, event):
        """Handle appointment selection"""
        selected = self.appointment_field.get()
        if selected in self.appointment_map:
            appt = self.appointment_map[selected]
            
            # Get doctor info
            doctor = None
            doctor_id = None
            
            # Try to get doctor_id from appointment
            if hasattr(appt, 'doctor_id') and appt.doctor_id:
                doctor_id = appt.doctor_id
                doctor = DoctorController.get_doctor_by_id(doctor_id)
            elif hasattr(appt, 'doctor') and appt.doctor:
                doctor = appt.doctor
                
            if doctor and hasattr(doctor, 'first_name') and hasattr(doctor, 'last_name'):
                self.doctor_var.set(f"Dr. {doctor.first_name} {doctor.last_name}")
            elif doctor_id:
                self.doctor_var.set(f"Doctor (ID: {doctor_id})")
            else:
                self.doctor_var.set("Unknown")
    
    def set_rating(self, rating):
        """Set the rating value"""
        self.rating_var.set(rating)
        self.update_rating_buttons()
    
    def update_rating_buttons(self):
        """Update rating buttons appearance"""
        rating = self.rating_var.get()
        
        # Update button colors based on selected rating
        for i, btn in enumerate(self.rating_buttons):
            if i < rating:
                btn.configure(fg_color="#FFD700")  # Gold color for selected stars
            else:
                btn.configure(fg_color="#444444")  # Dark color for unselected stars
    
    def submit_feedback(self):
        """Submit feedback form"""
        try:
            selected = self.appointment_field.get()
            if not selected:
                messagebox.showerror("Error", "Please select an appointment")
                return
                
            appointment = self.appointment_map[selected]
            rating = self.rating_var.get()
            comment = self.comment_field.get("1.0", tk.END).strip()
            
            if not comment:
                if not messagebox.askyesno("Confirm", "Are you sure you want to submit without any comments?"):
                    return
            
            # Get doctor_id safely
            doctor_id = None
            if hasattr(appointment, 'doctor_id'):
                doctor_id = appointment.doctor_id
            elif hasattr(appointment, 'doctor') and hasattr(appointment.doctor, 'doctor_id'):
                doctor_id = appointment.doctor.doctor_id
            
            if not doctor_id:
                messagebox.showerror("Error", "Could not determine doctor for this appointment")
                return
                
            # Get appointment_id safely
            appointment_id = None
            if hasattr(appointment, 'appointment_id'):
                appointment_id = appointment.appointment_id
            else:
                messagebox.showerror("Error", "Could not determine appointment ID")
                return
                
            success, result = FeedbackController.submit_feedback(
                patient_id=self.patient.patient_id,
                doctor_id=doctor_id,
                appointment_id=appointment_id,
                rating=rating,
                comment=comment
            )
            
            if success:
                messagebox.showinfo("Success", "Thank you for your feedback!")
                self.destroy()
            else:
                messagebox.showerror("Error", f"Failed to submit feedback: {result}")
                
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")