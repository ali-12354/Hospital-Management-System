"""
Appointment dialog module for scheduling appointments
"""
import customtkinter as ctk
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime, timedelta
from tkcalendar import DateEntry
from src.controllers.appointment_controller import AppointmentController
from src.controllers.doctor_controller import DoctorController

class AppointmentDialog(ctk.CTkToplevel):
    """Dialog for scheduling appointments"""
    
    def __init__(self, patient, parent=None):
        """Initialize appointment dialog"""
        super().__init__(parent)
        self.patient = patient
        
        # Configure window
        self.title("Schedule Appointment")
        self.geometry("500x400")
        
        # Create form frame
        self.form_frame = ctk.CTkFrame(self)
        self.form_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create form fields
        self.create_form()
        
        # Create buttons
        self.create_buttons()
        
        # Load doctors data
        self.load_doctors()
    
    def create_form(self):
        """Create form fields"""
        # Doctor selection
        doctor_label = ctk.CTkLabel(
            self.form_frame,
            text="Doctor:"
        )
        doctor_label.grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        
        self.doctor_field = ttk.Combobox(
            self.form_frame,
            state="readonly"
        )
        self.doctor_field.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)
        self.doctor_field.bind("<<ComboboxSelected>>", self.on_doctor_select)
        
        # Doctor specialization
        specialization_label = ctk.CTkLabel(
            self.form_frame,
            text="Specialization:"
        )
        specialization_label.grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        
        self.specialization_label = ctk.CTkLabel(
            self.form_frame,
            text=""
        )
        self.specialization_label.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
        
        # Date selection
        date_label = ctk.CTkLabel(
            self.form_frame,
            text="Date:"
        )
        date_label.grid(row=2, column=0, padx=5, pady=5, sticky=tk.W)
        
        # Set min date to tomorrow
        min_date = datetime.now().date() + timedelta(days=1)
        
        self.date_field = DateEntry(
            self.form_frame,
            width=30,
            background='darkblue',
            foreground='white',
            borderwidth=2,
            mindate=min_date
        )
        self.date_field.grid(row=2, column=1, padx=5, pady=5, sticky=tk.EW)
        self.date_field.bind("<<DateEntrySelected>>", self.on_date_select)
        
        # Time selection
        time_label = ctk.CTkLabel(
            self.form_frame,
            text="Time:"
        )
        time_label.grid(row=3, column=0, padx=5, pady=5, sticky=tk.W)
        
        self.time_field = ttk.Combobox(
            self.form_frame,
            state="readonly"
        )
        self.time_field.grid(row=3, column=1, padx=5, pady=5, sticky=tk.EW)
        
        # Reason for visit
        reason_label = ctk.CTkLabel(
            self.form_frame,
            text="Reason:"
        )
        reason_label.grid(row=4, column=0, padx=5, pady=5, sticky=tk.W)
        
        self.reason_field = ctk.CTkTextbox(
            self.form_frame,
            height=100,
            wrap=tk.WORD
        )
        self.reason_field.grid(row=4, column=1, padx=5, pady=5, sticky=tk.EW)
    
    def create_buttons(self):
        """Create form buttons"""
        button_frame = ctk.CTkFrame(self)
        button_frame.pack(fill=tk.X, pady=10)
        
        schedule_button = ctk.CTkButton(
            button_frame,
            text="Schedule",
            command=self.schedule_appointment
        )
        schedule_button.pack(side=tk.RIGHT, padx=5)
        
        cancel_button = ctk.CTkButton(
            button_frame,
            text="Cancel",
            command=self.destroy,
            fg_color="transparent",
            border_width=2
        )
        cancel_button.pack(side=tk.RIGHT, padx=5)
    
    def load_doctors(self):
        """Load doctors data"""
        try:
            doctors = DoctorController.get_all_doctors()
            
            # Create doctor map for easier lookup
            self.doctor_map = {
                f"Dr. {d.first_name} {d.last_name}": d
                for d in doctors
            }
            
            # Set doctor names in combobox
            self.doctor_field['values'] = list(self.doctor_map.keys())
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load doctors: {str(e)}")
    
    def on_doctor_select(self, event=None):
        """Handle doctor selection"""
        doctor_name = self.doctor_field.get()
        if doctor_name in self.doctor_map:
            doctor = self.doctor_map[doctor_name]
            self.specialization_label.configure(text=doctor.specialization)
            
            # Update available time slots
            self.update_time_slots()
    
    def on_date_select(self, event=None):
        """Handle date selection"""
        self.update_time_slots()
    
    def update_time_slots(self):
        """Update available time slots for selected doctor and date"""
        doctor_name = self.doctor_field.get()
        if not doctor_name or doctor_name not in self.doctor_map:
            return
        
        doctor = self.doctor_map[doctor_name]
        selected_date = self.date_field.get_date()
        
        try:
            # Get all appointments for the selected doctor
            all_appointments = AppointmentController.get_appointments_by_doctor(doctor.doctor_id)
            
            # Filter appointments for the selected date
            appointments = [
                appt for appt in all_appointments 
                if isinstance(appt.date, datetime) and appt.date.date() == selected_date
            ]
            
            # Create time slots from 9 AM to 5 PM
            all_slots = [
                (datetime.min + timedelta(hours=i)).strftime("%I:%M %p")
                for i in range(9, 17)  # 9 AM to 5 PM
            ]
            
            # Remove booked slots - handle string time_slot instead of appointment_time
            booked_slots = []
            for appt in appointments:
                # Try to convert time_slot string to time object for comparison
                try:
                    time_obj = datetime.strptime(appt.time_slot, "%H:%M").time()
                    booked_slots.append(time_obj.strftime("%I:%M %p"))
                except (AttributeError, ValueError):
                    # Skip if time_slot is not properly formatted
                    continue
            
            available_slots = [
                slot for slot in all_slots
                if slot not in booked_slots
            ]
            
            # Update time combobox
            self.time_field['values'] = available_slots
            if available_slots:
                self.time_field.set(available_slots[0])
            else:
                self.time_field.set('')
                messagebox.showinfo(
                    "No Slots Available",
                    "No appointments available for the selected date."
                )
            
        except Exception as e:
            messagebox.showerror(
                "Error",
                f"Failed to load available time slots: {str(e)}"
            )
    
    def schedule_appointment(self):
        """Schedule the appointment"""
        # Get form data
        doctor_name = self.doctor_field.get()
        if not doctor_name or doctor_name not in self.doctor_map:
            messagebox.showerror("Error", "Please select a doctor.")
            return
        
        appointment_time = self.time_field.get()
        if not appointment_time:
            messagebox.showerror("Error", "Please select an appointment time.")
            return
        
        reason = self.reason_field.get("1.0", tk.END).strip()
        if not reason:
            messagebox.showerror("Error", "Please provide a reason for the visit.")
            return
        
        # Get selected doctor
        doctor = self.doctor_map[doctor_name]
        
        # Create appointment data
        appointment_date = self.date_field.get_date()
        appointment_time = datetime.strptime(
            self.time_field.get(),
            "%I:%M %p"
        ).time()
        
        try:
            # Create appointment
            success, result = AppointmentController.create_appointment(
                patient_id=self.patient.patient_id,
                doctor_id=doctor.doctor_id,
                date=appointment_date,
                time=appointment_time,
                reason=reason
            )
            
            if success:
                messagebox.showinfo(
                    "Success",
                    "Appointment scheduled successfully."
                )
                self.destroy()
            else:
                messagebox.showerror("Error", result)
            
        except Exception as e:
            messagebox.showerror(
                "Error",
                f"Failed to schedule appointment: {str(e)}"
            )