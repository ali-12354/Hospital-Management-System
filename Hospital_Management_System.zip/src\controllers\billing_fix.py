"""
Temporary fix for billing display in admin panel
"""

import logging
from datetime import datetime
from src.data.memory_store import MemoryStore
from src.controllers.patient_controller import PatientController

logger = logging.getLogger('billing_fix')

def refresh_billing_table(table, bills_to_show=None, search_term=None):
    """
    Helper function to reload all bills from memory store into the table widget
    
    This function is a standalone utility that directly accesses the memory store
    and updates the given table widget with all available bill data.
    
    Args:
        table: The tkinter treeview table to populate
        bills_to_show: Optional list of bill objects to display (if None, shows all bills)
        search_term: Optional search term to filter bills by patient name
        
    Returns:
        int: Number of bills displayed
    """
    # Clear existing items
    for item in table.get_children():
        table.delete(item)
    
    # Get direct access to the memory store
    store = MemoryStore()
    
    # Get bills to display
    if bills_to_show is None:
        bills_to_show = list(store.billings.values())
        
    logger.info(f"Processing {len(bills_to_show)} bills for display")
    
    # Filter by search term if provided
    if search_term and isinstance(search_term, str) and search_term.strip():
        search_term = search_term.lower().strip()
        filtered_bills = []
        
        # Filter bills based on patient name
        for bill in bills_to_show:
            try:
                # Get patient ID
                if isinstance(bill, dict):
                    patient_id = bill.get("patient_id")
                else:
                    patient_id = getattr(bill, "patient_id", None)
                
                # Skip if no patient ID
                if not patient_id:
                    continue
                
                # Get patient
                patient = PatientController.get_patient_by_id(patient_id)
                if not patient:
                    continue
                
                # Check if search term is in patient name
                patient_name = f"{patient.first_name} {patient.last_name}".lower()
                if search_term in patient_name:
                    filtered_bills.append(bill)
            except Exception as e:
                logger.error(f"Error filtering bill by search term: {str(e)}")
                continue
                
        bills_to_show = filtered_bills
        logger.info(f"Filtered to {len(bills_to_show)} bills matching '{search_term}'")
    
    # Display count
    displayed_count = 0
    
    # Process each bill for display
    for bill in bills_to_show:
        try:
            # Process based on type
            if isinstance(bill, dict):
                # Handle dictionary bill format
                bill_id = bill.get("bill_id", "N/A")
                
                # Get patient information
                patient_id = bill.get("patient_id")
                patient_name = "Unknown"
                
                if "patient" in bill and hasattr(bill["patient"], "first_name"):
                    patient = bill["patient"]
                    patient_name = f"{patient.first_name} {patient.last_name}"
                elif patient_id:
                    patient = PatientController.get_patient_by_id(patient_id)
                    if patient:
                        patient_name = f"{patient.first_name} {patient.last_name}"
                    else:
                        patient_name = f"Patient {patient_id}"
                
                # Get date and format it
                date_value = bill.get("bill_date", datetime.now())
                bill_date = date_value.strftime("%m/%d/%Y") if isinstance(date_value, datetime) else str(date_value)
                
                # Get amount
                amount = f"${bill.get('total_amount', 0):.2f}"
                
                # Get status
                status_value = bill.get("payment_status", "pending")
                status = status_value.value if hasattr(status_value, "value") else str(status_value)
            else:
                # Handle object bill format
                bill_id = getattr(bill, "bill_id", getattr(bill, "billing_id", "N/A"))
                
                # Get patient
                patient_id = getattr(bill, "patient_id", None)
                if patient_id:
                    patient = PatientController.get_patient_by_id(patient_id)
                    patient_name = f"{patient.first_name} {patient.last_name}" if patient else f"Patient {patient_id}"
                else:
                    patient_name = "Unknown Patient"
                
                # Get date
                date_value = getattr(bill, "date", datetime.now())
                bill_date = date_value.strftime("%m/%d/%Y") if isinstance(date_value, datetime) else str(date_value)
                
                # Get amount
                amount = f"${getattr(bill, 'amount', 0):.2f}"
                
                # Get status
                status_obj = getattr(bill, "status", None)
                status = status_obj.value if hasattr(status_obj, "value") else "pending"
            
            # Insert into table
            table.insert("", "end", values=(
                bill_id,
                patient_name,
                bill_date,
                amount,
                status,
                "View | Delete"
            ))
            displayed_count += 1
            logger.info(f"Added bill {bill_id} to table")
        
        except Exception as e:
            logger.error(f"Error processing bill: {str(e)}")
            continue
    
    return displayed_count