"""
Doctor model with in-memory storage
"""
from dataclasses import dataclass, field
from typing import List, Optional
from datetime import datetime

@dataclass
class Doctor:
    """Doctor model with in-memory storage"""
    doctor_id: int
    user_id: int
    first_name: str
    last_name: str
    gender: str
    specialization: str
    qualification: str
    contact: str
    email: str = ""
    consulting_hours: str = ""
    fees: float = 0.0
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: Optional[datetime] = None

    # In-memory storage
    _doctors: List['Doctor'] = field(default_factory=list)

    @classmethod
    def create(cls, **kwargs) -> 'Doctor':
        doctor = cls(**kwargs)
        cls._doctors.append(doctor)
        return doctor

    @classmethod
    def get_all(cls) -> List['Doctor']:
        return cls._doctors.copy()

    @classmethod
    def get_by_id(cls, doctor_id: int) -> Optional['Doctor']:
        return next((d for d in cls._doctors if d.doctor_id == doctor_id), None)

    @classmethod
    def get_by_user_id(cls, user_id: int) -> Optional['Doctor']:
        return next((d for d in cls._doctors if d.user_id == user_id), None)

    @classmethod
    def update(cls, doctor_id: int, **kwargs) -> Optional['Doctor']:
        doctor = cls.get_by_id(doctor_id)
        if doctor:
            for key, value in kwargs.items():
                if hasattr(doctor, key):
                    setattr(doctor, key, value)
            doctor.updated_at = datetime.now()
        return doctor

    @classmethod
    def delete(cls, doctor_id: int) -> bool:
        doctor = cls.get_by_id(doctor_id)
        if doctor:
            cls._doctors.remove(doctor)
            return True
        return False

    @classmethod
    def get_by_specialization(cls, specialization: str) -> List['Doctor']:
        return [d for d in cls._doctors if d.specialization.lower() == specialization.lower()]