"""
In-memory data store for the Hospital Management System
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Dict, Optional
from enum import Enum
import bcrypt

class AppointmentStatus(Enum):
    SCHEDULED = "scheduled"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

class BillingStatus(Enum):
    PENDING = "pending"
    PAID = "paid"
    CANCELLED = "cancelled"

@dataclass
class User:
    user_id: int
    username: str
    password_hash: str
    role: str

@dataclass
class Doctor:
    doctor_id: int
    user_id: int
    first_name: str
    last_name: str
    specialization: str
    contact: str
    email: str
    gender: str = "Not specified"
    qualification: str = "Medical Doctor"
    consulting_hours: str = "9:00 AM - 5:00 PM"
    fees: float = 0.0
    
    @property
    def full_name(self):
        """Get the full name of the doctor."""
        return f"{self.first_name} {self.last_name}"

@dataclass
class Patient:
    patient_id: int
    user_id: int
    first_name: str
    last_name: str
    gender: str
    dob: datetime
    contact: str
    email: str
    blood_group: str
    address: str
    medical_history: str
    
    @property
    def full_name(self):
        """Get the full name of the patient."""
        return f"{self.first_name} {self.last_name}"
    
    @property
    def date_of_birth(self):
        """Alias for dob (date of birth)."""
        return self.dob

@dataclass
class Appointment:
    appointment_id: int
    patient_id: int
    doctor_id: int
    date: datetime
    time_slot: str
    reason: str
    status: AppointmentStatus = AppointmentStatus.SCHEDULED
    notes: str = ""

@dataclass
class Billing:
    billing_id: int
    appointment_id: int
    amount: float
    description: str
    status: BillingStatus = BillingStatus.PENDING
    date: datetime = field(default_factory=datetime.now)
    payment_date: Optional[datetime] = None

@dataclass
class Feedback:
    feedback_id: int
    patient_id: int
    doctor_id: int
    appointment_id: int
    rating: int
    comment: str
    submitted_at: datetime = field(default_factory=datetime.now)
    status: str = "pending"
    response: str = ""
    updated_at: Optional[datetime] = None

class MemoryStore:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialize()
        return cls._instance
    
    def _initialize(self):
        """Initialize the in-memory store with default data"""
        self.users: Dict[int, User] = {}
        self.patients: Dict[int, Patient] = {}
        self.doctors: Dict[int, Doctor] = {}
        self.appointments: Dict[int, Appointment] = {}
        self.billings: Dict[int, Billing] = {}
        self.feedback: Dict[int, Feedback] = {}
        
        self.next_user_id = 1
        self.next_patient_id = 1
        self.next_doctor_id = 1
        self.next_appointment_id = 1
        self.next_billing_id = 1
        self.next_feedback_id = 1
        
        # Create default admin user
        admin_password = "Admin@123"
        password_hash = bcrypt.hashpw(admin_password.encode('utf-8'), bcrypt.gensalt())
        
        self.users[0] = User(
            user_id=0,
            username="admin",
            password_hash=password_hash,
            role="admin"
        )
        
        # Create 10 test patients for testing reports
        self._create_test_patients()
    
    def _create_test_patients(self):
        """Create 10 test patient records with varied data for testing reports"""
        test_patients_data = [
            {
                "username": "patient1",
                "first_name": "John",
                "last_name": "Smith",
                "gender": "Male",
                "dob": datetime(1985, 3, 15),
                "contact": "555-0101",
                "email": "john.smith@email.com",
                "blood_group": "A+",
                "address": "123 Oak Street, Springfield",
                "medical_history": "No known allergies. Regular checkups."
            },
            {
                "username": "patient2",
                "first_name": "Emma",
                "last_name": "Johnson",
                "gender": "Female",
                "dob": datetime(1990, 7, 22),
                "contact": "555-0102",
                "email": "emma.johnson@email.com",
                "blood_group": "B+",
                "address": "456 Maple Avenue, Springfield",
                "medical_history": "Allergic to penicillin."
            },
            {
                "username": "patient3",
                "first_name": "Michael",
                "last_name": "Williams",
                "gender": "Male",
                "dob": datetime(1978, 11, 8),
                "contact": "555-0103",
                "email": "michael.williams@email.com",
                "blood_group": "O+",
                "address": "789 Pine Road, Springfield",
                "medical_history": "Diabetes Type 2. Regular insulin."
            },
            {
                "username": "patient4",
                "first_name": "Sophia",
                "last_name": "Brown",
                "gender": "Female",
                "dob": datetime(1995, 5, 30),
                "contact": "555-0104",
                "email": "sophia.brown@email.com",
                "blood_group": "A+",
                "address": "321 Elm Street, Springfield",
                "medical_history": "Asthma. Carries inhaler."
            },
            {
                "username": "patient5",
                "first_name": "William",
                "last_name": "Davis",
                "gender": "Male",
                "dob": datetime(1982, 9, 12),
                "contact": "555-0105",
                "email": "william.davis@email.com",
                "blood_group": "AB+",
                "address": "654 Birch Lane, Springfield",
                "medical_history": "High blood pressure. On medication."
            },
            {
                "username": "patient6",
                "first_name": "Olivia",
                "last_name": "Miller",
                "gender": "Female",
                "dob": datetime(1988, 2, 18),
                "contact": "555-0106",
                "email": "olivia.miller@email.com",
                "blood_group": "O-",
                "address": "987 Cedar Court, Springfield",
                "medical_history": "No major health issues."
            },
            {
                "username": "patient7",
                "first_name": "James",
                "last_name": "Wilson",
                "gender": "Male",
                "dob": datetime(1992, 12, 5),
                "contact": "555-0107",
                "email": "james.wilson@email.com",
                "blood_group": "A-",
                "address": "147 Willow Way, Springfield",
                "medical_history": "Seasonal allergies."
            },
            {
                "username": "patient8",
                "first_name": "Ava",
                "last_name": "Moore",
                "gender": "Female",
                "dob": datetime(1986, 6, 25),
                "contact": "555-0108",
                "email": "ava.moore@email.com",
                "blood_group": "B-",
                "address": "258 Spruce Drive, Springfield",
                "medical_history": "Previous surgery in 2015. Recovered fully."
            },
            {
                "username": "patient9",
                "first_name": "Robert",
                "last_name": "Taylor",
                "gender": "Male",
                "dob": datetime(1975, 4, 9),
                "contact": "555-0109",
                "email": "robert.taylor@email.com",
                "blood_group": "AB-",
                "address": "369 Ash Boulevard, Springfield",
                "medical_history": "Chronic back pain. Physical therapy."
            },
            {
                "username": "patient10",
                "first_name": "Isabella",
                "last_name": "Anderson",
                "gender": "Female",
                "dob": datetime(1998, 8, 14),
                "contact": "555-0110",
                "email": "isabella.anderson@email.com",
                "blood_group": "O+",
                "address": "741 Cherry Circle, Springfield",
                "medical_history": "Healthy. Regular fitness routine."
            }
        ]
        
        default_password = "Patient@123"
        
        for patient_data in test_patients_data:
            # Create user account
            user = self.create_user(
                username=patient_data["username"],
                password=default_password,
                role="patient"
            )
            
            if user:
                # Create patient record
                self.create_patient(
                    user_id=user.user_id,
                    first_name=patient_data["first_name"],
                    last_name=patient_data["last_name"],
                    gender=patient_data["gender"],
                    dob=patient_data["dob"],
                    contact=patient_data["contact"],
                    email=patient_data["email"],
                    blood_group=patient_data["blood_group"],
                    address=patient_data["address"],
                    medical_history=patient_data["medical_history"]
                )
    
    def authenticate_user(self, username: str, password: str) -> Optional[User]:
        """Authenticate a user by username and password"""
        for user in self.users.values():
            if user.username == username:
                if bcrypt.checkpw(password.encode('utf-8'), user.password_hash):
                    return user
        return None
    
    def create_user(self, username: str, password: str, role: str = "patient") -> Optional[User]:
        """Create a new user"""
        # Check if username already exists
        if any(u.username == username for u in self.users.values()):
            return None
            
        password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        user_id = self.next_user_id
        self.next_user_id += 1
        
        user = User(
            user_id=user_id,
            username=username,
            password_hash=password_hash,
            role=role
        )
        self.users[user_id] = user
        return user
    
    def create_patient(self, user_id: int, first_name: str, last_name: str,
                      gender: str, dob: datetime, contact: str, email: str,
                      blood_group: str, address: str, medical_history: str) -> Optional[Patient]:
        """Create a new patient record"""
        patient_id = self.next_patient_id
        self.next_patient_id += 1
        
        patient = Patient(
            patient_id=patient_id,
            user_id=user_id,
            first_name=first_name,
            last_name=last_name,
            gender=gender,
            dob=dob,
            contact=contact,
            email=email,
            blood_group=blood_group,
            address=address,
            medical_history=medical_history
        )
        self.patients[patient_id] = patient
        return patient
    
    def get_patient_by_user_id(self, user_id: int) -> Optional[Patient]:
        """Get patient record by user ID"""
        for patient in self.patients.values():
            if patient.user_id == user_id:
                return patient
        return None
    
    def get_all_patients(self) -> List[Patient]:
        """Get all patient records"""
        return list(self.patients.values())
    
    def get_user_by_id(self, user_id: int) -> Optional[User]:
        """Get user by ID"""
        return self.users.get(user_id)
    
    def get_user_by_username(self, username: str) -> Optional[User]:
        """Get user by username"""
        for user in self.users.values():
            if user.username == username:
                return user
        return None
        
    def get_patient_by_id(self, patient_id: int) -> Optional[Patient]:
        """Get patient by ID"""
        return self.patients.get(patient_id)
    
    # Doctor methods
    def create_doctor(self, user_id: int, first_name: str, last_name: str,
                     specialization: str, contact: str, email: str,
                     gender: str = "Not specified", qualification: str = "Medical Doctor",
                     consulting_hours: str = "9:00 AM - 5:00 PM", fees: float = 0.0) -> Doctor:
        """Create a new doctor record"""
        doctor_id = self.next_doctor_id
        self.next_doctor_id += 1
        
        doctor = Doctor(
            doctor_id=doctor_id,
            user_id=user_id,
            first_name=first_name,
            last_name=last_name,
            gender=gender,
            specialization=specialization,
            qualification=qualification,
            contact=contact,
            email=email,
            consulting_hours=consulting_hours,
            fees=fees
        )
        self.doctors[doctor_id] = doctor
        return doctor
    
    def get_doctor_by_id(self, doctor_id: int) -> Optional[Doctor]:
        """Get doctor by ID"""
        return self.doctors.get(doctor_id)
    
    def get_all_doctors(self) -> List[Doctor]:
        """Get all doctors"""
        return list(self.doctors.values())
    
    # Appointment methods
    def create_appointment(self, patient_id: int, doctor_id: int,
                         date: datetime, time_slot: str, reason: str,
                         status: AppointmentStatus = AppointmentStatus.SCHEDULED,
                         notes: str = "") -> Appointment:
        """Create a new appointment"""
        appointment_id = self.next_appointment_id
        self.next_appointment_id += 1
        
        appointment = Appointment(
            appointment_id=appointment_id,
            patient_id=patient_id,
            doctor_id=doctor_id,
            date=date,
            time_slot=time_slot,
            reason=reason,
            status=status,
            notes=notes
        )
        self.appointments[appointment_id] = appointment
        return appointment
    
    def get_appointment_by_id(self, appointment_id: int) -> Optional[Appointment]:
        """Get appointment by ID"""
        return self.appointments.get(appointment_id)
    
    def get_appointments_by_patient(self, patient_id: int) -> List[Appointment]:
        """Get appointments for a patient"""
        patient_appointments = []
        
        for appt in self.appointments.values():
            # Check for direct patient_id attribute match
            if hasattr(appt, 'patient_id') and appt.patient_id == patient_id:
                patient_appointments.append(appt)
                continue
            
            # Check for dictionary format
            if isinstance(appt, dict) and appt.get('patient_id') == patient_id:
                patient_appointments.append(appt)
                continue
            
            # Check for patient object reference
            if hasattr(appt, 'patient'):
                if hasattr(appt.patient, 'patient_id') and appt.patient.patient_id == patient_id:
                    patient_appointments.append(appt)
                    continue
        
        print(f"MemoryStore: Found {len(patient_appointments)} appointments for patient {patient_id}")
        return patient_appointments
    
    def get_appointments_by_doctor(self, doctor_id: int) -> List[Appointment]:
        """Get appointments for a doctor"""
        return [a for a in self.appointments.values() if a.doctor_id == doctor_id]
    
    # Billing methods
    def create_billing(self, appointment_id: int, amount: float,
                      description: str, status: BillingStatus = BillingStatus.PENDING) -> Billing:
        """Create a new billing record"""
        billing_id = self.next_billing_id
        self.next_billing_id += 1
        
        billing = Billing(
            billing_id=billing_id,
            appointment_id=appointment_id,
            amount=amount,
            description=description,
            status=status
        )
        self.billings[billing_id] = billing
        return billing
    
    def get_billing_by_id(self, billing_id: int) -> Optional[Billing]:
        """Get billing record by ID"""
        return self.billings.get(billing_id)
    
    def get_billings_by_appointment(self, appointment_id: int) -> List[Billing]:
        """Get billing records for an appointment"""
        return [b for b in self.billings.values() if b.appointment_id == appointment_id]
    
    # Feedback methods
    def create_feedback(self, patient_id: int, doctor_id: int, appointment_id: int, 
                        rating: int, comment: str = "", submitted_at: datetime = None) -> Feedback:
        """Create a new feedback record"""
        feedback_id = self.next_feedback_id
        self.next_feedback_id += 1
        
        feedback = Feedback(
            feedback_id=feedback_id,
            patient_id=patient_id,
            doctor_id=doctor_id,
            appointment_id=appointment_id,
            rating=rating,
            comment=comment,
            submitted_at=submitted_at or datetime.now(),
            status="pending"
        )
        self.feedback[feedback_id] = feedback
        return feedback
    
    def get_feedback_by_id(self, feedback_id: int) -> Optional[Feedback]:
        """Get feedback by ID"""
        return self.feedback.get(feedback_id)
    
    def get_feedback_by_appointment(self, appointment_id: int) -> List[Feedback]:
        """Get feedback for an appointment"""
        return [f for f in self.feedback.values() if f.appointment_id == appointment_id]
        
    def get_feedback_by_patient(self, patient_id: int) -> List[Feedback]:
        """Get feedback by patient"""
        return [f for f in self.feedback.values() if f.patient_id == patient_id]
        
    def get_feedback_by_doctor(self, doctor_id: int) -> List[Feedback]:
        """Get feedback by doctor"""
        return [f for f in self.feedback.values() if f.doctor_id == doctor_id]
        
    def get_billings_by_patient(self, patient_id: int) -> List[Billing]:
        """Get billing records for a patient"""
        # Get all bills related to the patient
        patient_bills = []
        
        for bill in self.billings.values():
            # Check for direct patient_id attribute in the bill
            if hasattr(bill, 'patient_id') and bill.patient_id == patient_id:
                patient_bills.append(bill)
            # Check for patient_id in dictionary
            elif isinstance(bill, dict) and bill.get('patient_id') == patient_id:
                patient_bills.append(bill)
            # Check for patient attribute
            elif hasattr(bill, 'patient') and hasattr(bill.patient, 'patient_id') and bill.patient.patient_id == patient_id:
                patient_bills.append(bill)
            # Check for appointment relation
            elif hasattr(bill, 'appointment_id'):
                appt = self.get_appointment_by_id(bill.appointment_id)
                if appt and appt.patient_id == patient_id:
                    patient_bills.append(bill)
            # Check for appointment_id in dictionary
            elif isinstance(bill, dict) and 'appointment_id' in bill:
                appt = self.get_appointment_by_id(bill['appointment_id'])
                if appt and appt.patient_id == patient_id:
                    patient_bills.append(bill)
        
        print(f"MemoryStore: Found {len(patient_bills)} bills for patient {patient_id}")
        return patient_bills
        
    def get_doctor_by_user_id(self, user_id: int) -> Optional[Doctor]:
        """Get doctor record by user ID"""
        for doctor in self.doctors.values():
            if doctor.user_id == user_id:
                return doctor
        return None