"""
Patient controller for handling patient-related operations
"""
import logging
from datetime import datetime
from src.data.memory_store import MemoryStore, Patient
from src.utils.helpers import validate_email, validate_phone, log_activity

# Configure logging
logger = logging.getLogger('patient_controller')



class PatientController:
    """Controller for patient operations"""
    
    @staticmethod
    def register_patient(username: str, password: str, first_name: str, last_name: str,
                        gender: str, date_of_birth: datetime, contact_number: str,
                        email: str = None, blood_group: str = None,
                        address: str = None, medical_history: str = None) -> tuple[bool, Patient | str]:
        """Register a new patient"""
        try:
            store = MemoryStore()
            
            # Validate required fields
            if not all([username, password, first_name, last_name, gender, date_of_birth, contact_number]):
                return False, "All required fields must be filled."
            
            # Validate email if provided
            if email and not validate_email(email):
                return False, "Invalid email format."
            
            # Validate phone number
            if not validate_phone(contact_number):
                return False, "Invalid phone number format."
            
            # Create user
            user = store.create_user(username, password, role="patient")
            if not user:
                return False, "Username already exists."
            
            # Create patient profile
            patient = store.create_patient(
                user_id=user.user_id,
                first_name=first_name,
                last_name=last_name,
                gender=gender,
                dob=date_of_birth,
                contact=contact_number,
                email=email or "",
                blood_group=blood_group or "",
                address=address or "",
                medical_history=medical_history or ""
            )
            
            if not patient:
                return False, "Failed to create patient profile"
                
            log_activity(user.user_id, f"New patient registered: {username}")
            return True, patient
                
        except Exception as e:
            logger.error(f"Patient registration error: {str(e)}")
            return False, f"An error occurred: {str(e)}"
    
    @staticmethod
    def get_patient_by_user_id(user_id: int) -> Patient | None:
        """Get patient by user ID"""
        try:
            store = MemoryStore()
            return store.get_patient_by_user_id(user_id)
        except Exception as e:
            logger.error(f"Error retrieving patient: {str(e)}")
            return None
    
    @staticmethod
    def get_all_patients() -> list[Patient]:
        """Get all patients"""
        try:
            store = MemoryStore()
            return store.get_all_patients()
        except Exception as e:
            logger.error(f"Error retrieving patients: {str(e)}")
            return []
    
    @staticmethod
    def update_patient(patient_id: int, first_name: str = None, last_name: str = None,
                      gender: str = None, date_of_birth: datetime = None,
                      blood_group: str = None, contact_number: str = None,
                      email: str = None, address: str = None,
                      medical_history: str = None) -> tuple[bool, Patient | str]:
        """
        Update patient information
        """
        try:
            store = MemoryStore()
            
            # Get patient
            patient = store.get_patient_by_id(patient_id)
            if not patient:
                return False, "Patient not found."
            
            # Create updated patient
            updated_patient = Patient(
                patient_id=patient.patient_id,
                user_id=patient.user_id,
                first_name=first_name if first_name else patient.first_name,
                last_name=last_name if last_name else patient.last_name,
                gender=gender if gender else patient.gender,
                dob=date_of_birth if date_of_birth else patient.dob,
                contact=contact_number if contact_number else patient.contact,
                email=email if email else patient.email,
                blood_group=blood_group if blood_group else patient.blood_group,
                address=address if address is not None else patient.address,
                medical_history=medical_history if medical_history is not None else patient.medical_history
            )
            
            # Validate updated fields
            if contact_number and not validate_phone(contact_number):
                return False, "Invalid phone number format."
                
            if email and not validate_email(email):
                return False, "Invalid email format."
            
            # Update in store
            store.patients[patient_id] = updated_patient
            
            log_activity(patient.user_id, f"Patient profile updated: {patient_id}")
            return True, updated_patient
            
        except Exception as e:
            logger.error(f"Patient update error: {str(e)}")
            return False, f"An error occurred: {str(e)}"
    
    @staticmethod
    def delete_patient(patient_id: int) -> tuple[bool, str]:
        """
        Delete a patient
        """
        try:
            store = MemoryStore()
            
            # Get patient
            patient = store.get_patient_by_id(patient_id)
            if not patient:
                return False, "Patient not found."
            
            # Delete patient
            if patient_id in store.patients:
                del store.patients[patient_id]
            
            # Delete associated user
            if patient.user_id in store.users:
                del store.users[patient.user_id]
            
            log_activity(0, f"Patient deleted: {patient_id}")
            return True, "Patient deleted successfully."
            
        except Exception as e:
            logger.error(f"Patient deletion error: {str(e)}")
            return False, f"An error occurred: {str(e)}"
    
    @staticmethod
    def get_patient_by_id(patient_id: int) -> Patient:
        """
        Get patient by ID
        
        Args:
            patient_id (int): Patient ID
            
        Returns:
            Patient: Patient object if found, None otherwise
        """
        try:
            store = MemoryStore()
            return store.get_patient_by_id(patient_id)
        except Exception as e:
            logger.error(f"Error retrieving patient: {str(e)}")
            return None
    
    @staticmethod
    def get_patient_by_user_id(user_id: int) -> Patient:
        """
        Get patient by user ID
        
        Args:
            user_id (int): User ID
            
        Returns:
            Patient: Patient object if found, None otherwise
        """
        try:
            store = MemoryStore()
            return store.get_patient_by_user_id(user_id)
        except Exception as e:
            logger.error(f"Error retrieving patient: {str(e)}")
            return None
    
    @staticmethod
    def get_all_patients() -> list[Patient]:
        """
        Get all patients
        
        Returns:
            list: List of Patient objects
        """
        try:
            store = MemoryStore()
            return store.get_all_patients()
        except Exception as e:
            logger.error(f"Error retrieving patients: {str(e)}")
            return []
    
    @staticmethod
    def search_patients(search_term: str) -> list[Patient]:
        """
        Search for patients
        
        Args:
            search_term (str): Search term
            
        Returns:
            list: List of matching Patient objects
        """
        try:
            if not search_term:
                return []
            
            store = MemoryStore()
            all_patients = store.get_all_patients()
            
            # Filter patients based on search term
            search_term = search_term.lower()
            return [
                p for p in all_patients
                if search_term in p.first_name.lower() or
                   search_term in p.last_name.lower() or
                   search_term in p.email.lower()
            ]
        except Exception as e:
            logger.error(f"Patient search error: {str(e)}")
            return []