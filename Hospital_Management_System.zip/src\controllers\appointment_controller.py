"""
Appointment controller for managing appointments
"""
import logging
from datetime import datetime
from src.data.memory_store import MemoryStore, Appointment, AppointmentStatus
from src.utils.helpers import log_activity

# Configure logging
logger = logging.getLogger('appointment_controller')

class AppointmentController:
    """Controller for appointment operations"""
    
    @staticmethod
    def create_appointment(patient_id: int, doctor_id: int, date: datetime, 
                         time: datetime.time, reason: str = None, 
                         status: AppointmentStatus = AppointmentStatus.SCHEDULED,
                         notes: str = None) -> tuple[bool, Appointment | str]:
        """Create a new appointment"""
        try:
            store = MemoryStore()
            
            # Log input parameters for debugging
            logger.debug(f"Creating appointment with: patient_id={patient_id}, doctor_id={doctor_id}, "
                        f"date={date}, time={time}, reason={reason}, status={status}")
            
            # Validate required fields
            if not all([patient_id, doctor_id, date]):
                return False, "Patient, doctor and date are required."
            
            # Check if patient exists
            patient = store.get_patient_by_id(patient_id)
            if not patient:
                return False, f"Patient not found with ID: {patient_id}"
            
            # Check if doctor exists
            doctor = store.get_doctor_by_id(doctor_id)
            if not doctor:
                return False, f"Doctor not found with ID: {doctor_id}"
            
            # Ensure we have a valid time
            if not time:
                # Create a default time of 9:00 AM
                time = datetime.time(9, 0)
                
            # Format time slot
            time_slot = time.strftime("%H:%M")
            
            # Make sure we have a reason (required by the Appointment class)
            if not reason:
                reason = f"Appointment with Dr. {doctor.last_name}"
            
            # Create appointment
            try:
                appointment = store.create_appointment(
                    patient_id=patient_id,
                    doctor_id=doctor_id,
                    date=date,
                    time_slot=time_slot,
                    reason=reason,
                    status=status,
                    notes=notes or ""
                )
                
                if not appointment:
                    return False, "Failed to create appointment"
                
                log_activity(patient_id, f"Appointment scheduled: {appointment.appointment_id}")
                return True, appointment
            except Exception as e:
                logger.error(f"Error in store.create_appointment: {str(e)}")
                return False, f"Error creating appointment: {str(e)}"
            
        except Exception as e:
            logger.error(f"Appointment creation error: {str(e)}")
            return False, f"An error occurred: {str(e)}"
    
    @staticmethod
    def get_appointment_by_id(appointment_id: int) -> Appointment | None:
        """Get appointment by ID"""
        try:
            store = MemoryStore()
            return store.get_appointment_by_id(appointment_id)
        except Exception as e:
            logger.error(f"Error retrieving appointment: {str(e)}")
            return None
    
    @staticmethod
    def get_appointments_by_patient(patient_id: int) -> list[Appointment]:
        """Get appointments for a patient"""
        try:
            store = MemoryStore()
            appointments = store.get_appointments_by_patient(patient_id)
            logger.info(f"Found {len(appointments)} appointments for patient {patient_id}")
            
            # Debug: print details of each appointment
            for i, appt in enumerate(appointments):
                logger.info(f"Appointment {i+1}: ID={getattr(appt, 'appointment_id', 'unknown')}, "
                           f"Date={getattr(appt, 'date', 'unknown')}, "
                           f"Doctor={getattr(appt, 'doctor_id', 'unknown')}, "
                           f"Status={getattr(appt, 'status', 'unknown')}")
                
            return appointments
        except Exception as e:
            logger.error(f"Error retrieving patient appointments: {str(e)}")
            return []
    
    @staticmethod
    def get_appointments_by_doctor(doctor_id: int) -> list[Appointment]:
        """Get appointments for a doctor"""
        try:
            store = MemoryStore()
            return store.get_appointments_by_doctor(doctor_id)
        except Exception as e:
            logger.error(f"Error retrieving doctor appointments: {str(e)}")
            return []
    
    @staticmethod
    def update_appointment_status(appointment_id: int, status: AppointmentStatus) -> tuple[bool, Appointment | str]:
        """Update appointment status"""
        try:
            store = MemoryStore()
            
            # Get appointment
            appointment = store.get_appointment_by_id(appointment_id)
            if not appointment:
                return False, "Appointment not found."
            
            # Make sure we have all the required fields for the Appointment class
            time_slot = appointment.time_slot if hasattr(appointment, 'time_slot') else "00:00"
            
            # Make sure we have a reason (required by the Appointment class)
            reason = appointment.reason if hasattr(appointment, 'reason') and appointment.reason else "Appointment"
            
            # Create updated appointment with all required fields
            updated_appointment = Appointment(
                appointment_id=appointment.appointment_id,
                patient_id=appointment.patient_id,
                doctor_id=appointment.doctor_id,
                date=appointment.date,
                time_slot=time_slot,
                reason=reason,
                status=status,
                notes=appointment.notes if hasattr(appointment, 'notes') else ""
            )
            
            # Update in store
            store.appointments[appointment_id] = updated_appointment
            
            log_activity(appointment.patient_id, f"Appointment status updated: {appointment_id} -> {status.name}")
            return True, updated_appointment
            
        except Exception as e:
            logger.error(f"Appointment status update error: {str(e)}")
            return False, f"An error occurred: {str(e)}"
    
    @staticmethod
    def get_appointments(date=None, status=None) -> list[Appointment]:
        """Get appointments based on filters"""
        try:
            store = MemoryStore()
            appointments = list(store.appointments.values())
            
            # Filter by date if specified
            if date:
                appointments = [a for a in appointments if a.date == date]
            
            # Filter by status if specified
            if status and status != "all":
                status_enum = AppointmentStatus(status)
                appointments = [a for a in appointments if a.status == status_enum]
                
            return appointments
        except Exception as e:
            logger.error(f"Error retrieving appointments: {str(e)}")
            return []
    
    @staticmethod
    def cancel_appointment(appointment_id: int) -> tuple[bool, str]:
        """Cancel an appointment"""
        try:
            store = MemoryStore()
            
            # Get appointment
            appointment = store.get_appointment_by_id(appointment_id)
            if not appointment:
                return False, "Appointment not found."
            
            # Check if appointment can be cancelled
            if appointment.status not in [AppointmentStatus.SCHEDULED]:
                return False, f"Cannot cancel appointment with status: {appointment.status.name}"
            
            # Update status to cancelled
            result = AppointmentController.update_appointment_status(
                appointment_id, 
                AppointmentStatus.CANCELLED
            )
            
            if result[0]:
                return True, "Appointment cancelled successfully."
            return False, result[1]
            
        except Exception as e:
            logger.error(f"Appointment cancellation error: {str(e)}")
            return False, f"An error occurred: {str(e)}"