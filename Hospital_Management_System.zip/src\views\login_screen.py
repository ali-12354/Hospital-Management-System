"""
Login screen using CustomTkinter that authenticates against the local sqlite database.
This file provides a small, self-contained CTk window to demonstrate a DB-backed login.
It uses the project's existing database helper `get_connection` from `src.utils.database`.
"""
import customtkinter as ctk
from tkinter import messagebox
import sqlite3
from src.utils.database import get_connection


class LoginScreen(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Login")
        self.geometry("360x220")

        # Username
        self.username_entry = ctk.CTkEntry(self, placeholder_text="Username")
        self.username_entry.pack(pady=(30, 8), padx=20, fill="x")

        # Password
        self.password_entry = ctk.CTkEntry(self, placeholder_text="Password", show="*")
        self.password_entry.pack(pady=8, padx=20, fill="x")

        # Login button
        self.login_button = ctk.CTkButton(self, text="Login", command=self.handle_login)
        self.login_button.pack(pady=20)

        # Note: In production, passwords must be hashed and compared using a safe algorithm
        # (bcrypt, Argon2, etc.). This example uses a plain-text comparison only for demo.

    def handle_login(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()

        if not username or not password:
            messagebox.showerror("Input Error", "Please provide both username and password.")
            return

        conn = None
        try:
            conn = get_connection()
            cursor = conn.cursor()

            # sqlite placeholder is '?'
            query = "SELECT user_id, username, password, role FROM users WHERE username = ?"
            cursor.execute(query, (username,))
            row = cursor.fetchone()

            if row:
                stored_password = row[2]
                # TODO: replace this with hashed-password check using bcrypt
                if password == stored_password:
                    messagebox.showinfo("Success", f"Welcome, {username}!")
                    # In a full app, destroy login window and open main dashboard
                    # self.destroy()
                else:
                    messagebox.showerror("Authentication Failed", "Invalid username or password.")
            else:
                messagebox.showerror("Authentication Failed", "Invalid username or password.")

        except sqlite3.Error as e:
            messagebox.showerror("Database Error", f"An error occurred: {e}")

        finally:
            try:
                if conn:
                    conn.close()
            except Exception:
                pass
