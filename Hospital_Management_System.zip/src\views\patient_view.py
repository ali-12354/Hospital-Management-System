"""
Patient dashboard view module
"""
import os
import sys
from datetime import date, datetime
import customtkinter as ctk
import tkinter as tk
from tkinter import ttk, messagebox
from tkcalendar import DateEntry
from PIL import Image, ImageTk
from src.views.base_view import BaseView
from src.data.memory_store import Patient, MemoryStore
from src.controllers.patient_controller import PatientController
from src.controllers.appointment_controller import AppointmentController
from src.controllers.doctor_controller import DoctorController
from src.controllers.billing_controller import BillingController
from src.controllers.auth_controller import AuthController
from src.controllers.feedback_controller import FeedbackController
from src.views.dialogs.profile_dialog import ProfileDialog
from src.views.dialogs.appointment_dialog import AppointmentDialog
from src.views.dialogs.feedback_dialog import FeedbackDialog

# Add all the dialog classes here...

class PatientView(BaseView):
    """Patient dashboard view implementation"""
    
    def __init__(self, patient):
        """Initialize patient dashboard"""
        super().__init__(f"Hospital Management System - Patient Dashboard", 1200, 800)
        self.patient = patient
        
        # The main_frame is now created and centered in BaseView
        
        # Create header
        self.create_header()
        
        # Create navigation and content area
        self.create_nav_and_content()
        
        # Load all data
        self.load_data()
        
        # Set default view
        self.show_dashboard()
        
    def show_dashboard(self):
        """Show dashboard tab"""
        # Select the first tab (dashboard)
        if hasattr(self, 'notebook') and self.notebook is not None:
            self.notebook.select(0)
    
    def create_header(self):
        """Create header area"""
        header_frame = ctk.CTkFrame(self.main_frame)
        header_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # Welcome label
        welcome_label = ctk.CTkLabel(
            header_frame,
            text=f"Welcome, {self.patient.full_name}",
            font=ctk.CTkFont(size=20, weight="bold")
        )
        welcome_label.pack(side=tk.LEFT, padx=10)
        
        # Right-side buttons
        button_frame = ctk.CTkFrame(header_frame)
        button_frame.pack(side=tk.RIGHT, padx=10)
        
        self.profile_button = ctk.CTkButton(
            button_frame,
            text="My Profile",
            command=self.show_profile,
            fg_color="transparent",
            border_width=2
        )
        self.profile_button.pack(side=tk.LEFT, padx=5)
        
        self.logout_button = ctk.CTkButton(
            button_frame,
            text="Logout",
            command=self.logout,
            fg_color="transparent",
            border_width=2
        )
        self.logout_button.pack(side=tk.LEFT, padx=5)
    
    def create_nav_and_content(self):
        """Create navigation and content area"""
        # Create notebook for tabs
        self.notebook = ttk.Notebook(self.main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Create tabs
        self.create_dashboard_tab()
        self.create_appointments_tab()
        self.create_medical_history_tab()
        self.create_billing_tab()
        self.create_feedback_tab()
    
    def create_dashboard_tab(self):
        """Create dashboard tab"""
        self.dashboard_frame = ctk.CTkFrame(self.notebook)
        
        # Quick actions
        actions_frame = ctk.CTkFrame(self.dashboard_frame)
        actions_frame.pack(fill=tk.X, padx=10, pady=5)
        
        new_appt_button = ctk.CTkButton(
            actions_frame,
            text="Schedule New Appointment",
            command=self.schedule_appointment
        )
        new_appt_button.pack(side=tk.LEFT, padx=5)
        
        # Create dashboard cards
        cards_frame = ctk.CTkFrame(self.dashboard_frame)
        cards_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Upcoming appointments card
        appt_card = ctk.CTkFrame(cards_frame)
        appt_card.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        
        ctk.CTkLabel(
            appt_card,
            text="Upcoming Appointments",
            font=ctk.CTkFont(size=16, weight="bold")
        ).pack(pady=5)
        
        self.upcoming_appointments_table = ttk.Treeview(
            appt_card,
            columns=("Date", "Time", "Doctor", "Status"),
            show="headings"
        )
        
        for col in ["Date", "Time", "Doctor", "Status"]:
            self.upcoming_appointments_table.heading(col, text=col)
            self.upcoming_appointments_table.column(col, width=100)
        
        self.upcoming_appointments_table.pack(
            fill=tk.BOTH,
            expand=True,
            padx=5,
            pady=5
        )
        
        # Recent bills card
        bills_card = ctk.CTkFrame(cards_frame)
        bills_card.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5)
        
        ctk.CTkLabel(
            bills_card,
            text="Recent Bills",
            font=ctk.CTkFont(size=16, weight="bold")
        ).pack(pady=5)
        
        self.recent_bills_table = ttk.Treeview(
            bills_card,
            columns=("Date", "Amount", "Status"),
            show="headings"
        )
        
        for col in ["Date", "Amount", "Status"]:
            self.recent_bills_table.heading(col, text=col)
            self.recent_bills_table.column(col, width=100)
        
        self.recent_bills_table.pack(
            fill=tk.BOTH,
            expand=True,
            padx=5,
            pady=5
        )
        
        self.notebook.add(self.dashboard_frame, text="Dashboard")
    
    def create_appointments_tab(self):
        """Create appointments tab"""
        self.appointments_frame = ctk.CTkFrame(self.notebook)
        
        # Controls
        controls_frame = ctk.CTkFrame(self.appointments_frame)
        controls_frame.pack(fill=tk.X, padx=10, pady=5)
        
        new_appt_button = ctk.CTkButton(
            controls_frame,
            text="Schedule New Appointment",
            command=self.schedule_appointment
        )
        new_appt_button.pack(side=tk.LEFT, padx=5)
        
        refresh_button = ctk.CTkButton(
            controls_frame,
            text="Refresh",
            command=lambda: self.load_appointments(),
            fg_color="transparent",
            border_width=2
        )
        refresh_button.pack(side=tk.LEFT, padx=5)
        
        # Appointments table
        self.appointments_table = ttk.Treeview(
            self.appointments_frame,
            columns=("Date", "Time", "Doctor", "Specialization", "Status", "Actions"),
            show="headings"
        )
        
        for col in ["Date", "Time", "Doctor", "Specialization", "Status", "Actions"]:
            self.appointments_table.heading(col, text=col)
            width = 150 if col in ["Doctor", "Specialization"] else 100
            self.appointments_table.column(col, width=width)
        
        self.appointments_table.pack(
            fill=tk.BOTH,
            expand=True,
            padx=10,
            pady=5
        )
        
        self.appointments_table.bind("<Double-1>", self.on_appointment_select)
        
        self.notebook.add(self.appointments_frame, text="Appointments")
    
    def create_medical_history_tab(self):
        """Create medical history tab"""
        self.medical_frame = ctk.CTkFrame(self.notebook)
        
        # Patient info
        info_frame = ctk.CTkFrame(self.medical_frame)
        info_frame.pack(fill=tk.X, padx=10, pady=5)
        
        labels = [
            ("Name:", f"{self.patient.first_name} {self.patient.last_name}"),
            ("Gender:", self.patient.gender),
            ("Date of Birth:", self.patient.date_of_birth.strftime("%m/%d/%Y")),
            ("Blood Group:", self.patient.blood_group or "Not specified")
        ]
        
        for label, value in labels:
            row = ctk.CTkFrame(info_frame)
            row.pack(fill=tk.X, pady=2)
            
            ctk.CTkLabel(row, text=label, width=100).pack(side=tk.LEFT, padx=5)
            ctk.CTkLabel(row, text=value).pack(side=tk.LEFT, padx=5)
        
        # Medical history
        history_frame = ctk.CTkFrame(self.medical_frame)
        history_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        ctk.CTkLabel(
            history_frame,
            text="Medical History",
            font=ctk.CTkFont(size=16, weight="bold")
        ).pack(pady=5)
        
        self.medical_history_text = ctk.CTkTextbox(history_frame)
        self.medical_history_text.pack(fill=tk.BOTH, expand=True, pady=5)
        self.medical_history_text.insert(
            "1.0",
            self.patient.medical_history or "No medical history recorded."
        )
        self.medical_history_text.configure(state="disabled")
        
        # Past appointments
        appointments_frame = ctk.CTkFrame(self.medical_frame)
        appointments_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        ctk.CTkLabel(
            appointments_frame,
            text="Past Appointments",
            font=ctk.CTkFont(size=16, weight="bold")
        ).pack(pady=5)
        
        self.medical_appointments_table = ttk.Treeview(
            appointments_frame,
            columns=("Date", "Doctor", "Notes"),
            show="headings"
        )
        
        for col in ["Date", "Doctor", "Notes"]:
            self.medical_appointments_table.heading(col, text=col)
            width = 200 if col == "Notes" else 100
            self.medical_appointments_table.column(col, width=width)
        
        self.medical_appointments_table.pack(
            fill=tk.BOTH,
            expand=True,
            pady=5
        )
        
        self.notebook.add(self.medical_frame, text="Medical History")
    
    def create_billing_tab(self):
        """Create billing tab"""
        self.billing_frame = ctk.CTkFrame(self.notebook)
        
        # Controls
        controls_frame = ctk.CTkFrame(self.billing_frame)
        controls_frame.pack(fill=tk.X, padx=10, pady=5)
        
        refresh_button = ctk.CTkButton(
            controls_frame,
            text="Refresh",
            command=self.load_bills,
            fg_color="transparent",
            border_width=2
        )
        refresh_button.pack(side=tk.LEFT, padx=5)
        
        # Bills table
        self.billing_table = ttk.Treeview(
            self.billing_frame,
            columns=("Date", "Amount", "Status", "Actions"),
            show="headings"
        )
        
        for col in ["Date", "Amount", "Status", "Actions"]:
            self.billing_table.heading(col, text=col)
            self.billing_table.column(col, width=100)
        
        self.billing_table.pack(
            fill=tk.BOTH,
            expand=True,
            padx=10,
            pady=5
        )
        
        self.billing_table.bind("<Double-1>", self.on_bill_select)
        
        self.notebook.add(self.billing_frame, text="Billing")
    
    def load_appointments(self):
        """Load appointments data"""
        # Clear tables
        for table in [self.appointments_table, self.upcoming_appointments_table]:
            for item in table.get_children():
                table.delete(item)
        
        # Get appointments from multiple sources to ensure we catch all formats
        patient_appointments = []
        
        # Get appointments from direct controller method
        appointments = AppointmentController.get_appointments_by_patient(
            self.patient.patient_id
        )
        print(f"PatientView: Loaded {len(appointments)} appointments for patient {self.patient.patient_id}")
        patient_appointments.extend(appointments)
        
        # Also check all appointments to catch any that might have been missed
        all_appointments = AppointmentController.get_appointments()
        print(f"PatientView: Retrieved {len(all_appointments)} total appointments")
        
        # Manually filter for this patient's appointments
        manual_patient_appts = []
        for appt in all_appointments:
            # Skip if already in patient_appointments
            if appt in patient_appointments:
                continue
                
            # Check all possible ways an appointment might be associated with a patient
            is_for_patient = False
            
            # Check for direct patient_id attribute
            if hasattr(appt, 'patient_id') and appt.patient_id == self.patient.patient_id:
                is_for_patient = True
            # Check for patient_id in dictionary
            elif isinstance(appt, dict) and appt.get('patient_id') == self.patient.patient_id:
                is_for_patient = True
            # Check for patient object reference
            elif hasattr(appt, 'patient'):
                if hasattr(appt.patient, 'patient_id') and appt.patient.patient_id == self.patient.patient_id:
                    is_for_patient = True
                    
            if is_for_patient:
                manual_patient_appts.append(appt)
        
        if manual_patient_appts:
            print(f"PatientView: Found {len(manual_patient_appts)} additional appointments using manual filtering")
            patient_appointments.extend(manual_patient_appts)
        
        # Sort appointments by date
        try:
            patient_appointments.sort(key=lambda x: 
                (x.date if hasattr(x, 'date') and x.date else
                 x['date'] if isinstance(x, dict) and 'date' in x else
                 datetime.min))
        except Exception as e:
            print(f"PatientView: Error sorting appointments: {e}")
        
        # Add to tables
        upcoming_count = 0
        
        print(f"PatientView: Displaying {len(patient_appointments)} total appointments for patient {self.patient.patient_id}")
        for appt in patient_appointments:
            try:
                # Get date and time safely
                date_str = "Unknown"
                if hasattr(appt, 'date') and hasattr(appt.date, 'strftime'):
                    date_str = appt.date.strftime("%m/%d/%Y")
                elif isinstance(appt, dict) and 'date' in appt and hasattr(appt['date'], 'strftime'):
                    date_str = appt['date'].strftime("%m/%d/%Y")
                
                time_str = "Unknown"
                if hasattr(appt, 'time_slot'):
                    time_str = appt.time_slot
                elif isinstance(appt, dict) and 'time_slot' in appt:
                    time_str = appt['time_slot']
                
                # Get doctor info
                doctor = None
                doctor_id = None
                
                if hasattr(appt, 'doctor_id'):
                    doctor_id = appt.doctor_id
                elif isinstance(appt, dict) and 'doctor_id' in appt:
                    doctor_id = appt['doctor_id']
                
                if doctor_id is not None:
                    doctor = DoctorController.get_doctor_by_id(doctor_id)
                
                doctor_name = "Unknown"
                if doctor and hasattr(doctor, 'first_name') and hasattr(doctor, 'last_name'):
                    doctor_name = f"{doctor.first_name} {doctor.last_name}"
                
                # Get doctor specialization
                specialization = "Unknown"
                if hasattr(appt, 'doctor') and appt.doctor and hasattr(appt.doctor, 'specialization'):
                    specialization = appt.doctor.specialization
                elif doctor and hasattr(doctor, 'specialization'):
                    specialization = doctor.specialization
                
                # Get status
                status_str = "Unknown"
                if hasattr(appt, 'status'):
                    status_str = str(appt.status).title()
                elif isinstance(appt, dict) and 'status' in appt:
                    status_str = str(appt['status']).title()
                
                # Add to appointments table
                self.appointments_table.insert(
                    "",
                    tk.END,
                    values=(
                        date_str,
                        time_str,
                        doctor_name,
                        specialization,
                        status_str,
                        "View Details"
                    )
                )
                
                # Determine if appointment is scheduled and in the future
                is_scheduled = False
                if hasattr(appt, 'status'):
                    if isinstance(appt.status, str):
                        status_val = appt.status.lower()
                        is_scheduled = "scheduled" in status_val or "pending" in status_val
                    else:
                        # Handle enum or other status types
                        status_val = str(appt.status).lower()
                        is_scheduled = "scheduled" in status_val or "pending" in status_val
                elif isinstance(appt, dict) and 'status' in appt:
                    status_val = str(appt['status']).lower()
                    is_scheduled = "scheduled" in status_val or "pending" in status_val
                
                is_future = False
                if hasattr(appt, 'date'):
                    try:
                        if isinstance(appt.date, datetime) or isinstance(appt.date, date):
                            today = date.today()
                            appt_date = appt.date.date() if hasattr(appt.date, 'date') else appt.date
                            is_future = appt_date >= today
                    except Exception:
                        # If date comparison fails, assume it's in the future to show it
                        is_future = True
                elif isinstance(appt, dict) and 'date' in appt:
                    try:
                        appt_date = appt['date']
                        if isinstance(appt_date, datetime) or isinstance(appt_date, date):
                            today = date.today()
                            appt_date = appt_date.date() if hasattr(appt_date, 'date') else appt_date
                            is_future = appt_date >= today
                    except Exception:
                        # If date comparison fails, assume it's in the future
                        is_future = True
                
                if (is_scheduled and is_future and upcoming_count < 5):
                    self.upcoming_appointments_table.insert(
                        "",
                        tk.END,
                        values=(
                            date_str,
                            time_str,
                            doctor_name,
                            status_str
                        )
                    )
                    upcoming_count += 1
            except Exception as e:
                print(f"Error processing appointment for display: {e}")
                # Skip this appointment if there's an error
    
    def load_bills(self):
        """Load billing data"""
        # Clear tables
        for table in [self.billing_table, self.recent_bills_table]:
            for item in table.get_children():
                table.delete(item)
        
        # Get bills from both methods to ensure all formats are covered
        patient_bills = []
        
        # Try direct get_bills_by_patient method
        bills = BillingController.get_bills_by_patient(self.patient.patient_id)
        print(f"PatientView: Loaded {len(bills)} bills for patient {self.patient.patient_id} via get_bills_by_patient")
        patient_bills.extend(bills)
        
        # Try get_bills method too to ensure we catch all formats
        all_bills = BillingController.get_bills()
        print(f"PatientView: Retrieved {len(all_bills)} total bills via get_bills")
        
        # Filter manually for this patient
        manual_patient_bills = []
        for bill in all_bills:
            # Skip if this exact bill object is already in patient_bills
            if bill in patient_bills:
                continue
                
            # Check all possible ways a bill might be associated with a patient
            is_for_patient = False
            
            # Check for direct patient_id attribute
            if hasattr(bill, 'patient_id') and bill.patient_id == self.patient.patient_id:
                is_for_patient = True
            # Check for patient_id in dictionary
            elif isinstance(bill, dict) and bill.get('patient_id') == self.patient.patient_id:
                is_for_patient = True
            # Check for patient object reference
            elif hasattr(bill, 'patient'):
                if hasattr(bill.patient, 'patient_id') and bill.patient.patient_id == self.patient.patient_id:
                    is_for_patient = True
            # Check for appointment relation
            elif hasattr(bill, 'appointment_id'):
                memory_store = MemoryStore()
                appt = memory_store.get_appointment_by_id(bill.appointment_id)
                if appt and hasattr(appt, 'patient_id') and appt.patient_id == self.patient.patient_id:
                    is_for_patient = True
            # Check for appointment_id in dictionary
            elif isinstance(bill, dict) and 'appointment_id' in bill:
                memory_store = MemoryStore()
                appt = memory_store.get_appointment_by_id(bill['appointment_id'])
                if appt and hasattr(appt, 'patient_id') and appt.patient_id == self.patient.patient_id:
                    is_for_patient = True
                    
            if is_for_patient:
                manual_patient_bills.append(bill)
        
        if manual_patient_bills:
            print(f"PatientView: Found {len(manual_patient_bills)} additional bills using manual filtering")
            patient_bills.extend(manual_patient_bills)
        
        # Sort bills by date if possible
        try:
            patient_bills.sort(key=lambda x: 
                (x.bill_date if hasattr(x, 'bill_date') and x.bill_date else
                 x.date if hasattr(x, 'date') and x.date else
                 x['bill_date'] if isinstance(x, dict) and 'bill_date' in x else
                 x['date'] if isinstance(x, dict) and 'date' in x else
                 datetime.min), 
                reverse=True)
        except Exception as e:
            print(f"PatientView: Error sorting bills: {e}")
        
        # Add to tables
        recent_count = 0
        
        print(f"PatientView: Displaying {len(patient_bills)} total bills for patient {self.patient.patient_id}")
        for bill in patient_bills:
            try:
                # Get date string safely
                date_str = "Unknown"
                if hasattr(bill, 'bill_date') and hasattr(bill.bill_date, 'strftime'):
                    date_str = bill.bill_date.strftime("%m/%d/%Y")
                elif hasattr(bill, 'date') and hasattr(bill.date, 'strftime'):
                    date_str = bill.date.strftime("%m/%d/%Y")
                elif isinstance(bill, dict):
                    bill_date = bill.get('bill_date') or bill.get('date')
                    if hasattr(bill_date, 'strftime'):
                        date_str = bill_date.strftime("%m/%d/%Y")
                
                # Get amount string safely
                amount_str = "Unknown"
                if hasattr(bill, 'total_amount'):
                    amount_str = f"${bill.total_amount:.2f}"
                elif hasattr(bill, 'amount'):
                    amount_str = f"${bill.amount:.2f}"
                elif isinstance(bill, dict):
                    amount = bill.get('total_amount') or bill.get('amount')
                    if amount is not None:
                        amount_str = f"${float(amount):.2f}"
                
                # Get status string safely
                status = "Unknown"
                if hasattr(bill, 'payment_status'):
                    status_val = bill.payment_status
                    status = status_val.title() if isinstance(status_val, str) else str(status_val).title()
                elif hasattr(bill, 'status'):
                    status_val = bill.status
                    status = status_val.title() if isinstance(status_val, str) else str(status_val).title()
                elif isinstance(bill, dict) and 'payment_status' in bill:
                    status_val = bill['payment_status']
                    status = status_val.title() if isinstance(status_val, str) else str(status_val).title()
                elif isinstance(bill, dict) and 'status' in bill:
                    status_val = bill['status']
                    status = status_val.title() if isinstance(status_val, str) else str(status_val).title()
            except Exception as e:
                print(f"Error processing bill for display: {e}")
                # Use safe defaults if there's an error
                date_str = "Unknown"
                amount_str = "Unknown"
                status = "Unknown"
            
            # Add to billing table
            # Determine an ID for the tree item (use billing_id or billing_id-like keys when available)
            item_id = None
            if isinstance(bill, dict):
                item_id = bill.get('bill_id') or bill.get('billing_id') or bill.get('invoice_id')
            else:
                item_id = getattr(bill, 'billing_id', None) or getattr(bill, 'bill_id', None) or getattr(bill, 'invoice_id', None)

            iid = str(item_id) if item_id is not None else None

            # Insert the item; if we have an iid use it so we can map back to the invoice id later
            if iid:
                self.billing_table.insert("", iid, values=(date_str, amount_str, status, "View Details"))
            else:
                self.billing_table.insert("", tk.END, values=(date_str, amount_str, status, "View Details"))
            
            # Add to recent bills
            if recent_count < 5:
                self.recent_bills_table.insert(
                    "",
                    tk.END,
                    values=(date_str, amount_str, status)
                )
                recent_count += 1
    
    def show_profile(self):
        """Show profile dialog"""
        dialog = ProfileDialog(self.patient, self)
        dialog.focus()
        self.wait_window(dialog)
        
        # Refresh patient data if profile was updated
        self.patient = PatientController.get_patient_by_id(self.patient.patient_id)
        self.load_data()
    
    def schedule_appointment(self):
        """Show appointment form in the appointments tab"""
        # Select the appointments tab first
        self.notebook.select(1)  # Index 1 is the appointments tab
        
        # Clear any existing appointment form
        if hasattr(self, 'appointment_form_frame'):
            self.appointment_form_frame.destroy()
        
        # Create a frame for the appointment form
        self.appointment_form_frame = ctk.CTkFrame(self.appointments_frame)
        self.appointment_form_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create form header
        header = ctk.CTkLabel(
            self.appointment_form_frame,
            text="Schedule New Appointment",
            font=ctk.CTkFont(size=18, weight="bold")
        )
        header.pack(pady=(10, 20))
        
        # Create form fields
        form_frame = ctk.CTkFrame(self.appointment_form_frame)
        form_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # Doctor selection
        doctor_frame = ctk.CTkFrame(form_frame)
        doctor_frame.pack(fill=tk.X, pady=5)
        
        doctor_label = ctk.CTkLabel(doctor_frame, text="Select Doctor:", width=100)
        doctor_label.pack(side=tk.LEFT, padx=5)
        
        # Get all doctors
        doctors = DoctorController.get_all_doctors()
        doctor_names = [f"Dr. {d.first_name} {d.last_name} ({d.specialization})" for d in doctors]
        
        self.doctor_var = tk.StringVar()
        doctor_menu = ctk.CTkOptionMenu(
            doctor_frame,
            variable=self.doctor_var,
            values=doctor_names
        )
        doctor_menu.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        if doctor_names:
            doctor_menu.set(doctor_names[0])
        
        # Date selection
        date_frame = ctk.CTkFrame(form_frame)
        date_frame.pack(fill=tk.X, pady=5)
        
        date_label = ctk.CTkLabel(date_frame, text="Select Date:", width=100)
        date_label.pack(side=tk.LEFT, padx=5)
        
        try:
            from tkcalendar import DateEntry
            self.date_picker = DateEntry(
                date_frame,
                width=20,
                date_pattern="mm/dd/yyyy",
                mindate=datetime.now(),
                background="#1f6aa5" if ctk.get_appearance_mode() == "Dark" else "#2D5A98",
                foreground="white"
            )
            self.date_picker.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        except ImportError:
            date_entry = ctk.CTkEntry(date_frame)
            date_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
            date_entry.insert(0, datetime.now().strftime("%m/%d/%Y"))
            self.date_picker = date_entry
        
        # Time selection
        time_frame = ctk.CTkFrame(form_frame)
        time_frame.pack(fill=tk.X, pady=5)
        
        time_label = ctk.CTkLabel(time_frame, text="Select Time:", width=100)
        time_label.pack(side=tk.LEFT, padx=5)
        
        times = ["9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM"]
        self.time_var = tk.StringVar()
        time_menu = ctk.CTkOptionMenu(time_frame, variable=self.time_var, values=times)
        time_menu.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        time_menu.set(times[0])
        
        # Notes field
        notes_frame = ctk.CTkFrame(form_frame)
        notes_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        notes_label = ctk.CTkLabel(notes_frame, text="Notes:")
        notes_label.pack(anchor="w", padx=5, pady=5)
        
        self.notes_text = ctk.CTkTextbox(notes_frame, height=100)
        self.notes_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Add some spacing before buttons
        ctk.CTkLabel(self.appointment_form_frame, text="").pack(pady=5)
        
        # Save appointment button
        self.save_appt_button = ctk.CTkButton(
            self.appointment_form_frame,
            text="Save Appointment",
            command=self.save_appointment,
            fg_color="#1f6aa5",  # Blue color (consistent with app theme)
            hover_color="#135380",
            font=ctk.CTkFont(size=14),
            height=38,
            corner_radius=8,
            border_width=0
        )
        self.save_appt_button.pack(pady=10, padx=20, fill=tk.X)
        
        # Buttons frame for cancel button
        button_frame = ctk.CTkFrame(self.appointment_form_frame)
        button_frame.pack(fill=tk.X, pady=5)
        
        # Cancel button
        cancel_button = ctk.CTkButton(
            button_frame,
            text="Cancel",
            command=self.cancel_appointment_form,
            fg_color="transparent",
            border_width=2
        )
        cancel_button.pack(side=tk.RIGHT, padx=40, fill=tk.X)
        
        # Hide the appointments table temporarily
        self.appointments_table.pack_forget()
    
    def save_appointment(self):
        """Save the new appointment"""
        try:
            # Change button text and disable while processing
            self.save_appt_button.configure(text="Scheduling...", state="disabled")
            
            # Get the selected doctor
            doctor_selection = self.doctor_var.get()
            if not doctor_selection:
                messagebox.showerror("Error", "Please select a doctor")
                self.save_appt_button.configure(text="Save Appointment", state="normal")
                return
                
            # Extract doctor ID from selection
            doctors = DoctorController.get_all_doctors()
            selected_doctor = None
            
            for doctor in doctors:
                doctor_name = f"Dr. {doctor.first_name} {doctor.last_name} ({doctor.specialization})"
                if doctor_name == doctor_selection:
                    selected_doctor = doctor
                    break
            
            if not selected_doctor:
                messagebox.showerror("Error", "Invalid doctor selection")
                self.save_appt_button.configure(text="Save Appointment", state="normal")
                return
                
            # Get selected date
            try:
                if hasattr(self.date_picker, "get_date"):
                    appt_date = self.date_picker.get_date()
                else:
                    date_str = self.date_picker.get()
                    appt_date = datetime.strptime(date_str, "%m/%d/%Y").date()
                    
                # Validate date is not in the past
                today = date.today()
                if appt_date < today:
                    messagebox.showerror("Error", "Please select a future date")
                    self.save_appt_button.configure(text="Save Appointment", state="normal")
                    return
            except Exception as e:
                messagebox.showerror("Error", f"Invalid date format: {str(e)}")
                self.save_appt_button.configure(text="Save Appointment", state="normal")
                return
                
            # Get selected time
            time_str = self.time_var.get()
            
            # Get notes
            notes = self.notes_text.get("1.0", tk.END).strip()
            
            # Create appointment
            success, result = AppointmentController.create_appointment(
                patient_id=self.patient.patient_id,
                doctor_id=selected_doctor.doctor_id,
                date=datetime.combine(appt_date, datetime.min.time()),
                time=datetime.strptime(time_str, "%I:%M %p").time(),
                reason="Patient scheduled appointment",
                notes=notes
            )
            
            if success:
                messagebox.showinfo("Success", "Appointment scheduled successfully")
                self.cancel_appointment_form()  # Close the form
                self.load_appointments()  # Refresh the appointments list
            else:
                messagebox.showerror("Error", str(result))
                self.save_appt_button.configure(text="Save Appointment", state="normal")
                
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")
            # Reset the button state in case of error
            self.save_appt_button.configure(text="Save Appointment", state="normal")
    
    def cancel_appointment_form(self):
        """Cancel the appointment form and show the appointments table"""
        # Destroy the form frame
        if hasattr(self, 'appointment_form_frame'):
            self.appointment_form_frame.destroy()
            
        # Show the appointments table again
        self.appointments_table.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
    
    def on_appointment_select(self, event):
        """Handle appointment selection"""
        selection = self.appointments_table.selection()
        if not selection:
            return
        
        # Get selected appointment
        item = selection[0]
        values = self.appointments_table.item(item)["values"]
        
        # Show appointment details
        date_str = values[0]
        time_str = values[1]
        doctor_name = values[2]
        status = values[4]
        
        details = (
            f"Appointment Details\n\n"
            f"Date: {date_str}\n"
            f"Time: {time_str}\n"
            f"Doctor: {doctor_name}\n"
            f"Status: {status}"
        )
        
        messagebox.showinfo("Appointment Details", details)
    
    def on_bill_select(self, event):
        """Handle bill selection"""
        selection = self.billing_table.selection()
        if not selection:
            return
        
        # Get selected bill
        item = selection[0]
        values = self.billing_table.item(item)["values"]

        # Attempt to obtain invoice id from the tree item iid
        invoice_id = None
        try:
            invoice_id = int(item)
        except Exception:
            invoice_id = None

        # Show bill details
        date_str = values[0]
        amount_str = values[1]
        status = values[2]

        details = (
            f"Bill Details\n\n"
            f"Date: {date_str}\n"
            f"Amount: {amount_str}\n"
            f"Status: {status}"
        )

        # If bill is pending, offer to mark as paid
        try:
            status_low = str(status).lower()
        except Exception:
            status_low = ""

        if "pending" in status_low or "unpaid" in status_low:
            if messagebox.askyesno("Mark Paid", details + "\n\nMark this bill as paid?"):
                try:
                    from src.reports import admin_reports
                    ok = admin_reports.mark_bill_as_paid(invoice_id) if invoice_id is not None else False
                    if ok:
                        messagebox.showinfo("Success", "Bill marked as paid")
                        # Refresh bills and recent bills
                        self.load_bills()
                    else:
                        messagebox.showerror("Error", "Failed to mark bill as paid")
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to mark bill as paid: {e}")
        else:
            messagebox.showinfo("Bill Details", details)
    
    def create_feedback_tab(self):
        """Create feedback tab"""
        self.feedback_frame = ctk.CTkFrame(self.notebook)
        
        # Controls
        controls_frame = ctk.CTkFrame(self.feedback_frame)
        controls_frame.pack(fill=tk.X, padx=10, pady=5)
        
        new_feedback_button = ctk.CTkButton(
            controls_frame,
            text="Submit New Feedback",
            command=self.submit_feedback
        )
        new_feedback_button.pack(side=tk.LEFT, padx=5)
        
        refresh_button = ctk.CTkButton(
            controls_frame,
            text="Refresh",
            command=self.load_feedback,
            fg_color="transparent",
            border_width=2
        )
        refresh_button.pack(side=tk.LEFT, padx=5)
        
        # Feedback table
        self.feedback_table = ttk.Treeview(
            self.feedback_frame,
            columns=("Date", "Doctor", "Rating", "Status"),
            show="headings"
        )
        
        for col in ["Date", "Doctor", "Rating", "Status"]:
            self.feedback_table.heading(col, text=col)
            width = 150 if col == "Doctor" else 100
            self.feedback_table.column(col, width=width)
        
        self.feedback_table.pack(
            fill=tk.BOTH,
            expand=True,
            padx=10,
            pady=5
        )
        
        self.feedback_table.bind("<Double-1>", self.on_feedback_select)
        
        self.notebook.add(self.feedback_frame, text="Feedback")
        
        # Load initial data
        self.load_feedback()
    
    def load_feedback(self):
        """Load feedback data"""
        # Clear table
        for item in self.feedback_table.get_children():
            self.feedback_table.delete(item)
        
        # Get feedback
        feedback_list = FeedbackController.get_feedback_by_patient(self.patient.patient_id)
        
        # Sort feedback by date
        feedback_list.sort(key=lambda x: x.submitted_at, reverse=True)
        
        # Add to table
        for feedback in feedback_list:
            try:
                # Get doctor info safely
                doctor_id = None
                doctor_name = "Unknown"
                
                if hasattr(feedback, 'doctor_id'):
                    doctor_id = feedback.doctor_id
                    doctor = DoctorController.get_doctor_by_id(doctor_id)
                    if doctor and hasattr(doctor, 'first_name') and hasattr(doctor, 'last_name'):
                        doctor_name = f"Dr. {doctor.first_name} {doctor.last_name}"
                    else:
                        doctor_name = f"Doctor {doctor_id}"
                
                # Format date safely
                date_str = "Unknown"
                if hasattr(feedback, 'submitted_at'):
                    if hasattr(feedback.submitted_at, 'strftime'):
                        date_str = feedback.submitted_at.strftime("%m/%d/%Y")
                    else:
                        date_str = str(feedback.submitted_at)
                
                # Format rating safely
                rating_stars = ""
                if hasattr(feedback, 'rating'):
                    try:
                        rating_stars = "★" * int(feedback.rating)
                    except (ValueError, TypeError):
                        rating_stars = str(feedback.rating)
                
                # Format status safely
                status = "Pending"
                if hasattr(feedback, "status"):
                    if isinstance(feedback.status, str):
                        status = feedback.status.title()
                    else:
                        status = str(feedback.status).title()
            except Exception as e:
                print(f"Error formatting feedback: {str(e)}")
                continue
            
            self.feedback_table.insert(
                "",
                tk.END,
                values=(date_str, doctor_name, rating_stars, status)
            )
    
    def set_rating(self, rating):
        """Set the rating value and update the star buttons"""
        self.rating_var.set(rating)
        self.update_rating_stars()
        
    def update_rating_stars(self):
        """Update the star buttons based on the selected rating"""
        current_rating = self.rating_var.get()
        for i in range(1, 6):
            button = getattr(self, f"star_button_{i}")
            if i <= current_rating:
                button.configure(fg_color="#FFD700", text="★")  # Gold for selected
            else:
                button.configure(fg_color="transparent", text="☆")  # Outline for unselected
    
    def save_feedback(self):
        """Save the new feedback"""
        try:
            # Change button text and disable while processing
            self.save_feedback_button.configure(text="Submitting...", state="disabled")
            
            # Get the selected doctor
            doctor_selection = self.feedback_doctor_var.get()
            if not doctor_selection:
                messagebox.showerror("Error", "Please select a doctor")
                self.save_feedback_button.configure(text="Submit Feedback", state="normal")
                return
                
            # Extract doctor ID from selection
            doctors = DoctorController.get_all_doctors()
            selected_doctor = None
            
            for doctor in doctors:
                doctor_name = f"Dr. {doctor.first_name} {doctor.last_name} ({doctor.specialization})"
                if doctor_name == doctor_selection:
                    selected_doctor = doctor
                    break
            
            if not selected_doctor:
                messagebox.showerror("Error", "Invalid doctor selection")
                self.save_feedback_button.configure(text="Submit Feedback", state="normal")
                return
                
            # Get rating
            rating = self.rating_var.get()
            if rating < 1:
                messagebox.showerror("Error", "Please select a rating (1-5 stars)")
                self.save_feedback_button.configure(text="Submit Feedback", state="normal")
                return
            
            # Get comments
            comments = self.comments_text.get("1.0", tk.END).strip()
            
            # Find the most recent appointment with this doctor or use 0 if none found
            appointments = AppointmentController.get_appointments_by_patient(self.patient.patient_id)
            doctor_appointments = [a for a in appointments if hasattr(a, 'doctor_id') and a.doctor_id == selected_doctor.doctor_id]
            appointment_id = doctor_appointments[0].appointment_id if doctor_appointments else 0
            
            # Submit feedback
            success, result = FeedbackController.submit_feedback(
                patient_id=self.patient.patient_id,
                doctor_id=selected_doctor.doctor_id,
                appointment_id=appointment_id,
                rating=rating,
                comment=comments
            )
            
            if success:
                messagebox.showinfo("Success", "Feedback submitted successfully")
                self.cancel_feedback_form()  # Close the form
                self.load_feedback()  # Refresh the feedback list
            else:
                messagebox.showerror("Error", str(result))
                self.save_feedback_button.configure(text="Submit Feedback", state="normal")
                
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")
            # Reset the button state in case of error
            self.save_feedback_button.configure(text="Submit Feedback", state="normal")
    
    def cancel_feedback_form(self):
        """Cancel the feedback form and show the feedback table"""
        # Destroy the form frame
        if hasattr(self, 'feedback_form_frame'):
            self.feedback_form_frame.destroy()
            
        # Show the feedback table again
        self.feedback_table.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
    
    def on_feedback_select(self, event):
        """Handle feedback selection"""
        selection = self.feedback_table.selection()
        if not selection:
            return
        
        # Get selected feedback
        item = selection[0]
        values = self.feedback_table.item(item)["values"]
        
        # Show feedback details
        date_str = values[0]
        doctor_name = values[1]
        rating = values[2]
        status = values[3]
        
        details = (
            f"Feedback Details\n\n"
            f"Date: {date_str}\n"
            f"Doctor: {doctor_name}\n"
            f"Rating: {rating}\n"
            f"Status: {status}"
        )
        
        messagebox.showinfo("Feedback Details", details)
    
    def submit_feedback(self):
        """Show feedback form in the feedback tab"""
        # Select the feedback tab first
        self.notebook.select(4)  # Index 4 is the feedback tab
        
        # Clear any existing feedback form
        if hasattr(self, 'feedback_form_frame'):
            self.feedback_form_frame.destroy()
        
        # Create a frame for the feedback form
        self.feedback_form_frame = ctk.CTkFrame(self.feedback_frame)
        self.feedback_form_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create form header
        header = ctk.CTkLabel(
            self.feedback_form_frame,
            text="Submit Feedback",
            font=ctk.CTkFont(size=18, weight="bold")
        )
        header.pack(pady=(10, 20))
        
        # Create form fields
        form_frame = ctk.CTkFrame(self.feedback_form_frame)
        form_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # Doctor selection
        doctor_frame = ctk.CTkFrame(form_frame)
        doctor_frame.pack(fill=tk.X, pady=5)
        
        doctor_label = ctk.CTkLabel(doctor_frame, text="Select Doctor:", width=100)
        doctor_label.pack(side=tk.LEFT, padx=5)
        
        # Get all doctors
        doctors = DoctorController.get_all_doctors()
        doctor_names = [f"Dr. {d.first_name} {d.last_name} ({d.specialization})" for d in doctors]
        
        self.feedback_doctor_var = tk.StringVar()
        doctor_menu = ctk.CTkOptionMenu(
            doctor_frame,
            variable=self.feedback_doctor_var,
            values=doctor_names
        )
        doctor_menu.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        if doctor_names:
            doctor_menu.set(doctor_names[0])
        
        # Rating
        rating_frame = ctk.CTkFrame(form_frame)
        rating_frame.pack(fill=tk.X, pady=5)
        
        rating_label = ctk.CTkLabel(rating_frame, text="Rating (1-5):", width=100)
        rating_label.pack(side=tk.LEFT, padx=5)
        
        self.rating_var = tk.IntVar(value=5)
        rating_stars = ctk.CTkFrame(rating_frame)
        rating_stars.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        for i in range(1, 6):
            star_button = ctk.CTkButton(
                rating_stars,
                text="★",
                width=30,
                height=30,
                command=lambda value=i: self.set_rating(value)
            )
            star_button.pack(side=tk.LEFT, padx=2)
            setattr(self, f"star_button_{i}", star_button)
        
        # Comments field
        comments_frame = ctk.CTkFrame(form_frame)
        comments_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        comments_label = ctk.CTkLabel(comments_frame, text="Comments:")
        comments_label.pack(anchor="w", padx=5, pady=5)
        
        self.comments_text = ctk.CTkTextbox(comments_frame, height=100)
        self.comments_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Buttons
        button_frame = ctk.CTkFrame(self.feedback_form_frame)
        button_frame.pack(fill=tk.X, pady=10)
        
        # Submit feedback button
        self.save_feedback_button = ctk.CTkButton(
            button_frame,
            text="Submit Feedback",
            command=self.save_feedback,
            fg_color="#1f6aa5",  # Blue color (consistent with app theme)
            hover_color="#135380",
            font=ctk.CTkFont(size=14),
            height=38,
            corner_radius=8,
            border_width=0
        )
        self.save_feedback_button.pack(side=tk.LEFT, padx=10, expand=True, fill=tk.X)
        
        # Cancel button
        cancel_button = ctk.CTkButton(
            button_frame,
            text="Cancel",
            command=self.cancel_feedback_form,
            fg_color="transparent",
            border_width=2
        )
        cancel_button.pack(side=tk.LEFT, padx=10, expand=True, fill=tk.X)
        
        # Hide the feedback table temporarily
        self.feedback_table.pack_forget()
        
        # Update the star buttons based on initial rating
        self.update_rating_stars()
    
    def load_data(self):
        """Load all data for patient dashboard"""
        try:
            # Load appointments
            self.load_appointments()
            
            # Load bills
            self.load_bills()
            
            # Load feedback if the method exists
            if hasattr(self, 'load_feedback'):
                self.load_feedback()
        except Exception as e:
            print(f"Error loading data: {e}")
            messagebox.showerror("Data Loading Error", f"Failed to load some data: {str(e)}")
    
    def logout(self):
        """Handle logout"""
        if messagebox.askyesno("Logout", "Are you sure you want to logout?"):
            # Log out user
            AuthController.logout(self.patient.user_id)
            
            # Show login view
            from src.views.login_view import LoginView
            self.destroy()
            login_view = LoginView()
            login_view.focus()
            login_view.mainloop()  # Start the login view's main event loop