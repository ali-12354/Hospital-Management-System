"""
Authentication controller for managing user authentication
"""
import logging
from src.data.memory_store import MemoryStore, User
from src.utils.helpers import validate_password_strength, log_activity

# Configure logging
logger = logging.getLogger('auth_controller')

class AuthController:
    """Controller for authentication operations"""
    
    @staticmethod
    def create_admin_if_not_exists() -> bool:
        """
        Create admin user if it doesn't exist
        
        Returns:
            bool: Success status
        """
        try:
            store = MemoryStore()
            admin_user = store.get_user_by_username("admin")
            
            if not admin_user:
                logger.info("Creating default admin account")
                admin_user = store.create_user(
                    username="admin",
                    password="Admin@123",
                    role="admin"
                )
                
                if admin_user:
                    logger.info("Default admin account created successfully")
                    return True
                else:
                    logger.error("Failed to create default admin account")
                    return False
            
            return True
        except Exception as e:
            logger.error(f"Error creating admin account: {str(e)}")
            return False
    
    @staticmethod
    def login(username: str, password: str) -> tuple[bool, User | str]:
        """
        Authenticate a user
        
        Args:
            username (str): Username to authenticate
            password (str): Password to verify
            
        Returns:
            tuple[bool, Union[User, str]]: Success status and user object or error message
        """
        try:
            # Validate inputs
            if not username or not password:
                return False, "Username and password are required."
            
            store = MemoryStore()
            user = store.authenticate_user(username, password)
            
            if user:
                log_activity(user.user_id, "User login successful")
                return True, user
            else:
                logger.warning(f"Failed login attempt for username: {username}")
                return False, "Invalid username or password."
                
        except Exception as e:
            logger.error(f"Login error: {str(e)}")
            return False, f"An error occurred during login: {str(e)}"
    
    @staticmethod
    def register_patient(username: str, password: str, confirm_password: str) -> tuple[bool, str]:
        """
        Validate registration data for patient
        
        Args:
            username (str): Username for new account
            password (str): Plain text password
            confirm_password (str): Password confirmation
            
        Returns:
            tuple[bool, str]: Success status and message
        """
        try:
            store = MemoryStore()
            
            # Validate inputs
            if not username or len(username) < 4:
                return False, "Username must be at least 4 characters"
            
            if not password:
                return False, "Password is required"
            
            if password != confirm_password:
                return False, "Passwords do not match"
            
            # Validate password strength
            if not validate_password_strength(password):
                return False, "Password must be at least 8 characters with letters, numbers and special characters"
            
            # Check if username exists
            if store.get_user_by_username(username):
                return False, "Username already exists"
            
            return True, "Registration validated"
            
        except Exception as e:
            logger.error(f"Registration validation error: {str(e)}")
            return False, f"An error occurred: {str(e)}"
    
    @staticmethod
    def logout(user_id: int) -> bool:
        """
        Log out user
        
        Args:
            user_id (int): User ID
            
        Returns:
            bool: Success status
        """
        try:
            log_activity(user_id, "User logout")
            return True
        except Exception as e:
            logger.error(f"Logout error: {str(e)}")
            return False